#version 120

/*
    Agua: por defecto, vanilla + olas. Con REALISTIC_WATER (perfil Ultra)
    se le suma tinte azul, sombreado por ola, y transparencia realista por
    angulo (fresnel) -- todo con matematica local, sin leer la pantalla.
*/

// #define REALISTIC_WATER

uniform sampler2D texture;
uniform sampler2D lightmap;

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec3 viewDir;
varying vec3 waveNormal;

void main() {
    vec4 tex = texture2D(texture, texcoord);
    vec4 light = texture2D(lightmap, lmcoord);
    vec3 col = tex.rgb * color.rgb * light.rgb;
    float alpha = tex.a * color.a;

    // Pulido sutil de olas para TODOS los perfiles: como ya calculamos la
    // normal de la ola para el movimiento del vertice, este brillo/sombra
    // leve es practicamente gratis (sin costo extra real).
    float waveShadeBase = clamp(dot(waveNormal, vec3(0.0, 1.0, 0.0)), 0.75, 1.0);
    col *= mix(0.92, 1.06, waveShadeBase);

    #ifdef REALISTIC_WATER
    // Tinte azul mas natural (menos plano, con un poco mas de verde en las
    // zonas claras, como el agua real bajo el sol)
    vec3 waterTintDeep = vec3(0.12, 0.45, 0.85);
    vec3 waterTintShallow = vec3(0.35, 0.75, 0.8);
    float waveShade = clamp(dot(waveNormal, vec3(0.0, 1.0, 0.0)), 0.5, 1.0);
    vec3 waterTint = mix(waterTintDeep, waterTintShallow, waveShade);
    col = mix(tex.rgb * light.rgb, tex.rgb * light.rgb * waterTint * 1.55, 0.55);
    col *= mix(0.85, 1.15, waveShade);

    // Fresnel mas suave/gradual
    float fresnel = pow(1.0 - clamp(dot(viewDir, waveNormal), 0.0, 1.0), 2.5);
    alpha = clamp(mix(tex.a * 0.4, tex.a * 0.88, fresnel), 0.0, 0.88);
    #endif

    gl_FragColor = vec4(col, alpha);
}
