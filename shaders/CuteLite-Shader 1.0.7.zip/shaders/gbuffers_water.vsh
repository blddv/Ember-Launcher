#version 120

/*
    Agua: por defecto, color 100% vanilla con olas reales. En el perfil Ultra
    (REALISTIC_WATER) se calcula tambien la normal de la ola de forma analitica
    (sin costo extra real) para dar sombreado y transparencia realista.
*/

// #define REALISTIC_WATER // Agua con tinte/transparencia realista (activado en perfil Ultra)
#define WAVE_LAYERS 2 // [1 2 3 4 5 6 7]  Capas de olas: 1 = mas FPS, 7 = mas detalle

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec3 viewDir;
varying vec3 waveNormal;

uniform mat4 gbufferModelViewInverse;
uniform float frameTimeCounter;

void main() {
    vec4 vertex = gl_Vertex;
    waveNormal = vec3(0.0, 1.0, 0.0);

    if (gl_Normal.y > 0.5) {
        vec4 tmpView = gl_ModelViewMatrix * vertex;
        vec4 tmpWorld = gbufferModelViewInverse * tmpView;

        float fx1 = tmpWorld.x * 0.5 + frameTimeCounter * 1.2;
        float fz1 = tmpWorld.z * 0.4 + frameTimeCounter * 1.0;
        float wave = sin(fx1) * 0.045 + cos(fz1) * 0.045;
        float dWaveDx = cos(fx1) * 0.5 * 0.045;
        float dWaveDz = -sin(fz1) * 0.4 * 0.045;

        #if WAVE_LAYERS >= 2
        float fx2 = tmpWorld.x * 1.3 - frameTimeCounter * 1.8;
        float fz2 = tmpWorld.z * 1.1 + frameTimeCounter * 1.5;
        wave += sin(fx2) * 0.02 + cos(fz2) * 0.02;
        dWaveDx += cos(fx2) * 1.3 * 0.02;
        dWaveDz += -sin(fz2) * 1.1 * 0.02;
        #endif

        #if WAVE_LAYERS >= 3
        float fx3 = tmpWorld.x * 2.6 + frameTimeCounter * 2.6;
        float fz3 = tmpWorld.z * 2.3 - frameTimeCounter * 2.1;
        wave += sin(fx3) * 0.008 + cos(fz3) * 0.008;
        dWaveDx += cos(fx3) * 2.6 * 0.008;
        dWaveDz += -sin(fz3) * 2.3 * 0.008;
        #endif

        #if WAVE_LAYERS >= 4
        float fx4 = tmpWorld.x * 4.8 - frameTimeCounter * 3.4;
        float fz4 = tmpWorld.z * 4.3 + frameTimeCounter * 3.0;
        wave += sin(fx4) * 0.003 + cos(fz4) * 0.003;
        dWaveDx += cos(fx4) * 4.8 * 0.003;
        dWaveDz += -sin(fz4) * 4.3 * 0.003;
        #endif

        #if WAVE_LAYERS >= 5
        float fx5 = tmpWorld.x * 8.5 + frameTimeCounter * 4.6;
        float fz5 = tmpWorld.z * 7.9 - frameTimeCounter * 4.1;
        wave += sin(fx5) * 0.0012 + cos(fz5) * 0.0012;
        dWaveDx += cos(fx5) * 8.5 * 0.0012;
        dWaveDz += -sin(fz5) * 7.9 * 0.0012;
        #endif

        #if WAVE_LAYERS >= 6
        float fx6 = tmpWorld.x * 14.0 - frameTimeCounter * 5.8;
        float fz6 = tmpWorld.z * 13.2 + frameTimeCounter * 5.3;
        wave += sin(fx6) * 0.0005 + cos(fz6) * 0.0005;
        dWaveDx += cos(fx6) * 14.0 * 0.0005;
        dWaveDz += -sin(fz6) * 13.2 * 0.0005;
        #endif

        #if WAVE_LAYERS >= 7
        float fx7 = tmpWorld.x * 23.0 + frameTimeCounter * 7.2;
        float fz7 = tmpWorld.z * 21.5 - frameTimeCounter * 6.6;
        wave += sin(fx7) * 0.0002 + cos(fz7) * 0.0002;
        dWaveDx += cos(fx7) * 23.0 * 0.0002;
        dWaveDz += -sin(fz7) * 21.5 * 0.0002;
        #endif

        vertex.y += wave;
        waveNormal = normalize(vec3(-dWaveDx, 1.0, -dWaveDz));
    }

    gl_Position = gl_ProjectionMatrix * gl_ModelViewMatrix * vertex;
    color = gl_Color;
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;

    vec4 viewPos = gl_ModelViewMatrix * vertex;
    viewDir = normalize(-viewPos.xyz);
}
