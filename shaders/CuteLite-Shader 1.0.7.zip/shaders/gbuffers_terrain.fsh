#version 120

/*
    Terreno: color + luz dinamica del objeto en mano + resplandor de lava.
*/

#define AO_STRENGTH 1.15 // [1.0 1.05 1.15 1.2 1.3]  Intensidad del sombreado por bloque
#define LAVA_GLOW // Tinte naranja calido cerca de luces muy intensas (como la lava)
#define LAVA_GLOW_STRENGTH 0.2 // [0.1 0.15 0.2 0.25 0.3]  Intensidad del resplandor de lava
#define WARM_LIGHTING // Luz de antorcha mas calida, luz de cielo un poco mas fria (mejora la iluminacion general)
#define FOLIAGE_BOOST // Hojas/pasto con un poco mas de vida (solo afecta tonos verdes, biomas)
#define FOLIAGE_BOOST_STRENGTH 0.25 // [0.1 0.15 0.2 0.25 0.3 0.4]

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform float heldBlockLightValue;
uniform float heldBlockLightValue2;

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying float viewDist;

void main() {
    vec4 tex = texture2D(texture, texcoord);
    if (tex.a < 0.1) discard;
    vec4 light = texture2D(lightmap, lmcoord);

    vec3 shade = (color.rgb - 0.5) * AO_STRENGTH + 0.5;

    #ifdef WARM_LIGHTING
    // Luz calida cerca de antorchas, fria en luz de cielo -- sutil, no cambia
    // el brillo, solo el tono, asi que no afecta legibilidad ni rendimiento
    vec3 warm = vec3(1.05, 0.99, 0.9);
    vec3 cool = vec3(0.94, 0.98, 1.04);
    vec3 lightTint = mix(cool, warm, lmcoord.x * 0.6 + 0.2);
    light.rgb *= lightTint;
    #endif

    vec3 litColor = tex.rgb * shade * light.rgb;

    #ifdef FOLIAGE_BOOST
    // Detecta tonos verdes (pasto/hojas, que llevan el tinte de bioma en el
    // color del vertice) y les da un poco mas de vida, sin tocar el resto
    float greenness = clamp(color.g - max(color.r, color.b), 0.0, 1.0) * 2.5;
    float litGray = dot(litColor, vec3(0.299, 0.587, 0.114));
    litColor = mix(litColor, mix(vec3(litGray), litColor, 1.0 + FOLIAGE_BOOST_STRENGTH), greenness);
    #endif

    #ifdef LAVA_GLOW
    // La lava emite luz al maximo nivel de bloque (15) -- umbral muy estricto
    // para que solo se note pegado a la lava de verdad, no en general.
    float lavaMask = smoothstep(0.99, 1.0, lmcoord.x);
    vec3 lavaTint = vec3(1.0, 0.45, 0.1);
    litColor = mix(litColor, litColor * lavaTint * 1.5, lavaMask * LAVA_GLOW_STRENGTH);
    #endif

    float heldLight = max(heldBlockLightValue, heldBlockLightValue2) / 15.0;
    float dynFalloff = clamp(1.0 - viewDist / 9.0, 0.0, 1.0);
    dynFalloff = dynFalloff * dynFalloff;
    vec3 dynGlow = vec3(1.0, 0.85, 0.6) * heldLight * dynFalloff * 0.6;

    gl_FragColor = vec4(litColor + dynGlow * tex.rgb, tex.a * color.a);
}
