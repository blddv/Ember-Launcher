#version 120

/*
    End: paleta etera/mistica. Violeta-turquesa, brillo suave en zonas claras
    (como el end stone y las estrellas del vacio), vineta oscura profunda tipo
    "vacio". Pulso lento y sutil para sensacion de lugar vivo/magico.
*/

uniform sampler2D colortex0;
uniform float frameTimeCounter;

varying vec2 texcoord;

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

    // Tinte violeta-magenta intenso, tipo "cielo cosmico"
    vec3 tintShadows = vec3(0.35, 0.2, 0.65);   // violeta profundo en zonas oscuras
    vec3 tintHighlights = vec3(0.9, 0.55, 1.0);  // magenta palido en zonas claras
    float lum = dot(color, vec3(0.299, 0.587, 0.114));
    vec3 tint = mix(tintShadows, tintHighlights, clamp(lum * 1.3, 0.0, 1.0));
    color = mix(color, color * tint * 1.8, 0.6);

    // Mas saturacion y contraste (sensacion mistica intensa)
    float gray = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(vec3(gray), color, 1.4);
    color = (color - 0.5) * 1.32 + 0.5;

    // Brillo extra en zonas claras (end stone, particulas), tipo nebulosa
    float glow = smoothstep(0.45, 1.0, lum);
    color += glow * vec3(0.7, 0.4, 0.9) * 0.5;

    // Particulas centelleantes tipo polvo magico (parpadeo aleatorio suave por pixel)
    float sparkle = fract(sin(dot(floor(texcoord * 400.0), vec2(12.9898, 78.233)) + frameTimeCounter * 0.5) * 43758.5453);
    sparkle = pow(sparkle, 40.0); // solo puntitos muy ocasionales
    color += sparkle * vec3(0.8, 0.7, 1.0) * 0.6;

    // Nebulosa/bruma violeta en el cielo, tipo la aurora comica de la imagen de referencia
    vec2 nebUV = texcoord * vec2(4.0, 2.0) + vec2(frameTimeCounter * 0.01, 0.0);
    float n = 0.0;
    float amp = 0.5;
    vec2 np = nebUV;
    for (int i = 0; i < 3; i++) {
        vec2 ip = floor(np);
        vec2 fp = fract(np);
        float a = fract(sin(dot(ip, vec2(127.1, 311.7))) * 43758.5453);
        float b = fract(sin(dot(ip + vec2(1.0, 0.0), vec2(127.1, 311.7))) * 43758.5453);
        float c = fract(sin(dot(ip + vec2(0.0, 1.0), vec2(127.1, 311.7))) * 43758.5453);
        float d = fract(sin(dot(ip + vec2(1.0, 1.0), vec2(127.1, 311.7))) * 43758.5453);
        vec2 u = fp * fp * (3.0 - 2.0 * fp);
        float val = mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
        n += val * amp;
        amp *= 0.5;
        np *= 2.0;
    }
    vec3 nebColor = mix(vec3(0.55, 0.15, 0.75), vec3(0.85, 0.45, 0.95), n);
    color += nebColor * pow(n, 2.0) * 0.22;

    // Pulso lento, energia magica respirando, mas notorio
    float pulse = 0.5 + 0.5 * sin(frameTimeCounter * 0.35);
    color += vec3(0.35, 0.18, 0.45) * 0.05 * pulse;

    // Vineta tipo "vacio infinito", mas suave que antes (menos sensacion de neblina)
    vec2 uv = texcoord - 0.5;
    float vig = 1.0 - dot(uv, uv) * 0.4;
    color *= vig;

    // Aclara las sombras (el End se estaba viendo casi negro), de forma
    // segura y acotada
    color = pow(clamp(color, 0.0, 1.0), vec3(0.7));

    gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
