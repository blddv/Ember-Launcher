#version 120

/*
    CuteLite Shader v14.0 - Mas optimizado + gradado cinematografico
    Shader liviano pensado para PCs viejas (ej. i5 4ta gen sin GPU dedicada).
    Se combinaron calculos que antes estaban separados (menos evaluaciones
    por pixel), y se agrego un gradado de color tipo cine (sombras frias,
    luces calidas) que no cuesta nada extra porque reutiliza datos ya
    calculados.
*/

#define ENABLE_RAYS
#define RAY_SAMPLES 8 // [6 8 10 12 16 20 24]  Calidad de los rayos: menos = mas FPS
#define RAY_INTENSITY 0.5 // [0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define SATURATION 1.0 // [1.0 1.1 1.2 1.3 1.4]
#define CONTRAST 1.05 // [1.0 1.03 1.05 1.09 1.12]
#define VIGNETTE_STRENGTH 0.45 // [0.0 0.2 0.35 0.45 0.55 0.7]
#define ENABLE_SKY_COLORS

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjection;
uniform vec3 sunPosition;
uniform int isEyeInWater;
uniform float frameTimeCounter;
uniform int worldTime;
uniform vec3 fogColor;

varying vec2 texcoord;

const vec3 LUM_WEIGHTS = vec3(0.299, 0.587, 0.114);

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;
    float depth = texture2D(depthtex0, texcoord).r;
    bool isSky = depth > 0.9999;
    vec3 rayGlow = vec3(0.0);

    float t = float(worldTime);
    float dawn = max(smoothstep(22500.0, 23500.0, t), smoothstep(1500.0, 500.0, t));

    // --- Rayos de luz (god rays), SOLO sobre geometria ---
    #ifdef ENABLE_RAYS
    if (!isSky) {
        vec3 sunDir = normalize(sunPosition);
        if (sunDir.z < 0.0) {
            vec4 sunClip = gbufferProjection * vec4(sunDir * 100.0, 1.0);
            if (sunClip.w > 0.05) {
                vec2 sunScreen = (sunClip.xy / sunClip.w) * 0.5 + 0.5;
                float distToSun = distance(texcoord, sunScreen);

                if (distToSun < 1.0) {
                    const int SAMPLES = RAY_SAMPLES;
                    vec2 step = (sunScreen - texcoord) / float(SAMPLES) * 0.85;

                    float dither = fract(sin(dot(texcoord, vec2(12.9898, 78.233))) * 43758.5453);
                    vec2 samplePos = texcoord + step * dither;

                    float decay = 1.0;
                    float rays = 0.0;

                    for (int i = 0; i < SAMPLES; i++) {
                        samplePos += step;
                        vec2 clamped = clamp(samplePos, 0.0, 1.0);
                        float d = texture2D(depthtex0, clamped).r;
                        rays += (d > 0.9999 ? 1.0 : 0.0) * decay;
                        decay *= 0.9;
                    }
                    rays /= float(SAMPLES);
                    rays = pow(rays, 0.65);

                    vec3 coreColor = vec3(1.0, 0.72, 0.32);
                    vec3 edgeColor = vec3(1.0, 0.96, 0.88);
                    float tt = clamp(1.0 - distToSun * 1.1, 0.0, 1.0);
                    vec3 rayColor = mix(edgeColor, coreColor, tt);

                    float fade = clamp(1.0 - distToSun * 1.6, 0.0, 1.0);
                    rayGlow = rays * fade * rayColor * RAY_INTENSITY;
                }
            }
        }
    }
    #endif

    // --- Colores del cielo por hora del dia ---
    #ifdef ENABLE_SKY_COLORS
    if (isSky) {
        float dusk = smoothstep(11000.0, 12200.0, t) * (1.0 - smoothstep(12800.0, 14000.0, t));
        float night = smoothstep(13500.0, 15000.0, t) * (1.0 - smoothstep(21500.0, 23000.0, t));

        float distFromHorizon = abs(texcoord.y - 0.55);
        float horizonMask = 1.0 - smoothstep(0.0, 0.35, distFromHorizon);
        float upperMask = smoothstep(0.1, 0.45, distFromHorizon) * (1.0 - smoothstep(0.45, 0.75, distFromHorizon));

        vec3 sunriseHorizon = vec3(1.0, 0.65, 0.38);
        vec3 sunriseUpper = vec3(0.95, 0.58, 0.72);
        vec3 sunsetHorizon = vec3(1.0, 0.42, 0.28);
        vec3 sunsetUpper = vec3(0.78, 0.32, 0.62);

        color = mix(color, color * sunriseHorizon * 1.4, dawn * horizonMask * 0.58);
        color = mix(color, color * sunriseUpper * 1.22, dawn * upperMask * 0.38);
        color = mix(color, color * sunsetHorizon * 1.4, dusk * horizonMask * 0.58);
        color = mix(color, color * sunsetUpper * 1.22, dusk * upperMask * 0.38);

        // Noche con ambiente: tinte azul-violeta MAS un pequeno aporte de luz
        // ambiental, para que no quede todo negro
        vec3 nightTint = vec3(0.5, 0.58, 1.0);
        color = mix(color, color * nightTint * 1.5 + vec3(0.015, 0.02, 0.035), night * 0.4);
    }
    #endif

    // Deteccion del Nether via color de niebla (sin carpetas de dimension)
    float isNether = step(0.12, fogColor.r) * step(fogColor.g * 2.2, fogColor.r) * step(fogColor.b * 2.2, fogColor.r);

    color.r *= mix(1.04, 1.18, isNether);
    color.g *= mix(1.01, 0.9, isNether);
    color.b *= mix(0.96, 0.65, isNether);

    float lum = dot(color, LUM_WEIGHTS);

    // Cuevas mas claras + perspectiva aerea en la distancia, combinados en un
    // solo bloque (antes eran dos "if" separados, ahora uno solo)
    if (!isSky) {
        float caveLift = smoothstep(0.2, 0.0, lum) * 0.045;
        color += vec3(caveLift * 1.05, caveLift, caveLift * 0.95);

        float farFactor = smoothstep(0.996, 0.9999, depth);
        vec3 hazeColor = vec3(0.68, 0.75, 0.88);
        color = mix(color, hazeColor, farFactor * 0.45);
    }

    // Gradado cinematografico barato: sombras un poco azul-verdosas, luces un
    // poco calidas -- da mas profundidad visual sin costo extra (reutiliza "lum")
    vec3 tealShadow = vec3(0.96, 1.0, 1.03);
    vec3 orangeHighlight = vec3(1.03, 1.0, 0.95);
    color *= mix(tealShadow, orangeHighlight, smoothstep(0.15, 0.75, lum));

    float highlightTame = mix(1.0, 0.78, smoothstep(0.5, 1.05, lum));
    color *= highlightTame;

    color = mix(vec3(lum * highlightTame), color, mix(SATURATION, SATURATION * 1.15, isNether));
    color = (color - 0.5) * CONTRAST + 0.5;
    color = pow(clamp(color, 0.0, 1.0), vec3(0.945));

    vec2 uv = texcoord - 0.5;
    float vig = 1.0 - dot(uv, uv) * VIGNETTE_STRENGTH;
    color *= vig;

    color += rayGlow;

    if (!isSky && dawn > 0.001) {
        vec3 dawnFogColor = vec3(0.95, 0.8, 0.7);
        color = mix(color, dawnFogColor, dawn * 0.18);
    }

    if (isEyeInWater == 1) {
        color = mix(color, color * vec3(0.35, 0.6, 0.9), 0.55);
        color *= 0.85;
        float vigWater = 1.0 - dot(uv, uv) * 0.7;
        color *= vigWater;
        float causticPulse = 0.5 + 0.5 * sin(frameTimeCounter * 0.8 + texcoord.y * 8.0);
        color += vec3(0.05, 0.09, 0.12) * causticPulse * 0.15;
    }

    gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
