#version 120

const int shadowMapResolution = 256;    // resolucion minima, no se usa visualmente
const float shadowDistance = 16.0;      // distancia minima, no se usa visualmente
const float shadowDistanceRenderMul = 1.0;
const float entityShadowDistanceMul = 0.0; // entidades (mobs/jugador) no proyectan sombra

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 glcolor;

void main() {
    vec4 color = texture2D(texture, texcoord) * glcolor;
    if (color.a < 0.1) discard;
    gl_FragColor = color;
}
