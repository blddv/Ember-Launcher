#version 120

/*
    Sombra con direccion FIJA (no sigue al sol real, no rota con el tiempo).
*/

varying vec2 texcoord;
varying vec4 glcolor;

uniform mat4 shadowModelViewInverse;

const vec3 fixedSunDir = vec3(0.4, 0.85, 0.35);
const float shadowDist = 70.0;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor = gl_Color;

    vec3 sunDir = normalize(fixedSunDir);
    vec4 shadowViewPos = gl_ModelViewMatrix * gl_Vertex;
    vec4 worldPos = shadowModelViewInverse * shadowViewPos;

    vec3 up = abs(sunDir.y) > 0.99 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
    vec3 right = normalize(cross(sunDir, up));
    vec3 realUp = cross(right, sunDir);

    vec3 rel = worldPos.xyz;
    float lx = dot(rel, right) / shadowDist;
    float ly = dot(rel, realUp) / shadowDist;
    float lz = -dot(rel, sunDir) / shadowDist;

    gl_Position = vec4(lx, ly, lz, 1.0);
}
