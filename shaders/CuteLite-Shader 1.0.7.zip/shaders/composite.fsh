#version 120

/*
    Pase composite: se ejecuta despues de dibujar todo el terreno + agua.
    Compara la profundidad CON agua (depthtex0) contra la profundidad SIN
    agua/translucidos (depthtex1) para saber que tan "gruesa" es la columna
    de agua en cada pixel, y oscurece/tinta el agua mas en las partes hondas,
    como el agua de verdad.
*/

#define DEPTH_WATER_COLOR // Color del agua segun profundidad (celeste poco profunda, azul oscuro honda)

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform float near;
uniform float far;
uniform int worldTime;

varying vec2 texcoord;

float linearizeDepth(float d) {
    return (2.0 * near) / (far + near - d * (far - near));
}

void main() {
    vec3 color = texture2D(colortex0, texcoord).rgb;

    #ifdef DEPTH_WATER_COLOR
    // Estas muestras de profundidad solo se piden si la funcion esta
    // activada -- antes se leian siempre, aunque no se usaran.
    float d0 = texture2D(depthtex0, texcoord).r; // con agua
    float d1 = texture2D(depthtex1, texcoord).r; // sin agua (terreno de abajo)
    bool isWater = d0 < d1 - 0.0000005; // hay agua en este pixel

    if (isWater) {
        float lin0 = linearizeDepth(d0);
        float lin1 = linearizeDepth(d1);
        float waterThickness = clamp(lin1 - lin0, 0.0, 40.0);
        // Curva mas suave (raiz cuadrada) en vez de lineal, transicion mas natural
        float depthFactor = sqrt(clamp(waterThickness / 14.0, 0.0, 1.0));

        // De noche el agua se ve mas oscura/fria, de dia mas viva
        float t = float(worldTime);
        float night = smoothstep(13500.0, 15000.0, t) * (1.0 - smoothstep(21500.0, 23000.0, t));

        vec3 shallowColor = mix(vec3(0.5, 0.82, 0.85), vec3(0.25, 0.4, 0.55), night);
        vec3 deepColor = mix(vec3(0.04, 0.14, 0.3), vec3(0.01, 0.04, 0.12), night);
        vec3 depthTint = mix(shallowColor, deepColor, depthFactor);

        color = mix(color, color * depthTint * 1.6, 0.45 + depthFactor * 0.35);
    }
    #endif

    gl_FragColor = vec4(color, 1.0);
}
