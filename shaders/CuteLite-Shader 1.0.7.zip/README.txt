CuteLite Shader
================

Shader hecho a medida, pensado para PCs con hardware limitado (ej. i5 de 4ta
generacion sin tarjeta grafica dedicada, o con una GPU integrada).

No modifica sombras, iluminacion volumetrica ni reflejos de agua: solo aplica
un retoque de color al final del renderizado (tonos calidos, mas saturacion
y una vineta suave). Por eso el costo de FPS es minimo, casi como jugar sin
shaders.

INSTALACION
-----------
1. Instala Iris (recomendado) u OptiFine en tu Minecraft Java Edition.
2. Copia la carpeta "shaders" (o comprime este contenido en un .zip) dentro
   de la carpeta de shaderpacks del juego:
   Opciones -> Video Settings -> Shader Packs -> "Open Shader Packs Folder"
3. Selecciona "CuteLite Shader" en la lista y aplicalo.

RECOMENDACIONES PARA TU PC
---------------------------
- Distancia de renderizado: 8-10 chunks.
- Suavizado (Smooth Lighting): minimo o desactivado.
- Motion Blur: desactivado.
- Graficos: Rapido (Fast), no Bonito (Fancy).

Si aun asi notas lag, puedes bajar el "screen.columns" en shaders.properties
o pedir que te ajuste el color grading a tu gusto.
