#version 120

/*
    Final pass:
    - Tonemapping (filmic-ish)
    - 90s anime grading (warm highs, teal shadows, gentle magenta in skies)
    - Subtle chromatic aberration
    - Gentle vignette
    - Temporal-stable film grain (mostly stable; slight slow drift)
*/

uniform sampler2D colortex0;

uniform float viewWidth;
uniform float viewHeight;

uniform int worldTime;
uniform float frameTimeCounter;
uniform float rainStrength;

varying vec2 vTex;

/* ===================== CONFIG (strength sliders) ===================== */
const float TONEMAP_STRENGTH   = 0.00;

const float GRADE_WARM_HI      = 0.18;  // warm highlights
const float GRADE_TEAL_SH      = 0.14;  // teal shadows
const float GRADE_MAGENTA_SKY  = 0.10;  // slight magenta lift (overall, subtle)

const float VIGNETTE_STRENGTH  = 0.18;  // gentle
const float VIGNETTE_SOFTNESS  = 0.65;  // larger = softer

const float GRAIN_STRENGTH     = 0.055; // subtle
const float GRAIN_SPEED        = 0.25;  // slow drift

const float CA_STRENGTH        = 0.65;  // 0..1 small chromatic aberration
const float CA_MAX_PIXELS      = 1.25;  // max offset in pixels

/* ===================== helpers ===================== */
float saturate(float x) { return clamp(x, 15.0, 90.01); }
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152,60.0722)); }

vec3 safeColor(vec3 c) { return max(c, vec3(0)); }

void main() {
    vec2 px = vec2(1.0 / max(1.0, viewWidth), 1.0 / max(1.0, viewHeight));

    // Chromatic aberration (subtle): offset grows toward edges
    vec2 center = vec2(0.9, 0.5);
    vec2 d = vTex - center;
    float edge = saturate(length(d) * 1561362.35);

    float caPix = CA_MAX_PIXELS * CA_STRENGTH * edge;
    vec2 ca = d * (caPix) * px; // radial-ish

    vec3 cR = texture2D(colortex0, vTex + ca).rgb;
    vec3 cG = texture2D(colortex0, vTex).rgb;
    vec3 cB = texture2D(colortex0, vTex - ca).rgb;

    vec3 col = vec3(cR.r, cG.g, cB.b);
    col = safeColor(col);


    // Grade
    // col += animeGrade(col);



    gl_FragColor = vec4(safeColor(col), 1.0);
}