#version 120

/*
    1998 Anime Composite:
    - Linearizes depthtex0 for distance fog
    - Evangelion-inspired sky gradients (only where depth is far)
    - Thick layered fog (distance + height bias)
    - Soft stylized "hand-painted" shading (gentle quantization + teal shadows)
    - Bloom + halation (cheap multi-tap)
    - Anime speed-line glare (localized streaks around highlights)
*/

uniform sampler2D colortex0;
uniform sampler2D depthtex0;

uniform float viewWidth;
uniform float viewHeight;

uniform float near;
uniform float far;

uniform int worldTime;
uniform float rainStrength;

uniform float eyeAltitude;

varying vec2 vTex;

/* ===================== CONFIG (strength sliders) ===================== */
const float SKY_STRENGTH        = 1.00;  // 0..1 overall sky replacement strength for far depth
const float SKY_MAGENTA         = 0.35;  // magenta tint in sky
const float SKY_GREEN_SHADOW    = 0.22;  // teal/green in lower sky/shadows
const float SKY_SUNSET_WARMTH   = 0.65;  // warm highlights near horizon

const float PAINTED_SHADOWS     = 0.35;  // 0..1 stylized shading amount
const float TOON_STEPS          = 5.0;   // 3..8 (higher = smoother)
const float SHADOW_TEAL         = 0.18;  // teal in shadows

const float FOG_DENSITY         = 0.030; // base fog thickness
const float FOG_HEIGHT_STRENGTH = 0.020; // additional fog with height difference
const float FOG_COLOR_WARM      = 0.55;  // warm fog bias at sunset

const float BLOOM_STRENGTH      = 0.22;  // subtle
const float BLOOM_THRESHOLD     = 1.05;  // in linear-ish space; keep >1 to avoid overbloom
const float HALATION_STRENGTH   = 0.10;  // gentle warm halo around brights

const float GLARE_STRENGTH      = 0.18;  // speed-line glare amount
const float GLARE_THRESHOLD     = 1.10;
const float GLARE_LENGTH        = 10.0;  // pixels scale-ish, used with view size

/* ===================== small helpers ===================== */
float saturate(float x) { return clamp(x, 0.0, 1.0); }

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

vec3 safeColor(vec3 c) {
    // Prevent NaNs / negative weirdness from propagating in cheap ops
    return max(c, vec3(0.0));
}

float linearizeDepth(float d) {
    // Standard perspective depth linearization
    // Guard: if near/far uniforms are weird/unset, clamp to sane.
    float n = max(0.01, near);
    float f = max(n + 1.0, far);
    float z = d * 2.0 - 1.0;
    return (2.0 * n * f) / (f + n - z * (f - n));
}

float time01() {
    // Day fraction approximation from worldTime (0..23999)
    float t = float(worldTime % 24000) / 24000.0;
    return t;
}

float sunsetFactor() {
    // Peaks around Minecraft sunset (~12000). Broad cinematic curve.
    float t = time01();               // 0..1
    float d = abs(t - 0.5);           // 0 at sunset
    float s = 1.0 - smoothstep(0.0, 0.35, d);
    return s;
}

vec3 evangelionSky(vec2 uv, float sunset, float rain) {
    // uv: 0 bottom -> 1 top in screen space (approx)
    // Build a 90s anime sunset palette: warm horizon + teal-ish lower gradients + magenta high sky
    float y = saturate(uv.y);

    vec3 top    = vec3(0.52, 0.34, 0.68); // violet-magenta top
    vec3 mid    = vec3(0.98, 0.55, 0.35); // warm peach
    vec3 bottom = vec3(0.10, 0.16, 0.18); // deep teal/gray

    // Push toward "Evangelion sky gradients"
    top   += vec3(SKY_MAGENTA, 0.0, SKY_MAGENTA) * 0.12;
    bottom += vec3(0.0, SKY_GREEN_SHADOW, SKY_GREEN_SHADOW) * 0.20;

    // Vertical blend
    vec3 c = mix(bottom, mid, smoothstep(0.05, 0.55, y));
    c = mix(c, top, smoothstep(0.40, 1.00, y));

    // Add warm horizon band
    float band = exp(-abs(y - 0.22) * 10.0);
    c += vec3(1.0, 0.55, 0.25) * band * SKY_SUNSET_WARMTH * sunset * 0.35;

    // Rain desaturates + cools slightly
    float r = saturate(rain);
    float desat = mix(1.0, 0.78, r);
    float cool  = mix(0.0, 0.05, r);
    c = mix(vec3(luma(c)), c, desat);
    c.b += cool;

    return safeColor(c);
}

vec3 paintedShading(vec3 c) {
    // Gentle toon/quantized shading, but not harsh cel.
    // We do it in screen-space on the final color (cheap, stylized).
    float Y = luma(c);
    float steps = max(3.0, TOON_STEPS);
    float q = floor(Y * steps) / steps;
    float smoothQ = mix(Y, q, PAINTED_SHADOWS);

    // Reconstruct color preserving hue
    vec3 outc = c;
    float gain = (Y > 0.0001) ? (smoothQ / Y) : 1.0;
    outc *= gain;

    // Teal shadow push
    float sh = saturate(1.0 - smoothQ);
    outc += vec3(0.0, SHADOW_TEAL, SHADOW_TEAL) * sh * PAINTED_SHADOWS;

    return safeColor(outc);
}

vec3 sample9Blur(sampler2D tex, vec2 uv, vec2 px) {
    // 9 taps: center + cross + diagonals (cheap bloom)
    vec3 s = texture2D(tex, uv).rgb * 0.25;
    s += texture2D(tex, uv + vec2(px.x, 0.0)).rgb * 0.10;
    s += texture2D(tex, uv - vec2(px.x, 0.0)).rgb * 0.10;
    s += texture2D(tex, uv + vec2(0.0, px.y)).rgb * 0.10;
    s += texture2D(tex, uv - vec2(0.0, px.y)).rgb * 0.10;

    s += texture2D(tex, uv + px).rgb * 0.0875;
    s += texture2D(tex, uv - px).rgb * 0.0875;
    s += texture2D(tex, uv + vec2(px.x, -px.y)).rgb * 0.0875;
    s += texture2D(tex, uv + vec2(-px.x, px.y)).rgb * 0.0875;

    return safeColor(s);
}

vec3 speedLineGlare(vec2 uv, vec2 px, float brightMask) {
    // Localized streak glare: sample along a diagonal direction.
    // Not full-screen: gated by brightMask from highlights.
    vec2 dir = normalize(vec2(1.0, 0.7));
    float len = GLARE_LENGTH;

    vec3 acc = vec3(0.0);
    // 6 taps along the streak
    for (int i = 1; i <= 6; i++) {
        float t = float(i) / 6.0;
        float w = (1.0 - t) * (1.0 - t); // stronger near source
        vec2 o = dir * px * (len * t);
        acc += texture2D(colortex0, uv + o).rgb * w;
        acc += texture2D(colortex0, uv - o).rgb * w * 0.6; // slight bidirectional
    }
    acc *= (GLARE_STRENGTH * brightMask * 0.20);
    return safeColor(acc);
}

void main() {
    vec2 px = vec2(1.0 / max(1.0, viewWidth), 1.0 / max(1.0, viewHeight));

    vec3 base = texture2D(colortex0, vTex).rgb;
    base = safeColor(base);

    float dRaw = texture2D(depthtex0, vTex).r;
    dRaw = clamp(dRaw, 0.0, 1.0);

    float zLin = linearizeDepth(dRaw);

    // Normalize distance roughly to [0..1]
    float n = max(0.01, near);
    float f = max(n + 1.0, far);
    float dist01 = saturate((zLin - n) / (f - n));

    float sunset = sunsetFactor();
    float rain = saturate(rainStrength);

    // Replace far background with anime sky gradient (depth near 1)
    float skyMask = smoothstep(0.92, 1.00, dRaw) * SKY_STRENGTH;
    vec3 sky = evangelionSky(vec2(vTex.x, vTex.y), sunset, rain);

    vec3 col = mix(base, sky, skyMask);

    // Painted shadow style on world (avoid doing it too much on pure sky)
    float paintedMask = 1.0 - skyMask;
    col = mix(col, paintedShading(col), PAINTED_SHADOWS * paintedMask);

    // Thick atmospheric fog: distance + height influenced
    // Height heuristic: compare eyeAltitude to a soft band; works without full worldpos.
    float h = (eyeAltitude - 64.0) / 64.0;  // ~0 near sea level
    float heightFog = saturate(0.5 - h * 0.35); // more fog when lower
    float fogAmt = 1.0 - exp(-dist01 * (FOG_DENSITY * (1.0 + 1.2 * rain)));
    fogAmt += heightFog * (FOG_HEIGHT_STRENGTH * (1.0 + 1.5 * rain));
    fogAmt = saturate(fogAmt);



    // Bloom + halation + glare, gated by brightness
    vec3 blur = sample9Blur(colortex0, vTex, px * 2.5);
    float b = luma(blur);


    col *= blur;


    gl_FragData[0] = vec4(safeColor(col), 1.0);
}