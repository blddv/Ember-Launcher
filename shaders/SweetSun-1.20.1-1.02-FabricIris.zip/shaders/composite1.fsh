#version 120

#include "/lib/settings.glsl"

uniform sampler2D colortex0;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;

vec3 extractBright(vec3 c) {
    float luma = dot(c, vec3(0.2126, 0.7152, 0.0722));
    float knee = smoothstep(0.75, 2.2, luma);
    return c * knee;
}

/* DRAWBUFFERS:3 */
void main() {
    #ifndef BLOOM_ENABLED
    gl_FragData[0] = vec4(0.0);
    return;
    #else

    vec2 texel = 1.0 / vec2(max(viewWidth, 1.0), max(viewHeight, 1.0));
    vec3 bloom = vec3(0.0);
    float weightSum = 0.0;

    // 25-tap wide multi-scale Gaussian-weighted bloom kernel
    for (int x = -2; x <= 2; x++) {
        for (int y = -2; y <= 2; y++) {
            vec2 offset = vec2(float(x), float(y)) * texel * 3.5;
            float w = exp(-float(x * x + y * y) * 0.35);
            vec3 s1 = extractBright(texture2D(colortex0, clamp(texcoord + offset, 0.001, 0.999)).rgb);
            vec3 s2 = extractBright(texture2D(colortex0, clamp(texcoord + offset * 2.8, 0.001, 0.999)).rgb);
            bloom += (s1 * 0.65 + s2 * 0.35) * w;
            weightSum += w;
        }
    }

    bloom /= max(weightSum, 0.001);
    gl_FragData[0] = vec4(bloom * 0.22 * BLOOM_STRENGTH, 1.0);
    #endif
}
