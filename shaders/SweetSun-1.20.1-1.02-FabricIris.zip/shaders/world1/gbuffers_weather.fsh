#version 120
#define DIMENSION_END

uniform sampler2D texture;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;

/* DRAWBUFFERS:0 */
void main() {
    vec4 tex = texture2D(texture, texcoord) * color;
    if (tex.a < 0.05) discard;
    gl_FragData[0] = vec4(tex.rgb * 0.85, tex.a * 0.55);
}
