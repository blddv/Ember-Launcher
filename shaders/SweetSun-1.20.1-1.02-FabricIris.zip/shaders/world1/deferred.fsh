#version 120
#define DIMENSION_END

#include "/lib/settings.glsl"
#include "/lib/sky.glsl"

/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA16;
const int colortex2Format = RGBA16;
const int colortex3Format = RGBA16F;
*/

const int shadowMapResolution = SHADOW_RES;
const float shadowDistance = SHADOW_DIST;
const float sunPathRotation = SUN_PATH_ROTATION;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D depthtex0;
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 shadowLightPosition;
uniform vec3 upPosition;
uniform vec3 cameraPosition;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform float rainStrength;
uniform float wetness;
uniform float nightVision;
uniform float frameTimeCounter;

varying vec2 texcoord;

// Interleaved gradient noise for jittering soft shadow samples
float interleavedGradientNoise(vec2 pixelPos) {
    vec3 magic = vec3(0.06711056, 0.00583715, 52.9829189);
    return fract(magic.z * fract(dot(pixelPos, magic.xy)));
}

vec3 computeSoftShadows(vec3 playerPos, vec3 worldNormal, float NdotL, float isFoliage) {
    float distSq = dot(playerPos, playerPos);
    float maxDistSq = SHADOW_DIST * SHADOW_DIST;
    if (distSq >= maxDistSq) {
        return vec3(1.0);
    }

    float edgeFade = 1.0 - smoothstep(maxDistSq * 0.72, maxDistSq, distSq);

    // Normal offset bias to eliminate shadow acne
    float slopeBias = clamp(1.0 - max(NdotL, 0.0), 0.0, 1.0);
    float normalBias = (isFoliage > 0.5) ? 0.035 : (0.045 + 0.075 * slopeBias);
    vec3 biasedPos = playerPos + worldNormal * normalBias;

    vec4 shadowView = shadowModelView * vec4(biasedPos, 1.0);
    vec4 shadowClip = shadowProjection * shadowView;
    shadowClip.xyz = distortShadowClipPos(shadowClip.xyz);

    vec3 shadowNDC = shadowClip.xyz / shadowClip.w;
    vec3 shadowScreen = shadowNDC * 0.5 + 0.5;

    if (shadowScreen.x <= 0.002 || shadowScreen.x >= 0.998 ||
        shadowScreen.y <= 0.002 || shadowScreen.y >= 0.998 ||
        shadowScreen.z <= 0.0 || shadowScreen.z >= 1.0) {
        return vec3(1.0);
    }

    float depthBias = 0.00038 + 0.00035 * slopeBias;
    float currentDepth = shadowScreen.z - depthBias;

    #ifndef SOFT_SHADOWS
    float opaqueDepth = texture2D(shadowtex1, shadowScreen.xy).r;
    if (currentDepth > opaqueDepth) {
        return mix(vec3(1.0), vec3(0.0), edgeFade);
    }
    #ifdef COLORED_SHADOWS
    float transDepth = texture2D(shadowtex0, shadowScreen.xy).r;
    if (currentDepth > transDepth) {
        vec4 sc = texture2D(shadowcolor0, shadowScreen.xy);
        vec3 stainedCol = mix(vec3(1.0), sc.rgb * 1.25, sc.a);
        return mix(vec3(1.0), stainedCol, edgeFade);
    }
    #endif
    return vec3(1.0);
    #else

    // Vogel disk PCF soft shadows with per-pixel rotation
    float radius = (1.65 * SHADOW_SOFTNESS) / float(SHADOW_RES);
    float angle = interleavedGradientNoise(gl_FragCoord.xy) * 6.2831853;
    float s = sin(angle);
    float c = cos(angle);
    mat2 rot = mat2(c, -s, s, c);

    vec3 shadowAccum = vec3(0.0);
    const int SAMPLES = SHADOW_FILTER_SAMPLES;
    float invSamples = 1.0 / float(SAMPLES);

    for (int i = 0; i < SAMPLES; i++) {
        float fi = float(i) + 0.5;
        float r = sqrt(fi * invSamples);
        float theta = fi * 2.3999632; // Golden angle
        vec2 offset = rot * (vec2(cos(theta), sin(theta)) * r * radius);
        vec2 sampleUV = shadowScreen.xy + offset;

        float opDepth = texture2D(shadowtex1, sampleUV).r;
        if (currentDepth > opDepth) {
            shadowAccum += vec3(0.0);
        } else {
            #ifdef COLORED_SHADOWS
            float trDepth = texture2D(shadowtex0, sampleUV).r;
            if (currentDepth > trDepth) {
                vec4 sc = texture2D(shadowcolor0, sampleUV);
                shadowAccum += mix(vec3(1.0), sc.rgb * 1.25, sc.a);
            } else {
                shadowAccum += vec3(1.0);
            }
            #else
            shadowAccum += vec3(1.0);
            #endif
        }
    }

    vec3 finalShadow = shadowAccum * invSamples;
    return mix(vec3(1.0), finalShadow, edgeFade);
    #endif
}

/* DRAWBUFFERS:03 */
void main() {
    vec4 albedoData = texture2D(colortex0, texcoord);
    vec4 normalData = texture2D(colortex1, texcoord);
    vec4 lightData = texture2D(colortex2, texcoord);
    float depth = texture2D(depthtex0, texcoord).r;

    vec2 lm = lightData.rg;
    float matId = lightData.b;
    float ao = clamp(lightData.a, 0.25, 1.0);

    // Reconstruct view-space position
    vec4 clipPos = vec4(texcoord * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 viewPosH = gbufferProjectionInverse * clipPos;
    vec3 viewPos = viewPosH.xyz / viewPosH.w;
    vec3 viewDir = normalize(viewPos);
    vec3 worldDir = normalize((gbufferModelViewInverse * vec4(viewDir, 0.0)).xyz);

    bool inEnd = isEndDimensionFallback(skyColor, fogColor);

    // Sky & Celestial bodies (Sun, Moon, Stars, or The End Cosmic Void)
    if (depth >= 0.999999 || matId < 0.08) {
        if (inEnd) {
            vec3 endSky = computeEndSky(worldDir, frameTimeCounter);
            gl_FragData[0] = vec4(endSky, 1.0);
            gl_FragData[1] = vec4(endSky, 1.0);
            return;
        }
        #ifdef DIMENSION_NETHER
        vec3 netherSky = pow(max(fogColor, vec3(0.02)), vec3(2.2)) * 0.65;
        gl_FragData[0] = vec4(netherSky, 1.0);
        gl_FragData[1] = vec4(netherSky, 1.0);
        return;
        #else
        vec3 atmoSky = computeAtmosphericSky(viewDir, sunPosition, moonPosition, upPosition, rainStrength, skyColor);
        // Blend sun/moon/stars texture from gbuffers_skytextured / gbuffers_skybasic
        if (abs(matId - 0.05) < 0.02) {
            atmoSky += albedoData.rgb * (1.0 - rainStrength * 0.85);
        }
        gl_FragData[0] = vec4(atmoSky, 1.0);
        gl_FragData[1] = vec4(atmoSky, 1.0);
        return;
        #endif
    }

    // Convert albedo to linear space for physically plausible lighting
    vec3 albedo = pow(max(albedoData.rgb, vec3(0.0)), vec3(2.2));
    vec3 viewNormal = normalize(normalData.rgb * 2.0 - 1.0);

    // Player-centered world position and world normal
    vec3 playerPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
    vec3 worldNormal = normalize((gbufferModelViewInverse * vec4(viewNormal, 0.0)).xyz);

    TimeState ts = computeTimeState(sunPosition, upPosition);
    vec3 lightDirView = normalize(shadowLightPosition);
    vec3 upDirView = normalize(upPosition);

    float NdotL = dot(viewNormal, lightDirView);
    float NdotUp = dot(viewNormal, upDirView) * 0.5 + 0.5;

    float isFoliage = (abs(matId - 0.20) < 0.04) ? 1.0 : 0.0;
    float isEmissive = (abs(matId - 0.30) < 0.04) ? 1.0 : 0.0;
    float isCloud = (abs(matId - 0.80) < 0.04) ? 1.0 : 0.0;

    // 2. Warm Block / Torch Light (modulated by lightmap block channel lm.x)
    float torchFalloff = pow(clamp(lm.x, 0.0, 1.0), 2.35) + pow(clamp(lm.x, 0.0, 1.0), 5.5) * 1.45;
    float flicker = 1.0 + sin(frameTimeCounter * 6.5 + playerPos.x * 2.0 + playerPos.z * 2.0) * 0.025;
    vec3 torchColor = (inEnd ? vec3(1.35, 0.65, 1.65) : vec3(1.55, 0.78, 0.28)) * TORCH_WARMTH;
    vec3 blockLight = torchColor * torchFalloff * flicker;

    // =========================================================================
    // THE END DIMENSION LIGHTING (Magical Violet-Black + Sky Flash Pulses)
    // =========================================================================
    if (inEnd) {
        float flashPulse = getEndAmbientFlashPulse(frameTimeCounter);
        vec3 endZenithAmb = vec3(0.24, 0.11, 0.38) + vec3(0.55, 0.16, 0.85) * flashPulse * 0.75;
        vec3 endNadirAmb = vec3(0.06, 0.025, 0.11);
        vec3 endAmbient = mix(endNadirAmb, endZenithAmb, NdotUp) + vec3(nightVision * 0.35);

        // Soft directional cosmic light from upper End nebula
        vec3 cosmicLightDir = normalize(vec3(0.35, 0.88, -0.30));
        float cosmicDiff = max(dot(worldNormal, cosmicLightDir) * 0.6 + 0.4, 0.0);
        vec3 cosmicDirect = (vec3(0.32, 0.15, 0.50) + vec3(0.95, 0.30, 1.40) * flashPulse) * cosmicDiff;

        // Rim / specular highlight from purple flashes
        vec3 halfEnd = normalize(upDirView - viewDir);
        float endSpec = pow(max(dot(viewNormal, halfEnd), 0.0), 28.0) * (0.10 + 0.35 * flashPulse);
        vec3 endSpecCol = vec3(1.25, 0.45, 1.85) * endSpec;

        vec3 endLit = albedo * ((endAmbient + cosmicDirect) * ao + blockLight) + endSpecCol;

        #ifdef EMISSIVE_GLOW
        if (isEmissive > 0.5) {
            endLit = max(endLit, albedo * 3.4);
        }
        #endif

        gl_FragData[0] = vec4(max(endLit, vec3(0.0)), 1.0);
        gl_FragData[1] = vec4(max(endLit, vec3(0.0)), 1.0);
        return;
    }

    // =========================================================================
    // OVERWORLD & NETHER LIGHTING
    // =========================================================================
    // 1. Ambient Sky Light (modulated by lightmap sky channel lm.y)
    float skyLightWeight = pow(clamp(lm.y, 0.0, 1.0), 1.45);
    vec3 ambientSky = getAmbientSkyColor(ts, rainStrength);
    vec3 groundBounce = ambientSky * vec3(0.45, 0.42, 0.38);
    vec3 ambient = mix(groundBounce, ambientSky, NdotUp) * skyLightWeight;

    // Minimum cave/Nether ambient floor so dark interiors and Nether stay readable
    vec3 minAmbient = mix(vec3(0.022, 0.025, 0.035), pow(max(fogColor, vec3(0.0)), vec3(2.2)) * 0.28 + vec3(0.025), 1.0 - skyLightWeight);
    ambient = max(ambient, minAmbient) + vec3(nightVision * 0.35);

    // 3. Direct Sunlight / Moonlight & Soft Shadows
    float diffuseTerm = max(NdotL, 0.0);
    if (isFoliage > 0.5) {
        diffuseTerm = max(NdotL * 0.65 + 0.35, 0.0);
    }

    vec3 shadowMult = vec3(1.0);
    if (diffuseTerm > 0.001 || isFoliage > 0.5) {
        shadowMult = computeSoftShadows(playerPos, worldNormal, NdotL, isFoliage);
    }
    shadowMult *= ts.shadowFade;
    shadowMult *= smoothstep(0.05, 0.35, lm.y);

    vec3 directColor = getDirectLightColor(ts, rainStrength);
    vec3 directLight = directColor * diffuseTerm * shadowMult;

    // 4. Foliage Subsurface Scattering (Backlit leaves & grass glow in sunlight)
    #ifdef FOLIAGE_SSS
    if (isFoliage > 0.5) {
        float backLight = pow(clamp(dot(viewDir, lightDirView), 0.0, 1.0), 3.0);
        vec3 sssColor = directColor * vec3(0.85, 1.15, 0.45) * (0.45 + 0.55 * backLight);
        directLight += sssColor * shadowMult * 0.55;
    }
    #endif

    // 5. Specular Highlight & Rain Wetness Puddles
    vec3 halfVec = normalize(lightDirView - viewDir);
    float NdotH = max(dot(viewNormal, halfVec), 0.0);
    float specBase = pow(NdotH, 32.0) * 0.08;

    #ifdef WET_RAIN_PUDDLES
    vec3 worldPos = playerPos + cameraPosition;
    float puddleNoise = sin(worldPos.x * 0.65 + sin(worldPos.z * 0.55)) * cos(worldPos.z * 0.70 - cos(worldPos.x * 0.50)) * 0.5 + 0.5;
    float upSurface = smoothstep(0.75, 0.95, dot(worldNormal, vec3(0.0, 1.0, 0.0)));
    float puddleMask = wetness * upSurface * smoothstep(0.15, 0.75, lm.y) * smoothstep(0.30, 0.75, puddleNoise);
    albedo *= mix(1.0, 0.68, puddleMask);
    float wetSpec = pow(NdotH, 96.0) * 0.85 * puddleMask;
    specBase += wetSpec;
    #endif

    vec3 specular = directColor * specBase * shadowMult * max(NdotL, 0.0);

    // Combine lighting on opaque surface
    vec3 litColor = albedo * ((ambient + directLight) * ao + blockLight) + specular;

    // Wet ground sky reflection in rain
    #ifdef WET_RAIN_PUDDLES
    if (puddleMask > 0.01) {
        vec3 reflDir = reflect(viewDir, viewNormal);
        vec3 skyRefl = computeAtmosphericSky(reflDir, sunPosition, moonPosition, upPosition, rainStrength, skyColor);
        float fresnelWet = pow(1.0 - max(dot(-viewDir, viewNormal), 0.0), 4.0);
        litColor = mix(litColor, skyRefl, puddleMask * fresnelWet * 0.55);
    }
    #endif

    // 6. Emissive Ores & Light Blocks
    #ifdef EMISSIVE_GLOW
    if (isEmissive > 0.5) {
        litColor = max(litColor, albedo * 3.2);
    }
    #endif

    // 7. Clouds shading
    if (isCloud > 0.5) {
        vec3 cloudLight = ambientSky * 0.85 + directColor * 0.75;
        litColor = albedo * cloudLight;
    }

    gl_FragData[0] = vec4(max(litColor, vec3(0.0)), 1.0);
    gl_FragData[1] = vec4(max(litColor, vec3(0.0)), 1.0);
}
