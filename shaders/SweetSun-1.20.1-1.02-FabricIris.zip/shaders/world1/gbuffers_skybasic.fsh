#version 120
#define DIMENSION_END

varying vec4 starData;

/* DRAWBUFFERS:012 */
void main() {
    float matId = (starData.a > 0.5) ? 0.05 : 0.00;
    gl_FragData[0] = vec4(starData.rgb, 1.0);
    gl_FragData[1] = vec4(0.5, 0.5, 1.0, 1.0);
    gl_FragData[2] = vec4(0.0, 1.0, matId, 1.0);
}
