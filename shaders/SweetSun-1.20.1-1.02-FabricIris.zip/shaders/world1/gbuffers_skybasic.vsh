#version 120
#define DIMENSION_END

varying vec4 starData;

void main() {
    gl_Position = ftransform();
    float isStar = (gl_Color.r == gl_Color.g && gl_Color.g == gl_Color.b && gl_Color.r > 0.0) ? 1.0 : 0.0;
    starData = vec4(gl_Color.rgb, isStar);
}
