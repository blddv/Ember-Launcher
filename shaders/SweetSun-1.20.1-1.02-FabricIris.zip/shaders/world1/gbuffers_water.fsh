#version 120
#define DIMENSION_END

#include "/lib/settings.glsl"

uniform sampler2D texture;
uniform mat4 gbufferModelView;
uniform vec3 upPosition;
uniform float frameTimeCounter;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 viewNormal;
varying vec3 worldPos;
varying float matId;

vec3 getWaterWaveNormalWorld(vec3 wp, float time) {
    float t = time * 2.1 * WAVING_SPEED;
    float h = 0.065 * WATER_WAVE_HEIGHT;

    // Multi-octave directional wave derivatives
    float dx = cos(wp.x * 1.8 + wp.z * 0.9 + t) * 1.8 * h
             + sin(wp.x * 3.4 - wp.z * 2.1 + t * 1.35) * 1.9 * h
             + cos(wp.x * 6.2 + wp.z * 4.5 - t * 1.7) * 0.9 * h;

    float dz = cos(wp.x * 1.8 + wp.z * 0.9 + t) * 0.9 * h
             - sin(wp.x * 3.4 - wp.z * 2.1 + t * 1.35) * 1.2 * h
             + sin(wp.z * 5.8 - wp.x * 3.7 + t * 1.55) * 1.1 * h;

    return normalize(vec3(-dx, 1.0, -dz));
}

/* DRAWBUFFERS:012 */
void main() {
    vec4 tex = texture2D(texture, texcoord) * color;
    if (tex.a < 0.05) discard;

    vec3 n = normalize(viewNormal);

    if (abs(matId - 0.50) < 0.04) {
        // Water surface: compute animated world-space wave normal and transform to view space
        vec3 waveWorldN = getWaterWaveNormalWorld(worldPos, frameTimeCounter);
        vec3 waveViewN = normalize((gbufferModelView * vec4(waveWorldN, 0.0)).xyz);

        // Blend wave normal mostly on horizontal water surfaces
        vec3 upView = normalize(upPosition);
        float isHorizontal = clamp(abs(dot(n, upView)), 0.0, 1.0);
        n = normalize(mix(n, waveViewN, isHorizontal));

        // Alpha=1.0 on FragData[1] and FragData[2] guarantees exact overwrite even with GL_BLEND
        gl_FragData[0] = vec4(tex.rgb, 0.25);
        gl_FragData[1] = vec4(n * 0.5 + 0.5, 1.0);
        gl_FragData[2] = vec4(clamp(lmcoord, 0.0, 1.0), 0.50, 1.0);
    } else {
        // Translucent Stained Glass / Ice: blend linear albedo onto lit colortex0
        vec3 linearGlass = pow(max(tex.rgb, vec3(0.0)), vec3(2.2));
        gl_FragData[0] = vec4(linearGlass, tex.a);
        gl_FragData[1] = vec4(n * 0.5 + 0.5, 1.0);
        gl_FragData[2] = vec4(clamp(lmcoord, 0.0, 1.0), 0.60, 1.0);
    }
}
