// Aurora Shaders - Atmospheric Sky, The End Cosmic Void & Purple Flashes

#ifndef SKY_GLSL
#define SKY_GLSL

struct TimeState {
    float sunElevation;
    float dayFactor;
    float sunsetFactor;
    float nightFactor;
    float shadowFade;
};

TimeState computeTimeState(vec3 sunPosView, vec3 upPosView) {
    TimeState ts;
    vec3 sunDir = normalize(sunPosView);
    vec3 upDir = normalize(upPosView);
    ts.sunElevation = dot(sunDir, upDir);
    ts.dayFactor = smoothstep(-0.08, 0.18, ts.sunElevation);
    ts.sunsetFactor = smoothstep(-0.12, 0.02, ts.sunElevation) * (1.0 - smoothstep(0.06, 0.38, ts.sunElevation));
    ts.nightFactor = smoothstep(0.06, -0.12, ts.sunElevation);
    ts.shadowFade = clamp(abs(ts.sunElevation) * 7.5, 0.0, 1.0);
    return ts;
}

vec3 getDirectLightColor(TimeState ts, float rain) {
    vec3 daySun = vec3(1.55, 1.38, 1.18);
    vec3 sunsetSun = vec3(1.85, 0.78, 0.32);
    vec3 nightMoon = vec3(0.16, 0.24, 0.42);

    vec3 col = mix(nightMoon, daySun, ts.dayFactor);
    col = mix(col, sunsetSun, ts.sunsetFactor * 0.85);
    col *= (1.0 - rain * 0.72);
    return col;
}

vec3 getAmbientSkyColor(TimeState ts, float rain) {
    vec3 dayAmb = vec3(0.42, 0.56, 0.78);
    vec3 sunsetAmb = vec3(0.55, 0.36, 0.38);
    vec3 nightAmb = vec3(0.05, 0.08, 0.16);

    vec3 amb = mix(nightAmb, dayAmb, ts.dayFactor);
    amb = mix(amb, sunsetAmb, ts.sunsetFactor * 0.65);

    vec3 rainGray = vec3(dot(amb, vec3(0.299, 0.587, 0.114))) * 0.65;
    return mix(amb, rainGray, rain * 0.75);
}

// =============================================================================
// THE END DIMENSION: Cosmic Purple-Black Nebula & Bright Purple Sky Flashes
// =============================================================================
float hash11End(float p) {
    p = fract(p * 0.1031);
    p *= p + 33.33;
    p *= p + p;
    return fract(p);
}

float hash31End(vec3 p3) {
    p3 = fract(p3 * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float noise3DEnd(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);

    float n000 = hash31End(i + vec3(0.0, 0.0, 0.0));
    float n100 = hash31End(i + vec3(1.0, 0.0, 0.0));
    float n010 = hash31End(i + vec3(0.0, 1.0, 0.0));
    float n110 = hash31End(i + vec3(1.0, 1.0, 0.0));
    float n001 = hash31End(i + vec3(0.0, 0.0, 1.0));
    float n101 = hash31End(i + vec3(1.0, 0.0, 1.0));
    float n011 = hash31End(i + vec3(0.0, 1.0, 1.0));
    float n111 = hash31End(i + vec3(1.0, 1.0, 1.0));

    float nx00 = mix(n000, n100, f.x);
    float nx10 = mix(n010, n110, f.x);
    float nx01 = mix(n001, n101, f.x);
    float nx11 = mix(n011, n111, f.x);

    float nxy0 = mix(nx00, nx10, f.y);
    float nxy1 = mix(nx01, nx11, f.y);

    return mix(nxy0, nxy1, f.z);
}

float fbmEndNebula(vec3 p) {
    float v = 0.0;
    float amp = 0.5;
    for (int i = 0; i < 4; i++) {
        v += noise3DEnd(p) * amp;
        p = p * 2.05 + vec3(11.3, 7.1, 17.9);
        amp *= 0.5;
    }
    return v;
}

float getSingleFlashEnvelope(float time, float seedOffset, float rate) {
    float cycle = time * rate * END_FLASH_FREQUENCY + seedOffset;
    float cellId = floor(cycle);
    float localT = fract(cycle);

    // ~62% of cycles trigger a flash so intervals feel organic and alive
    float chance = hash11End(cellId * 19.73 + seedOffset);
    if (chance < 0.38) {
        return 0.0;
    }

    // Double-strike lightning pulse + smooth magical afterglow
    float strike1 = exp(-pow((localT - 0.07) * 26.0, 2.0));
    float strike2 = exp(-pow((localT - 0.16) * 34.0, 2.0)) * 0.80;
    float afterglow = exp(-localT * 5.5) * smoothstep(0.0, 0.05, localT) * 0.35;
    return clamp(strike1 + strike2 + afterglow, 0.0, 1.0);
}

vec3 computeSingleEndFlash(vec3 worldDir, float time, float seedOffset, float rate, float n1, float n2) {
    float pulse = getSingleFlashEnvelope(time, seedOffset, rate);
    if (pulse <= 0.001) {
        return vec3(0.0);
    }

    float cycle = time * rate * END_FLASH_FREQUENCY + seedOffset;
    float cellId = floor(cycle);

    // Pick a random direction in the End sky dome for this flash
    float theta = hash11End(cellId * 43.17 + seedOffset) * 6.2831853;
    float phi = mix(-0.15, 0.82, hash11End(cellId * 89.31 + seedOffset));
    float cosPhi = sqrt(max(0.0, 1.0 - phi * phi));
    vec3 flashDir = normalize(vec3(cos(theta) * cosPhi, phi, sin(theta) * cosPhi));

    float alignment = clamp(dot(worldDir, flashDir), 0.0, 1.0);

    // Wide purple nebula flash glow
    float cloudBurst = pow(alignment, 3.0) * (0.45 + 0.95 * n1);

    // Jagged electric purple-white arcane rift / lightning filament in the core
    float filament = clamp(1.0 - abs(n2 - 0.48) * 7.5, 0.0, 1.0);
    float coreRift = pow(alignment, 14.0) * (0.65 + 2.2 * pow(filament, 2.0));
    float hotCenter = pow(alignment, 42.0) * (1.2 + 2.5 * filament);

    vec3 electricPurple = vec3(1.35, 0.18, 2.55);
    vec3 vividMagenta = vec3(3.20, 0.85, 4.60);
    vec3 whiteViolet = vec3(4.50, 2.80, 5.80);

    vec3 flashCol = electricPurple * cloudBurst + vividMagenta * coreRift + whiteViolet * hotCenter;
    return flashCol * pulse * END_FLASH_INTENSITY;
}

float getEndAmbientFlashPulse(float time) {
    #ifndef END_FLASHES
    return 0.0;
    #else
    float p1 = getSingleFlashEnvelope(time, 0.0, 0.32);
    float p2 = getSingleFlashEnvelope(time, 13.7, 0.21);
    return clamp(max(p1, p2 * 0.85), 0.0, 1.0) * END_FLASH_INTENSITY;
    #endif
}

vec3 computeEndSky(vec3 worldDir, float time) {
    vec3 dir = normalize(worldDir);

    // Deep obsidian-black to dark violet void base
    float horizonBand = 1.0 - abs(dir.y);
    vec3 voidBlack = vec3(0.008, 0.002, 0.018);
    vec3 horizonViolet = vec3(0.055, 0.012, 0.105);
    vec3 sky = mix(voidBlack, horizonViolet, pow(horizonBand, 2.2));

    // Swirling 3D cosmic purple & magenta nebulae
    vec3 windDrift = vec3(time * 0.018, -time * 0.012, time * 0.015);
    float n1 = fbmEndNebula(dir * 2.6 + windDrift);
    float n2 = fbmEndNebula(dir * 5.2 - windDrift * 1.4 + vec3(n1 * 1.35));

    float nebulaMask = smoothstep(0.36, 0.78, n1);
    float riftMask = smoothstep(0.45, 0.82, n2) * nebulaMask;

    vec3 darkNebulaCol = vec3(0.14, 0.028, 0.26);
    vec3 brightNebulaCol = vec3(0.48, 0.11, 0.72);
    vec3 magentaVeinCol = vec3(0.85, 0.22, 1.15);

    vec3 nebula = darkNebulaCol * nebulaMask + brightNebulaCol * pow(nebulaMask, 2.2) + magentaVeinCol * pow(riftMask, 2.6) * 0.65;
    sky += nebula * END_NEBULA_BRIGHTNESS;

    // Distant twinkling violet & white void stars
    float starNoise = hash31End(floor(dir * 260.0));
    if (starNoise > 0.9945) {
        float twinkle = sin(time * 3.2 + starNoise * 600.0) * 0.4 + 0.6;
        float starBright = pow((starNoise - 0.9945) / 0.0055, 2.0) * twinkle;
        vec3 starTint = mix(vec3(0.85, 0.55, 1.0), vec3(1.0, 0.90, 1.0), fract(starNoise * 137.0));
        sky += starTint * starBright * 1.35;
    }

    // Occasional bright purple sky flashes & arcane lightning rifts
    #ifdef END_FLASHES
    sky += computeSingleEndFlash(dir, time, 0.0, 0.32, n1, n2);
    sky += computeSingleEndFlash(dir, time, 13.7, 0.21, n2, n1);
    #endif

    return max(sky, vec3(0.0));
}

bool isEndDimensionFallback(vec3 biomeSkyColor, vec3 biomeFogColor) {
    #ifdef DIMENSION_END
    return true;
    #else
    #ifdef DIMENSION_NETHER
    return false;
    #else
    #ifdef DIMENSION_OVERWORLD
    return false;
    #else
    // Fallback detection if running from root shaders/: in Vanilla End, skyColor is (0,0,0) and fogColor is dark purple
    float skyLen = length(biomeSkyColor);
    float fogLen = length(biomeFogColor);
    return (skyLen < 0.005 && fogLen > 0.02 && fogLen < 0.30 && biomeFogColor.r > biomeFogColor.g * 1.15 && biomeFogColor.b > biomeFogColor.g * 1.15);
    #endif
    #endif
    #endif
}

vec3 computeAtmosphericSky(vec3 viewDir, vec3 sunPosView, vec3 moonPosView, vec3 upPosView, float rain, vec3 biomeSkyColor) {
    TimeState ts = computeTimeState(sunPosView, upPosView);
    vec3 upDir = normalize(upPosView);
    vec3 sunDir = normalize(sunPosView);
    vec3 moonDir = normalize(moonPosView);

    float VoU = clamp(dot(viewDir, upDir), -0.25, 1.0);
    float horizonFactor = pow(1.0 - clamp(VoU, 0.0, 1.0), 3.2);

    // Zenith and horizon palettes
    vec3 dayZenith = mix(vec3(0.16, 0.40, 0.88), biomeSkyColor * 0.95, 0.30);
    vec3 dayHorizon = vec3(0.62, 0.80, 0.98);

    vec3 sunsetZenith = vec3(0.18, 0.24, 0.52);
    vec3 sunsetHorizon = vec3(1.15, 0.48, 0.22);

    vec3 nightZenith = vec3(0.015, 0.025, 0.065);
    vec3 nightHorizon = vec3(0.045, 0.075, 0.155);

    vec3 zenith = mix(nightZenith, dayZenith, ts.dayFactor);
    zenith = mix(zenith, sunsetZenith, ts.sunsetFactor * 0.75);

    vec3 horizon = mix(nightHorizon, dayHorizon, ts.dayFactor);
    horizon = mix(horizon, sunsetHorizon, ts.sunsetFactor * 0.90);

    vec3 sky = mix(zenith, horizon, horizonFactor);

    // Solar Mie scattering halo
    float VoS = clamp(dot(viewDir, sunDir), 0.0, 1.0);
    float sunHalo = pow(VoS, 6.0) * 0.35 + pow(VoS, 32.0) * 0.65;
    vec3 sunGlowCol = mix(vec3(1.2, 0.95, 0.65), vec3(1.6, 0.55, 0.20), ts.sunsetFactor);
    sky += sunGlowCol * sunHalo * clamp(ts.dayFactor + ts.sunsetFactor * 0.8, 0.0, 1.0) * (1.0 - rain * 0.85);

    // Lunar Mie halo at night
    float VoM = clamp(dot(viewDir, moonDir), 0.0, 1.0);
    float moonHalo = pow(VoM, 10.0) * 0.20;
    sky += vec3(0.22, 0.34, 0.58) * moonHalo * ts.nightFactor * (1.0 - rain * 0.85);

    // Rain overcast desaturation
    vec3 overcast = vec3(dot(sky, vec3(0.299, 0.587, 0.114))) * vec3(0.58, 0.62, 0.68);
    sky = mix(sky, overcast, rain * 0.82);

    return max(sky, vec3(0.0));
}

#endif
