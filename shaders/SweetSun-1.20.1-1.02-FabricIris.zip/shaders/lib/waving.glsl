// Aurora Shaders - Vertex Waving & Wind Animation Library

#ifndef WAVING_GLSL
#define WAVING_GLSL

vec3 getWindOffset(vec3 worldPos, float time, float amp) {
    float windSpeed = time * 2.6 * WAVING_SPEED;
    float gust = sin(time * 0.7 + worldPos.x * 0.12 + worldPos.z * 0.10) * 0.35 + 0.65;
    float waveX = sin(windSpeed + worldPos.x * 1.35 + worldPos.z * 0.85 + worldPos.y * 0.60);
    float waveZ = cos(windSpeed * 0.85 + worldPos.z * 1.25 - worldPos.x * 0.70 + worldPos.y * 0.50);
    float waveY = sin(windSpeed * 1.40 + worldPos.x * 1.10 + worldPos.z * 1.10) * 0.18;
    return vec3(waveX, waveY, waveZ) * (amp * gust * WAVING_AMPLITUDE);
}

float getWaterVertexWave(vec3 worldPos, float time) {
    float t = time * 2.2 * WAVING_SPEED;
    float w1 = sin(worldPos.x * 1.6 + worldPos.z * 0.9 + t) * 0.038;
    float w2 = cos(worldPos.z * 2.1 - worldPos.x * 1.1 + t * 1.25) * 0.024;
    return (w1 + w2) * WATER_WAVE_HEIGHT;
}

vec3 applyWaving(vec3 playerPos, vec3 cameraPos, int entityId, vec2 texcoord, vec2 midTexCoord, float time, float rain) {
    vec3 worldPos = playerPos + cameraPos;
    float rainBoost = 1.0 + rain * 0.45;

    // 10002: Ground Grass, Flowers, Crops (only top vertices move)
    #ifdef WAVING_GRASS
    if (entityId == 10002) {
        if (texcoord.y < midTexCoord.y) {
            playerPos += getWindOffset(worldPos, time, 0.055 * rainBoost);
        }
    }
    #endif

    // 10003: Leaves and Vines (all vertices sway continuously in world space)
    #ifdef WAVING_LEAVES
    if (entityId == 10003) {
        playerPos += getWindOffset(worldPos, time, 0.038 * rainBoost);
    }
    #endif

    // 10004: Tall 2-block plants
    #ifdef WAVING_TALL_PLANTS
    if (entityId == 10004) {
        float topWeight = (texcoord.y < midTexCoord.y) ? 1.0 : 0.45;
        playerPos += getWindOffset(worldPos, time, 0.048 * topWeight * rainBoost);
    }
    #endif

    // 10001 / 10007: Water surface & Lily pads
    #ifdef WAVING_WATER
    if (entityId == 10001 || entityId == 10007) {
        float fractY = fract(worldPos.y + 0.005);
        if (fractY > 0.70 || entityId == 10007) {
            playerPos.y += getWaterVertexWave(worldPos, time) - 0.025 * WATER_WAVE_HEIGHT;
        }
    }
    #endif

    return playerPos;
}

#endif
