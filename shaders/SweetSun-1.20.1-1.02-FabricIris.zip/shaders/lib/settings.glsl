// Aurora Shaders - Configurable Settings & Pipeline Constants

#ifndef SETTINGS_GLSL
#define SETTINGS_GLSL

// --- Lighting & Shadows ---
#define SOFT_SHADOWS
#define COLORED_SHADOWS
#define SHADOW_RES 2048 // [1024 1536 2048 3072 4096]
#define SHADOW_DIST 160.0 // [64.0 96.0 128.0 160.0 192.0 256.0]
#define SHADOW_FILTER_SAMPLES 12 // [4 8 12 16]
#define SHADOW_SOFTNESS 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00]
#define SUN_PATH_ROTATION -35.0 // [-45.0 -35.0 -25.0 -15.0 0.0 15.0 25.0 35.0]
#define FOLIAGE_SSS
#define EMISSIVE_GLOW
#define TORCH_WARMTH 1.00 // [0.60 0.80 1.00 1.20 1.40]

// --- Water & Reflections ---
#define WAVING_WATER
#define SSR_QUALITY 2 // [0 1 2 3]
#define WATER_REFRACTION
#define WATER_CAUSTICS
#define WATER_WAVE_HEIGHT 1.00 // [0.40 0.70 1.00 1.30 1.60]
#define WATER_OPACITY 1.00 // [0.50 0.75 1.00 1.25 1.50]
#define GLASS_REFLECTIONS
#define WET_RAIN_PUDDLES

// --- Waving Plants ---
#define WAVING_GRASS
#define WAVING_LEAVES
#define WAVING_TALL_PLANTS
#define WAVING_SPEED 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00]
#define WAVING_AMPLITUDE 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00]

// --- The End Dimension ---
#define END_FLASHES
#define END_FLASH_FREQUENCY 1.00 // [0.50 0.75 1.00 1.50 2.00]
#define END_FLASH_INTENSITY 1.00 // [0.50 0.75 1.00 1.35 1.75 2.20]
#define END_NEBULA_BRIGHTNESS 1.00 // [0.50 0.75 1.00 1.25 1.50]

// --- Post-Processing & Color ---
#define BLOOM_ENABLED
#define BLOOM_STRENGTH 1.00 // [0.20 0.40 0.60 0.80 1.00 1.25 1.50]
#define GODRAYS
#define GODRAYS_INTENSITY 1.00 // [0.40 0.70 1.00 1.30 1.60]
#define TONEMAP_EXPOSURE 1.05 // [0.75 0.90 1.00 1.05 1.15 1.30 1.50]
#define TONEMAP_SATURATION 1.12 // [0.80 0.90 1.00 1.08 1.12 1.20 1.35]
#define TONEMAP_CONTRAST 1.05 // [0.90 0.95 1.00 1.05 1.10 1.20]
#define VIGNETTE_ENABLED
#define SHARPENING 0.40 // [0.00 0.20 0.40 0.60 0.80 1.00]

// --- Shadow Distortion Constants ---
#define SHADOW_DISTORTION 0.85

float getShadowDistortionFactor(vec2 clipXY) {
    float dist = length(clipXY);
    return mix(1.0, dist, SHADOW_DISTORTION);
}

vec3 distortShadowClipPos(vec3 clipPos) {
    float factor = getShadowDistortionFactor(clipPos.xy);
    clipPos.xy /= max(factor, 0.001);
    clipPos.z *= 0.2;
    return clipPos;
}

#endif
