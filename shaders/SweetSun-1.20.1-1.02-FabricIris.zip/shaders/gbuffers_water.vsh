#version 120

#include "/lib/settings.glsl"
#include "/lib/waving.glsl"

attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 viewNormal;
varying vec3 worldPos;
varying float matId;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    color = gl_Color;
    viewNormal = normalize(gl_NormalMatrix * gl_Normal);

    int entityId = int(mc_Entity.x + 0.5);
    if (entityId == 10001) {
        matId = 0.50; // Water
    } else {
        matId = 0.60; // Stained glass / Ice / Translucent
    }

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vec4 playerPos = gbufferModelViewInverse * viewPos;

    playerPos.xyz = applyWaving(
        playerPos.xyz,
        cameraPosition,
        entityId,
        texcoord,
        mc_midTexCoord.xy,
        frameTimeCounter,
        rainStrength
    );

    worldPos = playerPos.xyz + cameraPosition;
    gl_Position = gl_ProjectionMatrix * (gbufferModelView * playerPos);
}
