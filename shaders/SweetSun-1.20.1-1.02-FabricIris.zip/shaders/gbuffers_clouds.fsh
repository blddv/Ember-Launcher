#version 120

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 color;
varying vec3 viewNormal;

/* DRAWBUFFERS:012 */
void main() {
    vec4 tex = texture2D(texture, texcoord) * color;
    if (tex.a < 0.1) discard;
    vec3 n = (length(viewNormal) > 0.01) ? normalize(viewNormal) : vec3(0.0, 1.0, 0.0);
    gl_FragData[0] = tex;
    gl_FragData[1] = vec4(n * 0.5 + 0.5, 1.0);
    gl_FragData[2] = vec4(0.0, 1.0, 0.80, 1.0);
}
