#version 120
#define DIMENSION_OVERWORLD

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 color;

/* DRAWBUFFERS:012 */
void main() {
    vec4 tex = texture2D(texture, texcoord) * color;
    if (tex.a < 0.05) discard;
    gl_FragData[0] = vec4(tex.rgb * 1.6, tex.a);
    gl_FragData[1] = vec4(0.5, 0.5, 1.0, 1.0);
    gl_FragData[2] = vec4(0.0, 1.0, 0.05, 1.0);
}
