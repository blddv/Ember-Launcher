#version 120
#define DIMENSION_OVERWORLD

#include "/lib/settings.glsl"
#include "/lib/sky.glsl"

/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA16;
const int colortex2Format = RGBA16;
const int colortex3Format = RGBA16F;
*/

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D shadowtex1;

uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 shadowLightPosition;
uniform vec3 upPosition;
uniform vec3 cameraPosition;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform float rainStrength;
uniform float frameTimeCounter;
uniform float near;
uniform float far;
uniform int isEyeInWater;

varying vec2 texcoord;

vec3 reconstructViewPos(vec2 uv, float depth) {
    vec4 clip = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 viewH = gbufferProjectionInverse * clip;
    return viewH.xyz / viewH.w;
}

vec3 projectViewToScreen(vec3 viewPos) {
    vec4 clip = gbufferProjection * vec4(viewPos, 1.0);
    vec3 ndc = clip.xyz / clip.w;
    return ndc * 0.5 + 0.5;
}

float computeWaterCaustics(vec3 worldPos, float time) {
    vec2 p1 = worldPos.xz * 1.45 + vec2(time * 0.85, -time * 0.65);
    vec2 p2 = worldPos.xz * 1.85 + vec2(-time * 0.70, time * 0.95);
    float c1 = sin(p1.x + sin(p1.y * 1.3)) * cos(p1.y + cos(p1.x * 1.2));
    float c2 = sin(p2.x - cos(p2.y * 1.4)) * cos(p2.y - sin(p2.x * 1.1));
    float caustic = pow(clamp((c1 + c2) * 0.5 + 0.5, 0.0, 1.0), 3.2);
    return caustic;
}

float sampleQuickShadow(vec3 playerPos) {
    float distSq = dot(playerPos, playerPos);
    if (distSq >= SHADOW_DIST * SHADOW_DIST) return 1.0;
    vec4 shadowView = shadowModelView * vec4(playerPos, 1.0);
    vec4 shadowClip = shadowProjection * shadowView;
    shadowClip.xyz = distortShadowClipPos(shadowClip.xyz);
    vec3 shadowScreen = (shadowClip.xyz / shadowClip.w) * 0.5 + 0.5;
    if (shadowScreen.x <= 0.002 || shadowScreen.x >= 0.998 ||
        shadowScreen.y <= 0.002 || shadowScreen.y >= 0.998 ||
        shadowScreen.z <= 0.0 || shadowScreen.z >= 1.0) {
        return 1.0;
    }
    float opDepth = texture2D(shadowtex1, shadowScreen.xy).r;
    return (shadowScreen.z - 0.0006 > opDepth) ? 0.0 : 1.0;
}

// Screen-Space Reflections raymarching in view space against solid geometry (depthtex1 & colortex3)
vec4 traceScreenSpaceReflection(vec3 startViewPos, vec3 reflDirView) {
    #if SSR_QUALITY == 0
    return vec4(0.0);
    #else

    #if SSR_QUALITY == 1
    const int STEPS = 12;
    #elif SSR_QUALITY == 2
    const int STEPS = 24;
    #else
    const int STEPS = 36;
    #endif

    // If reflection ray points straight toward camera, fade out gracefully
    if (reflDirView.z > 0.25) {
        return vec4(0.0);
    }

    float rayLen = max(0.35, length(startViewPos) * 0.08);
    vec3 currentPos = startViewPos + reflDirView * 0.15;
    vec3 stepVec = reflDirView * rayLen;

    for (int i = 0; i < STEPS; i++) {
        currentPos += stepVec;
        stepVec *= 1.12; // Exponential step growth for distant reflections

        vec3 screenPos = projectViewToScreen(currentPos);
        if (screenPos.x < 0.005 || screenPos.x > 0.995 ||
            screenPos.y < 0.005 || screenPos.y > 0.995 ||
            screenPos.z <= 0.0 || screenPos.z >= 1.0) {
            break;
        }

        float sceneDepth = texture2D(depthtex1, screenPos.xy).r;
        if (sceneDepth >= 0.999999) {
            continue;
        }

        vec3 sceneViewPos = reconstructViewPos(screenPos.xy, sceneDepth);
        float depthDiff = sceneViewPos.z - currentPos.z; // Remember viewPos.z is negative!

        // Ray crossed behind a solid surface within plausible thickness
        if (depthDiff > 0.0 && depthDiff < max(1.8, length(stepVec) * 2.2)) {
            // Binary refinement step (3 iterations)
            vec3 refinePos = currentPos - stepVec * 0.5;
            vec3 refineStep = stepVec * 0.25;
            for (int j = 0; j < 3; j++) {
                vec3 rScreen = projectViewToScreen(refinePos);
                float rDepth = texture2D(depthtex1, rScreen.xy).r;
                vec3 rView = reconstructViewPos(rScreen.xy, rDepth);
                if (rView.z > refinePos.z) {
                    refinePos -= refineStep;
                } else {
                    refinePos += refineStep;
                }
                refineStep *= 0.5;
            }

            vec3 hitScreen = projectViewToScreen(refinePos);
            vec2 edgeDist = smoothstep(vec2(0.0), vec2(0.08), hitScreen.xy) *
                            (1.0 - smoothstep(vec2(0.92), vec2(1.0), hitScreen.xy));
            float edgeFade = edgeDist.x * edgeDist.y;
            vec3 hitColor = texture2D(colortex3, hitScreen.xy).rgb;
            return vec4(hitColor, clamp(edgeFade, 0.0, 1.0));
        }
    }

    return vec4(0.0);
    #endif
}

/* DRAWBUFFERS:0 */
void main() {
    vec4 colorData = texture2D(colortex0, texcoord);
    vec4 normalData = texture2D(colortex1, texcoord);
    vec4 lightData = texture2D(colortex2, texcoord);
    float depth0 = texture2D(depthtex0, texcoord).r;
    float depth1 = texture2D(depthtex1, texcoord).r;

    vec3 viewPos = reconstructViewPos(texcoord, depth0);
    vec3 viewDir = normalize(viewPos);
    float dist = length(viewPos);

    float matId = lightData.b;
    vec2 lm = lightData.rg;
    vec3 viewNormal = normalize(normalData.rgb * 2.0 - 1.0);

    bool inEnd = isEndDimensionFallback(skyColor, fogColor);

    TimeState ts = computeTimeState(sunPosition, upPosition);
    vec3 lightDirView = normalize(shadowLightPosition);
    vec3 directColor = inEnd ? vec3(0.85, 0.35, 1.35) : getDirectLightColor(ts, rainStrength);
    vec3 ambientSky = inEnd ? vec3(0.22, 0.09, 0.36) : getAmbientSkyColor(ts, rainStrength);

    vec3 finalColor = colorData.rgb;

    // =========================================================================
    // 1. WATER SHADING (Refraction, Absorption, Caustics, SSR + Sky Fresnel)
    // =========================================================================
    if (abs(matId - 0.50) < 0.04) {
        vec3 playerPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
        vec3 worldPos = playerPos + cameraPosition;

        // Underwater solid floor position before refraction
        vec3 floorViewPos = reconstructViewPos(texcoord, depth1);
        float waterDepth = max(0.0, length(floorViewPos) - dist);

        // Screen-space UV refraction
        vec2 refractUV = texcoord;
        #ifdef WATER_REFRACTION
        vec2 waveOffset = viewNormal.xy * (0.028 * WATER_WAVE_HEIGHT) * clamp(waterDepth * 0.35, 0.0, 1.0) / max(1.0, dist * 0.15);
        vec2 candidateUV = clamp(texcoord + waveOffset, 0.002, 0.998);
        float candidateDepth1 = texture2D(depthtex1, candidateUV).r;
        if (candidateDepth1 > depth0) {
            refractUV = candidateUV;
            floorViewPos = reconstructViewPos(refractUV, candidateDepth1);
            waterDepth = max(0.0, length(floorViewPos) - dist);
        }
        #endif

        // Sample already-lit underwater seabed from colortex3
        vec3 seabedColor = texture2D(colortex3, refractUV).rgb;

        // Underwater caustics on the seabed
        #ifdef WATER_CAUSTICS
        if (depth1 < 0.999999 && waterDepth < 28.0) {
            vec3 floorPlayerPos = (gbufferModelViewInverse * vec4(floorViewPos, 1.0)).xyz;
            vec3 floorWorldPos = floorPlayerPos + cameraPosition;
            float caustic = computeWaterCaustics(floorWorldPos, frameTimeCounter);
            float causticFade = exp(-waterDepth * 0.14) * (inEnd ? 0.65 : (clamp(ts.dayFactor + ts.sunsetFactor * 0.5, 0.0, 1.0) * (1.0 - rainStrength * 0.8)));
            float floorShadow = inEnd ? 1.0 : sampleQuickShadow(floorPlayerPos);
            seabedColor += seabedColor * caustic * directColor * 0.75 * causticFade * floorShadow;
        }
        #endif

        // Beer-Lambert water absorption and volume scattering
        vec3 absorptionCoeff = (inEnd ? vec3(0.28, 0.36, 0.12) : vec3(0.42, 0.14, 0.065)) * WATER_OPACITY;
        vec3 transmittance = exp(-absorptionCoeff * min(waterDepth, 40.0));

        float waterSkyLight = inEnd ? 1.0 : pow(clamp(lm.y, 0.1, 1.0), 1.3);
        float surfaceShadow = inEnd ? 1.0 : (sampleQuickShadow(playerPos) * ts.shadowFade);
        vec3 deepWaterCol = (vec3(0.025, 0.15, 0.24) * ambientSky * 2.2 + vec3(0.02, 0.18, 0.25) * directColor * surfaceShadow * 0.35) * waterSkyLight;

        vec3 refractedWater = mix(deepWaterCol, seabedColor * vec3(0.82, 0.96, 1.02), transmittance);

        // Reflections: Screen-Space Reflections (SSR) + Sky fallback (End Nebula or Overworld Sky)
        vec3 reflDir = reflect(viewDir, viewNormal);
        vec3 reflWorldDir = normalize((gbufferModelViewInverse * vec4(reflDir, 0.0)).xyz);
        vec3 skyRefl = inEnd
            ? computeEndSky(reflWorldDir, frameTimeCounter)
            : (computeAtmosphericSky(reflDir, sunPosition, moonPosition, upPosition, rainStrength, skyColor) * waterSkyLight);
        vec4 ssr = traceScreenSpaceReflection(viewPos, reflDir);
        vec3 reflectionColor = mix(skyRefl, ssr.rgb, ssr.a);

        // Schlick's Fresnel approximation for water (F0 = 0.02)
        float NdotV = max(dot(-viewDir, viewNormal), 0.0);
        float fresnel = clamp(0.03 + 0.97 * pow(1.0 - NdotV, 4.5), 0.0, 0.92);

        // Solar / Lunar specular glint on water waves
        vec3 halfVec = normalize(lightDirView - viewDir);
        float NdotH = max(dot(viewNormal, halfVec), 0.0);
        float sunSpec = (pow(NdotH, 256.0) * 3.8 + pow(NdotH, 32.0) * 0.22) * surfaceShadow * max(dot(viewNormal, lightDirView), 0.0);
        vec3 specGlow = directColor * sunSpec;

        finalColor = mix(refractedWater, reflectionColor, fresnel) + specGlow;
    }

    // =========================================================================
    // 2. TRANSLUCENT GLASS & ICE SHADING
    // =========================================================================
    #ifdef GLASS_REFLECTIONS
    else if (abs(matId - 0.60) < 0.04) {
        vec3 reflDir = reflect(viewDir, viewNormal);
        vec3 reflWorldDir = normalize((gbufferModelViewInverse * vec4(reflDir, 0.0)).xyz);
        vec3 skyRefl = inEnd
            ? computeEndSky(reflWorldDir, frameTimeCounter)
            : (computeAtmosphericSky(reflDir, sunPosition, moonPosition, upPosition, rainStrength, skyColor) * pow(clamp(lm.y, 0.1, 1.0), 1.3));
        vec4 ssr = traceScreenSpaceReflection(viewPos, reflDir);
        vec3 reflCol = mix(skyRefl, ssr.rgb, ssr.a);

        float NdotV = max(dot(-viewDir, viewNormal), 0.0);
        float fresnel = 0.06 + 0.85 * pow(1.0 - NdotV, 4.0);

        vec3 halfVec = normalize(lightDirView - viewDir);
        float spec = pow(max(dot(viewNormal, halfVec), 0.0), 128.0) * 1.35 * max(dot(viewNormal, lightDirView), 0.0);

        finalColor = mix(colorData.rgb, reflCol, fresnel * 0.45) + directColor * spec;
    }
    #endif

    // =========================================================================
    // 3. ATMOSPHERIC FOG, MORNING MIST, END VOID FOG & UNDERWATER FOG
    // =========================================================================
    if (isEyeInWater == 1) {
        // Underwater camera fog
        float uwFog = 1.0 - exp(-dist * 0.055);
        vec3 uwFogCol = vec3(0.02, 0.16, 0.26) * (ambientSky + directColor * 0.25);
        finalColor = mix(finalColor, uwFogCol, clamp(uwFog, 0.0, 0.92));
    } else if (depth0 < 0.999999 && matId > 0.08) {
        vec3 playerPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
        vec3 worldPos = playerPos + cameraPosition;
        vec3 worldDir = normalize((gbufferModelViewInverse * vec4(viewDir, 0.0)).xyz);

        if (inEnd) {
            // Magical Purple-Black End Void Fog
            float endDistFog = 1.0 - exp(-pow(dist * 0.0032, 1.55));
            float endBorderFog = smoothstep(far * 0.70, far * 0.98, dist);
            float totalEndFog = clamp(max(endDistFog * 0.75, endBorderFog), 0.0, 1.0);
            vec3 endFogCol = computeEndSky(worldDir, frameTimeCounter);
            finalColor = mix(finalColor, endFogCol, totalEndFog);
        } else {
            // Distance exponential fog + morning/sunset low-lying valley mist
            float fogDensity = 0.0022 + rainStrength * 0.0065 + ts.sunsetFactor * 0.0018;
            float distFog = 1.0 - exp(-pow(dist * fogDensity, 1.45));

            // Far plane smooth blend
            float borderFog = smoothstep(far * 0.72, far * 0.98, dist);

            // Low-altitude mist
            float heightFactor = exp(-max(worldPos.y - 60.0, 0.0) * 0.035);
            float mist = (1.0 - exp(-dist * 0.0045)) * heightFactor * (0.30 + ts.sunsetFactor * 0.45 + rainStrength * 0.35);

            float totalFog = clamp(max(distFog + mist * 0.45, borderFog), 0.0, 1.0);

            vec3 atmoFogCol = computeAtmosphericSky(viewDir, sunPosition, moonPosition, upPosition, rainStrength, skyColor);
            // Cave / Nether fog fallback when sky light is low
            float skyFactor = smoothstep(0.0, 0.30, lm.y);
            vec3 caveFogCol = pow(max(fogColor, vec3(0.0)), vec3(2.2)) * 0.65;
            vec3 targetFog = mix(caveFogCol, atmoFogCol, skyFactor);

            finalColor = mix(finalColor, targetFog, totalFog);
        }
    }

    gl_FragData[0] = vec4(max(finalColor, vec3(0.0)), 1.0);
}
