#version 120
#define DIMENSION_OVERWORLD

uniform sampler2D texture;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 viewNormal;
varying float matId;

/* DRAWBUFFERS:012 */
void main() {
    vec4 tex = texture2D(texture, texcoord);
    if (tex.a * color.a < 0.1) discard;

    vec3 albedo = tex.rgb * color.rgb;
    float ao = color.a;

    // Detect glowing ore pixels vs stone background on ore blocks
    float finalMatId = matId;
    if (abs(matId - 0.30) < 0.04) {
        float maxC = max(tex.r, max(tex.g, tex.b));
        float minC = min(tex.r, min(tex.g, tex.b));
        float sat = (maxC > 0.01) ? ((maxC - minC) / maxC) : 0.0;
        // High saturation or bright pixels on ores/lights glow strongly
        if (sat < 0.22 && maxC < 0.68 && lmcoord.x < 0.85) {
            finalMatId = 0.10;
        }
    }

    gl_FragData[0] = vec4(albedo, tex.a);
    gl_FragData[1] = vec4(normalize(viewNormal) * 0.5 + 0.5, 1.0);
    gl_FragData[2] = vec4(clamp(lmcoord, 0.0, 1.0), finalMatId, ao);
}
