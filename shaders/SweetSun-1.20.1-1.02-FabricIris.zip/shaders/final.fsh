#version 120

#include "/lib/settings.glsl"
#include "/lib/sky.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex3;
uniform sampler2D depthtex0;

uniform mat4 gbufferProjection;
uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform vec3 skyColor;
uniform vec3 fogColor;
uniform float rainStrength;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 texcoord;

// ACES Filmic Tone Mapping Curve (Narkowicz approximation)
vec3 acesTonemap(vec3 x) {
    float a = 2.51;
    float b = 0.03;
    float c = 2.43;
    float d = 0.59;
    float e = 0.14;
    return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

vec3 computeGodrays(vec2 uv) {
    #ifndef GODRAYS
    return vec3(0.0);
    #else
    #ifdef DIMENSION_END
    return vec3(0.0);
    #else
    #ifdef DIMENSION_NETHER
    return vec3(0.0);
    #else

    if (isEndDimensionFallback(skyColor, fogColor)) {
        return vec3(0.0);
    }

    // Only cast sun rays when the sun is in front of the camera
    if (sunPosition.z >= 0.0) {
        return vec3(0.0);
    }

    vec4 sunClip = gbufferProjection * vec4(sunPosition, 1.0);
    vec2 sunScreen = (sunClip.xy / sunClip.w) * 0.5 + 0.5;

    vec2 delta = sunScreen - uv;
    float aspect = viewWidth / max(viewHeight, 1.0);
    float distToSun = length(delta * vec2(aspect, 1.0));
    float radialFalloff = exp(-distToSun * 1.85);

    if (radialFalloff < 0.01) {
        return vec3(0.0);
    }

    const int SAMPLES = 12;
    vec2 stepUV = delta / float(SAMPLES);
    vec2 sampleUV = uv;
    float occlusion = 0.0;

    for (int i = 0; i < SAMPLES; i++) {
        sampleUV += stepUV;
        if (sampleUV.x >= 0.0 && sampleUV.x <= 1.0 && sampleUV.y >= 0.0 && sampleUV.y <= 1.0) {
            float d = texture2D(depthtex0, sampleUV).r;
            occlusion += step(0.9999, d);
        }
    }

    occlusion /= float(SAMPLES);

    TimeState ts = computeTimeState(sunPosition, upPosition);
    vec3 rayColor = getDirectLightColor(ts, rainStrength);
    float sunVis = clamp(ts.dayFactor + ts.sunsetFactor * 0.9, 0.0, 1.0) * (1.0 - rainStrength * 0.85);

    return rayColor * occlusion * radialFalloff * 0.26 * GODRAYS_INTENSITY * sunVis;
    #endif
    #endif
    #endif
}

void main() {
    vec2 texel = 1.0 / vec2(max(viewWidth, 1.0), max(viewHeight, 1.0));
    vec3 hdrColor = texture2D(colortex0, texcoord).rgb;

    // Optional Contrast-Adaptive Sharpening (CAS-inspired)
    if (SHARPENING > 0.01) {
        vec3 n = texture2D(colortex0, texcoord + vec2(0.0, -texel.y)).rgb;
        vec3 s = texture2D(colortex0, texcoord + vec2(0.0,  texel.y)).rgb;
        vec3 e = texture2D(colortex0, texcoord + vec2( texel.x, 0.0)).rgb;
        vec3 w = texture2D(colortex0, texcoord + vec2(-texel.x, 0.0)).rgb;
        vec3 avg = (n + s + e + w) * 0.25;
        hdrColor = max(vec3(0.0), hdrColor + (hdrColor - avg) * (0.45 * SHARPENING));
    }

    // Add Multi-Scale HDR Bloom
    #ifdef BLOOM_ENABLED
    vec3 bloom = texture2D(colortex3, texcoord).rgb;
    hdrColor += bloom;
    #endif

    // Add Volumetric Sun Shafts (Godrays)
    hdrColor += computeGodrays(texcoord);

    // Exposure & ACES Filmic Tone Mapping
    hdrColor *= TONEMAP_EXPOSURE;
    vec3 ldrColor = acesTonemap(hdrColor);

    // Gamma Correction (Linear -> sRGB)
    ldrColor = pow(max(ldrColor, vec3(0.0)), vec3(1.0 / 2.2));

    // Contrast & Saturation Grading
    ldrColor = clamp((ldrColor - 0.5) * TONEMAP_CONTRAST + 0.5, 0.0, 1.0);
    float luma = dot(ldrColor, vec3(0.2126, 0.7152, 0.0722));
    ldrColor = clamp(mix(vec3(luma), ldrColor, TONEMAP_SATURATION), 0.0, 1.0);

    // Subtle Vignette
    #ifdef VIGNETTE_ENABLED
    vec2 vigUV = texcoord * (1.0 - texcoord.yx);
    float vig = pow(vigUV.x * vigUV.y * 15.0, 0.14);
    ldrColor *= clamp(vig, 0.0, 1.0);
    #endif

    gl_FragColor = vec4(ldrColor, 1.0);
}
