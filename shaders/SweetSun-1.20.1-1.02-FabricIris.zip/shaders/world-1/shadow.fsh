#version 120
#define DIMENSION_NETHER

#include "/lib/settings.glsl"

uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 color;
varying float isWater;
varying float isGlass;

void main() {
    // Discard water in shadow map so shallow water does not self-shadow darkly
    if (isWater > 0.5) {
        discard;
    }

    vec4 tex = texture2D(texture, texcoord) * color;
    if (tex.a < 0.1) {
        discard;
    }

    #ifdef COLORED_SHADOWS
    if (isGlass > 0.5) {
        gl_FragData[0] = vec4(tex.rgb, tex.a);
        return;
    }
    #endif

    gl_FragData[0] = tex;
}
