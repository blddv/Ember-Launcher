#version 120
#define DIMENSION_NETHER

#include "/lib/settings.glsl"
#include "/lib/waving.glsl"

attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;

uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjection;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;

varying vec2 texcoord;
varying vec4 color;
varying float isWater;
varying float isGlass;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    color = gl_Color;

    int entityId = int(mc_Entity.x + 0.5);
    isWater = (entityId == 10001) ? 1.0 : 0.0;
    isGlass = (entityId == 10006) ? 1.0 : 0.0;

    // Transform vertex to player-centered world space
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vec4 playerPos = shadowModelViewInverse * viewPos;

    // Synchronize shadow waving with terrain waving
    playerPos.xyz = applyWaving(
        playerPos.xyz,
        cameraPosition,
        entityId,
        texcoord,
        mc_midTexCoord.xy,
        frameTimeCounter,
        rainStrength
    );

    gl_Position = shadowProjection * (shadowModelView * playerPos);
    gl_Position.xyz = distortShadowClipPos(gl_Position.xyz);
}
