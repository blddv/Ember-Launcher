#version 120
#define DIMENSION_NETHER

varying vec4 color;
varying vec3 viewNormal;
varying vec2 lmcoord;

void main() {
    gl_Position = ftransform();
    color = gl_Color;
    viewNormal = normalize(gl_NormalMatrix * gl_Normal);
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
}
