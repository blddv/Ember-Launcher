#version 120
#define DIMENSION_NETHER

#include "/lib/settings.glsl"
#include "/lib/waving.glsl"

attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 upPosition;
uniform float frameTimeCounter;
uniform float rainStrength;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 color;
varying vec3 viewNormal;
varying float matId;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    color = gl_Color;
    viewNormal = normalize(gl_NormalMatrix * gl_Normal);

    int entityId = int(mc_Entity.x + 0.5);

    if (entityId == 10002 || entityId == 10003 || entityId == 10004 || entityId == 10007) {
        matId = 0.20; // Foliage / Subsurface scattering material
        // Smooth upward normal bias for grass & cross-model plants
        if (entityId == 10002 || entityId == 10004) {
            viewNormal = normalize(mix(viewNormal, normalize(upPosition), 0.65));
        }
    } else if (entityId == 10005) {
        matId = 0.30; // Emissive block / ore
    } else {
        matId = 0.10; // Standard solid block
    }

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vec4 playerPos = gbufferModelViewInverse * viewPos;

    playerPos.xyz = applyWaving(
        playerPos.xyz,
        cameraPosition,
        entityId,
        texcoord,
        mc_midTexCoord.xy,
        frameTimeCounter,
        rainStrength
    );

    gl_Position = gl_ProjectionMatrix * (gbufferModelView * playerPos);
}
