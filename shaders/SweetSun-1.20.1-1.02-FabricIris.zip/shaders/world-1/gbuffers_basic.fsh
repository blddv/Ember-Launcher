#version 120
#define DIMENSION_NETHER

varying vec4 color;
varying vec3 viewNormal;
varying vec2 lmcoord;

/* DRAWBUFFERS:012 */
void main() {
    if (color.a < 0.1) discard;
    vec3 n = (length(viewNormal) > 0.01) ? normalize(viewNormal) : vec3(0.0, 1.0, 0.0);
    gl_FragData[0] = color;
    gl_FragData[1] = vec4(n * 0.5 + 0.5, 1.0);
    gl_FragData[2] = vec4(clamp(lmcoord, 0.0, 1.0), 0.10, 1.0);
}
