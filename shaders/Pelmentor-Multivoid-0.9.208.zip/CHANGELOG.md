## 0.9.208

- **Update together.** A lobby admits only players on the same build: lobbies of other builds
  still show in the browser but refuse the join. Players who stay on b150 can play among themselves.

**Joining and lobbies**

- Two master servers, in the USA and in the EU: the browser has a tab for each, and a host
  announces its lobby to the one it picks.
- A lobby's row shows its real player count (it used to read "1/4") and how its players reach
  the host: direct, LAN or relay.
- Joining through the relay keeps working after the first two minutes: the host's relay
  credential is renewed with every heartbeat.
- The join screen shows the host's world downloading, a join waits on the step that is working
  instead of one fixed timeout, and a failed join names the step it failed at.
- A large world downloads without choking the connection: sending is paced to what the link
  actually delivers.
- A joiner loads in the host's game mode, keeps its own inventory, health and spot, and a join
  during an event gets the live world.
- A join started from inside a world of your own leaves it for the menu and loads the host's.
- The relay policy and the listen port you set apply to every session, and a relay setting a
  session cannot honour is refused by name.
- Hosting a save from another game version warns first.
- The main menu shows a thanks list.

**The world**

- A coop session plays by the save's world rules (fall damage, for one) and starts on the save's
  day; it used to run on the defaults.
- The clock is the host's: a client's time of day and its midnight follow the host's.
- Weather and world events come from the host: lightning, the red sky, the sky eye, jellyfish.
- Power is the host's: the power panel, the generators, their repair puzzles, upgrades and wear;
  a client's upgrade the host refuses is handed back.
- Doors, keypads, light switches, light groups, the garage door, lockers, lids and appliances are
  shared as they are used; a client's door press, hit and pry run on the host, doors close by
  themselves again, and a client's keypad works after a blackout and a repair.
- Doors, lights, light groups and containers are named the same way on every machine, so a
  client's presses reach them.
- An oven repaired by one player is repaired for everyone.
- A container take is judged by the player's reach to it, and a container's view closes when you
  walk away from it.
- Shop upgrades are the host's, and so is the bill; a client earns into the shared balance.

**The signal desk and its devices**

- The desk runs on the host: downloading, pinging, the scan needle, the dish's calibration and
  precision, the hash codes, the coordinate towers, decoding on the refiner, saving a signal (its
  photo too) and the signal database; a client's press is carried out on the host's desk.
- The drive slots, the drive rack, the drive box, the eraser, the laptop's disc slot and the
  server boxes (breaking, repairing, upgrades) are the host's.
- A player who joins in the middle of a download or a decode gets it as it stands.
- A device no longer takes a drive or a module another player is carrying out of their hands.
- A disc keeps its contents when it is handed over or ejected, and a disc put into a signal
  server stays there for everyone, a joining player included.

**Props, trash and tools**

- Props keep one identity across players, so a prop moved, frozen or freed by one player does the
  same for everyone: a wall-mounted fire extinguisher, a sign or a torch holder pried off its wall.
- A prop a client spawns from the spawn menu reaches everyone.
- A client no longer deletes props the host still holds.
- Trash piles, clumps and the broom are the host's; a client's sweeping, bagging and carrying
  reach everyone.
- Cleaning grime and windows, and the wall fixer's repairs, reach everyone.
- A deployed hook, and what it drags, is visible to everyone.

**Creatures**

- The plain kerfur thinks on the host; a Kerfus a client turns on follows that client, and a
  thrown Kerfus no longer vanishes for the other players.
- The drone rests where the host's does, and a client's press of the drone console runs on the
  host.

**Stability**

- One cause of the "Fatal Error!" crash at game start is removed: the mod's hook install no longer
  races the game's embedded browser.
- The mod keeps an index of the game's objects instead of rescanning them every frame.
- The host's log no longer fills with false alarms while somebody joins.

Known limitations:

- The desk's back panels and the drone's sack are not shared yet.
- When one player carries a device and another a prop that fits it, neither of their worlds takes
  the prop.

## 0.9.150

- **INSTALL CHANGE — if you are on b133, uninstall it before installing this.** Multivoid
  is now a normal UE4SS mod (`Mods/Multivoid/`), so it installs through r2modman or
  Thunderstore Mod Manager, or by hand into the game's `Mods` folder. The old standalone
  loader is gone, and this build **refuses to start** if a leftover `multivoid-*.dll` or
  `votv-coop.dll` is still sitting next to the game executable — it will tell you so in a
  dialog rather than failing quietly. Steps: `docs/install.md`.
- **Four scientist skins ship with the mod.** They are in the package; no separate download.
  The F1 skin picker now only lists skins the game can actually put on you, and picking one
  that briefly fails to load no longer wipes the skin you had chosen.
- **The in-game server browser is now the game's own UI, not an overlay.** It opens from the
  main menu, uses VOTV's colours and sounds, and supports hovering, selecting, scrolling,
  Connect, Host, Refresh and Back. The old F1 browser is still there as a fallback if you
  turn it on in `multivoid.ini`.
- **You are only let into a lobby after proving who you are.** Every install now has a durable
  keypair, and both sides prove themselves to each other before a seat is spent — the host
  proves itself first. Your saved data is keyed to that identity instead of to a name anyone
  could type.
- **Lobby passwords are enforced.** "Locked" used to be a label on a lobby that anyone could
  still walk into. A password now actually gates admission, and it is bound to the host's key
  so it cannot be replayed at a different host.
- **Nobody can take over your lobby's name on the matchmaking server.** Registrations are
  signed now, and the client refuses to talk to a relay that does not challenge it.
- **Death no longer ends the session.** You hear the death, the screen goes black, and then
  you are revived where you were, instead of the game unloading the world and throwing
  everyone to the main menu. The red damage overlay no longer stays on your screen afterwards,
  and a dead player can open the pause menu again.
- **Shopping and coins are real transactions now.** Laptop shop orders are priced by the host
  from its own table instead of by the buyer, the coin gun's sales are performed by the host,
  and a client can finally pick up coins the host dropped.
- **The ATV is drivable together.** A peer that is not driving no longer freezes its copy of
  the ATV; it simulates and is steered onto the driver's pose. Tyre wear, dirt and damage now
  travel with it, so both players see the same vehicle condition.
- **Light switches and the lamps they drive agree across peers.** Previously only the switch's
  own click travelled and the lights themselves were left to each player's world.
- **The F1 overlay works with RTSS, MSI Afterburner and OBS.** It used to be invisible while
  RTSS was running, and OBS's default game capture did not record it at all. Both are fixed on
  DirectX 11 and DirectX 12.
- **Hosting can be done more than once per session.** The second time you hosted a New Game it
  failed on a duplicate save name and dumped you back to the browser with no reason shown.
  Server names are also editable on the session settings screen now.
- **A host who quit to the menu and hosted a different map could send the joining player an
  empty world** — two ATVs, every door disagreeing. The host now refuses to send a world that
  describes nothing.
- **Rejoining a session no longer crashes the game.**
- Chat, names and non-English text carry over from b133 unchanged, and every text field the
  game owns keeps its keys — the mod does not steal them.

Known limitation: if the host refuses a coin-gun sale, the item is still consumed. Refusals
should be rare now that the underlying cause is fixed, but the sale is not yet atomic.

This is a development prerelease. Please report what breaks:
https://github.com/VOTV-MP/Multivoid/issues

## 0.9.133

- **Chat now has history.** Press `T` and the last messages fade back in above the
  input bar; `PgUp`/`PgDn` page through them, and the fade-out clock stops while you
  are reading so nothing expires under you. A player who joins mid-session is seeded
  with the lobby's chat record instead of arriving to an empty feed.
- **The player list (tilde) answers the same question on every row.** It now lists
  everyone — the host, other clients, and yourself — with an ID column, and shows how
  each player reaches the session plus their ping. Your own row is no longer blank.
- **Names are unique and the host decides them.** If two players ask for the same
  name the host hands out `Name2`, `Name3`, and the assignment is written back to
  `multivoid.ini`, so you keep it next session. Names that merely *look* identical
  (Latin `A` vs Cyrillic `А`) still count as taken.
- **Non-English names and chat actually render.** Cyrillic, Greek, Hebrew, Thai,
  Arabic, Tamil, Dhivehi and Latin-Extended text now draw instead of falling back to
  boxes — 4,700+ characters that were previously unrenderable, plus emoji. Combining
  marks are included, so scripts written entirely with them (Dhivehi) are writable at
  all. Case-insensitive name matching now covers Greek, Armenian, Georgian and
  Latin-Extended, which it silently did not before.
- **The mouse cursor is visible again in the multiplayer menus.** At any UI scale
  below 1.0 the software cursor was being drawn at zero size — present, tracking, and
  completely invisible.
- **The mod no longer steals keys the game is typing.** You can type at the in-game
  SAT server console, the notepad, save-slot names and the settings search without
  `T` opening chat or `V` opening the voice panel. Function keys still reach the mod,
  so `F1` works even inside a game interface. (GitHub issue #5.)
- **Nameplates:** the name and ping are centred on the health bar as one label, and a
  client now sees the host's ping instead of a blank.
- **A message you just sent no longer flickers** out of the chat feed and back in.
- The overlay renders correctly under DirectX 12, including a fix for a rare crash in
  its texture-release path.
- Chat text arriving from other players is now validated as UTF-8 at the receive
  boundary and refused if malformed.

## 0.9.128

- The in-game overlay (F1 menu, chat, nameplates, dialogs) now renders under
  DirectX 12 — it was DX11-only before. If you launch VotV with `-dx12`, the
  mod's UI now draws instead of logging a warning.
- The F1 menu shows which graphics API the game is running on ("Graphics API:
  DX11/DX12").
- The "Tidy up" button in the boot-time SETTINGS CHECK notice now actually
  works: it reformats `multivoid.ini` and comments out unknown or invalid
  lines. It was a dead button before.
- New install guide: [docs/install.md](https://github.com/VOTV-MP/Multivoid/blob/main/docs/install.md)
  — release pages now carry install steps and this changelog section.
- README gained a Credits section (prior art: MTA:SA, RE-UE4SS, MinHook,
  VoidTogether) and a living playbook for porting the mod to future VotV
  versions (`docs/versioning.md`).

## 0.9.127

- `multivoid.ini.example` is now generated next to `multivoid.ini` on every
  boot: a catalog of every setting the mod reads, each with a description.
  `multivoid.ini` itself is never overwritten.
- Internal config-system hardening (typed settings registry; a CI gate keeps
  the settings catalog and the code in lockstep).
- `BUILDING.md`: the mod can now be built from source via GitHub Actions alone,
  no local toolchain needed.

## 0.9.126

- First public development build.
- The whole co-op layer as of July 2026: shared world and props, host-scheduled
  events and NPCs, the signal desk, proximity voice and text chat, server
  browser and direct connect, skins.
- Settings live in one file next to the game executable (`multivoid.ini`); on
  boot the mod checks it and shows a SETTINGS CHECK notice if something is off.
