/* 
BSL Shaders v8 Series by Capt Tatsu 
https://bitslablab.com 
*/ 

//Settings//
#include "/lib/settings.glsl"

//Fragment Shader///////////////////////////////////////////////////////////////////////////////////
#ifdef FSH

//Varyings//
varying float star;

varying vec3 upVec, sunVec;
varying vec3 sunTan, sunNorm;

//Uniforms//
uniform int isEyeInWater;
uniform int worldTime;

uniform float blindFactor;
uniform float frameCounter;
uniform float frameTimeCounter;
uniform float nightVision;
uniform float rainStrength;
uniform float shadowFade, voidFade;
uniform float timeAngle, timeBrightness;
uniform float viewWidth, viewHeight;

uniform ivec2 eyeBrightnessSmooth;

uniform vec3 cameraPosition;

uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;

uniform sampler2D noisetex;

//Common Variables//
#ifdef WORLD_TIME_ANIMATION
float frametime = float(worldTime) * 0.05 * ANIMATION_SPEED;
#else
float frametime = frameTimeCounter * ANIMATION_SPEED;
#endif

float eBS = eyeBrightnessSmooth.y / 240.0;
float sunVisibility  = clamp((dot( sunVec, upVec) + 0.05) * 10.0, 0.0, 1.0);
float moonVisibility = clamp((dot(-sunVec, upVec) + 0.05) * 10.0, 0.0, 1.0);

vec3 lightVec = sunVec * (1.0 - 2.0 * float(timeAngle > 0.5325 && timeAngle < 0.9675));

//Common Functions//
float GetLuminance(vec3 color) {
	return dot(color,vec3(0.299, 0.587, 0.114));
}

void RoundSunMoon(inout vec3 color, vec3 viewPos, vec3 sunColor, vec3 moonColor) {
	float VoL = dot(normalize(viewPos),sunVec);
	float isMoon = float(VoL < 0.0);
	float sun = pow(abs(VoL), 800.0 * isMoon + 800.0) * (1.0 - sqrt(rainStrength));

	vec3 sunMoonCol = mix(moonColor * moonVisibility, sunColor * sunVisibility, float(VoL > 0.0));
	color += sun * sunMoonCol * 32.0;
}

void SunGlare(inout vec3 color, vec3 viewPos, vec3 lightCol) {
	float VoL = dot(normalize(viewPos), lightVec);
	float visfactor = 0.05 * (-0.8 * timeBrightness + 1.0) * (3.0 * rainStrength + 1.0);
	float invvisfactor = 1.0 - visfactor;

	float visibility = clamp(VoL * 0.5 + 0.5, 0.0, 1.0);
    visibility = visfactor / (1.0 - invvisfactor * visibility) - visfactor;
	visibility = clamp(visibility * 1.015 / invvisfactor - 0.015, 0.0, 1.0);
	visibility = mix(1.0, visibility, 0.25 * eBS + 0.75) * (1.0 - rainStrength * eBS * 0.875);
	visibility *= shadowFade * LIGHT_SHAFT_STRENGTH;
	//visibility *= voidFade;
	#if MC_VERSION >= 11800
	visibility *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
	#else
	visibility *= clamp((cameraPosition.y + 6.0) / 8.0, 0.0, 1.0);
	#endif

	#ifdef LIGHT_SHAFT
	if (isEyeInWater == 1) color += 0.25 * lightCol * visibility;
	#else
	color += 0.25 * lightCol * visibility * (1.0 + 0.25 * isEyeInWater);
	#endif
}

//Includes//
#include "/lib/color/dimensionColor.glsl"
#include "/lib/color/skyColor.glsl"
#include "/lib/util/dither.glsl"
#include "/lib/atmospherics/clouds.glsl"
#include "/lib/atmospherics/sky.glsl"

//Celestial-space helper (Super Duper Vanilla style sun, moon, stars and aether)
//x/y are the coordinates on the plane of the sky that rotates with the sun, z points at the sun
vec3 GetCelestialPos(vec3 nViewPos) {
	return vec3(dot(nViewPos, sunTan), dot(nViewPos, sunNorm), dot(nViewPos, sunVec));
}

#ifdef OVERWORLD

float SDVSunMoonShape(vec3 celestialPos) {
	#if SUN_MOON_SHAPE == 1
	float r = pow(abs(celestialPos.x * celestialPos.x * celestialPos.x) +
				  abs(celestialPos.y * celestialPos.y * celestialPos.y), 0.33333333);
	#else
	float r = sqrt(max(1.0 - celestialPos.z * celestialPos.z, 0.0));
	#endif
	return min(1.0, exp2((SUN_MOON_SIZE - r) * 256.0));
}

void ShapedSunMoon(inout vec3 color, vec3 viewPos, vec3 sunColor, vec3 moonColor) {
	vec3 nViewPos = normalize(viewPos);
	vec3 celestialPos = GetCelestialPos(nViewPos);

	float shape = SDVSunMoonShape(celestialPos) * (1.0 - sqrt(rainStrength));
	vec3 sunMoonCol = mix(moonColor * moonVisibility, sunColor * sunVisibility, float(celestialPos.z > 0.0));

	color += shape * sunMoonCol * 16.0 * SUN_MOON_INTENSITY;
}

//Black hole sun and moon, returns 1.0 inside of the event horizon
float DrawBlackHole(inout vec3 color, vec3 viewPos, vec3 lightColor) {
	vec3 nViewPos = normalize(viewPos);
	vec3 celestialPos = GetCelestialPos(nViewPos);
	//Follows whichever of the sun or moon is currently in the sky
	float side = dot(lightVec, sunVec);
	celestialPos.z *= side;
	celestialPos.x *= side;

	float holeSize = 1024.0 - SUN_MOON_SIZE * 64.0;
	float hole = holeSize - celestialPos.z * 1024.0;

	if (hole <= 0.0) return 1.0;
	hole = 1.0 / max(1.0, hole);

	const float rotationFactor = 6.28318530718 * 16.0;
	float rot = hole * rotationFactor;
	vec2 rotated = vec2(
		cos(rot) * celestialPos.x - sin(rot) * celestialPos.y,
		sin(rot) * celestialPos.x + cos(rot) * celestialPos.y
	);
	vec2 ringCoord = vec2(rotated.x * hole, frametime * 0.0009765625);
	float rings = texture2D(noisetex, ringCoord).r;

	color += (rings * hole * 0.9 + hole * 0.1) * lightColor * 16.0 * SUN_MOON_INTENSITY * (1.0 - rainStrength);
	return 0.0;
}

//Soft pastel nebula clouds that rotate with the night sky
void DrawNebula(inout vec3 color, vec3 viewPos) {
	vec3 nViewPos = normalize(viewPos);
	vec3 celestialPos = GetCelestialPos(nViewPos);
	float VoU = dot(nViewPos, upVec);

	vec2 plane = celestialPos.xy / (abs(celestialPos.z) + 1.0);
	vec2 q = plane * 18.0 + vec2(40.0, 70.0);
	float n1 = texture2D(noisetex, q / 512.0).g;
	float n2 = texture2D(noisetex, (q * 2.3 + vec2(120.0, 60.0)) / 512.0).g;

	float nebula = smoothstep(0.27, 0.42, n1 * 0.65 + n2 * 0.35);
	vec3 nebulaCol = mix(vec3(1.0, 0.55, 0.85), vec3(0.45, 0.55, 1.0), clamp(n2 * 3.2, 0.0, 1.0));

	float night = moonVisibility * (1.0 - rainStrength) * clamp(VoU * 6.0 + 0.5, 0.0, 1.0);
	color += nebulaCol * nebula * 0.05 * SKY_NEBULA_STRENGTH * night;
}

//Stars that rotate along with the sky, in the style of Super Duper Vanilla
void DrawStarsSDV(inout vec3 color, vec3 viewPos) {
	vec3 celestialPos = GetCelestialPos(normalize(viewPos));
	float VoU = dot(normalize(viewPos), upVec);

	vec2 coord = floor(celestialPos.xy * 256.0 / (abs(celestialPos.z) + sqrt(max(1.0 - celestialPos.z * celestialPos.z, 0.0))));
	float a = texture2D(noisetex, (mod(coord, 512.0) + 0.5) / 512.0).b;
	float b = texture2D(noisetex, (mod(coord + vec2(137.0, 59.0), 512.0) + 0.5) / 512.0).b;
	float starVal = exp(a * b * 64.0 - 64.0);

	starVal *= (1.0 - rainStrength) * moonVisibility * clamp(VoU * 8.0 + 0.5, 0.0, 1.0);
	#if MC_VERSION >= 11800
	starVal *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
	#else
	starVal *= clamp((cameraPosition.y + 6.0) / 8.0, 0.0, 1.0);
	#endif
	#ifdef UNDERGROUND_SKY
	starVal *= mix(clamp((cameraPosition.y - 48.0) / 16.0, 0.0, 1.0), 1.0, eBS);
	#endif

	color += starVal * 16.0 * STAR_BRIGHTNESS * pow(lightNight, vec3(1.8));
}

//Animated aether glow along the horizon, in the style of Super Duper Vanilla
void DrawAether(inout vec3 color, vec3 viewPos, vec3 lightColor) {
	vec3 nViewPos = normalize(viewPos);
	vec3 celestialPos = GetCelestialPos(nViewPos);
	float VoU = dot(nViewPos, upVec);

	vec2 skyCoord = celestialPos.xy * 256.0;
	float speed = floor(frametime * 8.0 * AETHER_SPEED);

	vec2 c0 = floor(vec2(255.0) - skyCoord - speed);
	vec2 c1 = vec2(c0.x, floor(skyCoord.y - speed));
	vec2 c2 = vec2(floor(skyCoord.x - speed), c0.y);

	vec3 aetherNoise = vec3(
		texture2D(noisetex, (mod(c0, 512.0) + 0.5) / 512.0).b,
		texture2D(noisetex, (mod(c1, 512.0) + 0.5) / 512.0).b,
		texture2D(noisetex, (mod(c2, 512.0) + 0.5) / 512.0).b
	);
	float aetherSum = aetherNoise.x + aetherNoise.y + aetherNoise.z;
	vec3 aether = aetherNoise * lightColor + aetherSum * 0.66666666;

	float horizon = exp2(-abs(VoU) * 8.0) * clamp(VoU * 8.0 + 1.0, 0.0, 1.0);
	color += horizon * aether * aether * aether * lightColor * AETHER_INTENSITY * 0.25 * (1.0 - rainStrength);
}
#endif

//Program//
void main() {
	#ifdef OVERWORLD
	vec4 screenPos = vec4(gl_FragCoord.xy / vec2(viewWidth, viewHeight), gl_FragCoord.z, 1.0);
	vec4 viewPos = gbufferProjectionInverse * (screenPos * 2.0 - 1.0);
	viewPos /= viewPos.w;
	
	vec3 albedo = GetSkyColor(viewPos.xyz, false);
	
	float blackHole = 0.0;
	#ifdef ROUND_SUN_MOON
	vec3 lightMA = mix(lightMorning, lightEvening, mefade);
    vec3 sunColor = mix(lightMA, sqrt(lightDay * lightMA * LIGHT_DI), timeBrightness);
    vec3 moonColor = sqrt(lightNight);

	#if SUN_MOON_SHAPE == 0
	RoundSunMoon(albedo, viewPos.xyz, sunColor, moonColor);
	#elif SUN_MOON_SHAPE == 3
	vec3 holeColor = mix(moonColor * moonVisibility, sunColor * sunVisibility, sunVisibility);
	blackHole = DrawBlackHole(albedo, viewPos.xyz, holeColor);
	#else
	ShapedSunMoon(albedo, viewPos.xyz, sunColor, moonColor);
	#endif
	#endif

	#ifdef SKY_NEBULA
	if (moonVisibility > 0.0) DrawNebula(albedo.rgb, viewPos.xyz);
	#endif

	#ifdef STARS
	if (moonVisibility > 0.0) {
		#if STAR_STYLE == 1
		DrawStarsSDV(albedo.rgb, viewPos.xyz);
		#else
		DrawStars(albedo.rgb, viewPos.xyz);
		#endif
	}
	#endif

	#ifdef SKY_AETHER
	DrawAether(albedo.rgb, viewPos.xyz, mix(sqrt(lightNight), sqrt(lightDay), sunVisibility));
	#endif

	float dither = Bayer64(gl_FragCoord.xy);

	#ifdef AURORA
	albedo.rgb += DrawAurora(viewPos.xyz, dither, 24);
	#endif
	
	#if (CLOUDS == 1 || CLOUDS == 3)
	vec4 cloud = DrawCloud(viewPos.xyz, dither, lightCol, ambientCol);
	albedo.rgb = mix(albedo.rgb, cloud.rgb, cloud.a);
	#endif

	#if defined ROUND_SUN_MOON && SUN_MOON_SHAPE == 3
	albedo.rgb *= 1.0 - blackHole;
	#endif

	SunGlare(albedo, viewPos.xyz, lightCol);

	albedo.rgb *= (4.0 - 3.0 * eBS) * (1.0 + nightVision);

	#if ALPHA_BLEND == 0
	albedo.rgb = sqrt(max(albedo.rgb, vec3(0.0)));
	albedo.rgb = albedo.rgb + dither / vec3(64.0);
	#endif
	#endif
	
	#ifdef END
	vec3 albedo = vec3(0.0);
	#endif
	
    /* DRAWBUFFERS:0 */
	gl_FragData[0] = vec4(albedo, 1.0 - star);
    #if defined OVERWORLD && (CLOUDS == 1 || CLOUDS == 3)
    /* DRAWBUFFERS:04 */
	gl_FragData[1] = vec4(cloud.a, 0.0, 0.0, 0.0);
    #endif
}

#endif

//Vertex Shader/////////////////////////////////////////////////////////////////////////////////////
#ifdef VSH

//Varyings//
varying float star;

varying vec3 sunVec, upVec;
varying vec3 sunTan, sunNorm;

//Uniforms//
uniform float timeAngle;

uniform mat4 gbufferModelView;

//Program//
void main() {
	const vec2 sunRotationData = vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994));
	float ang = fract(timeAngle - 0.25);
	ang = (ang + (cos(ang * 3.14159265358979) * -0.5 + 0.5 - ang) / 3.0) * 6.28318530717959;
	sunVec = normalize((gbufferModelView * vec4(vec3(-sin(ang), cos(ang) * sunRotationData) * 2000.0, 1.0)).xyz);

	upVec = normalize(gbufferModelView[1].xyz);

	//Axes of the plane the sun and moon travel along
	vec3 sunTanPre  = vec3(-cos(ang), -sin(ang) * sunRotationData.x, -sin(ang) * sunRotationData.y);
	vec3 sunNormPre = vec3(0.0, -sunRotationData.y, sunRotationData.x);
	sunTan  = normalize((gbufferModelView * vec4(sunTanPre, 0.0)).xyz);
	sunNorm = normalize((gbufferModelView * vec4(sunNormPre, 0.0)).xyz);
	
	gl_Position = ftransform();

	star = float(gl_Color.r == gl_Color.g && gl_Color.g == gl_Color.b && gl_Color.r > 0.0);
}

#endif