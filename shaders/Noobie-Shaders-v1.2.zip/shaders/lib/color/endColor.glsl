vec4 endColSqrt = vec4(vec3(END_R, END_G, END_B) / 255.0, 1.0) * END_I;
vec4 endCol = endColSqrt * endColSqrt;

#if END_SKY_STYLE == 1
#if END_SKY_PALETTE == 0
//Super Duper Vanilla End colors
vec3 endSkyHorizonSqrt = vec3(15.0, 3.0, 60.0) / 255.0;
vec3 endSkyTopSqrt     = vec3(15.0, 3.0, 60.0) / 255.0;
vec3 endGlowSqrt       = vec3(210.0, 165.0, 255.0) / 255.0;
#elif END_SKY_PALETTE == 1
//Pastel End colors
vec3 endSkyHorizonSqrt = vec3(248.0, 196.0, 214.0) / 255.0 * 0.65;
vec3 endSkyTopSqrt     = vec3(176.0, 160.0, 255.0) / 255.0 * 0.50;
vec3 endGlowSqrt       = vec3(255.0, 214.0, 236.0) / 255.0;
#else
vec3 endSkyHorizonSqrt = vec3(END_SKY_HR, END_SKY_HG, END_SKY_HB) / 255.0 * END_SKY_HI;
vec3 endSkyTopSqrt     = vec3(END_SKY_TR, END_SKY_TG, END_SKY_TB) / 255.0 * END_SKY_TI;
vec3 endGlowSqrt       = vec3(END_GLOW_R, END_GLOW_G, END_GLOW_B) / 255.0 * END_GLOW_I;
#endif
vec3 endSkyHorizonCol  = endSkyHorizonSqrt * endSkyHorizonSqrt;
vec3 endSkyTopCol      = endSkyTopSqrt * endSkyTopSqrt;
vec3 endGlowCol        = endGlowSqrt * endGlowSqrt;
#endif
