/* 
██████████████████████████
█░░░▒▒▒░░░▒▒▒░░░▒▒▒░░░▒▒▒█
█░░░▒▒▒░░░▒▒▒░░░▒▒▒░░░▒▒▒█
█▒▒▒░░░▒▒▒░░░▒▒▒░░░▒▒▒░░░█
█▒▒▒░░░▒▒▒░░░▒▒▒░░░▒▒▒░░░█
█░░░██████▒▒▒░░░██████▒▒▒█
█░░░██████▒▒▒░░░██████▒▒▒█
█▒▒▒██████░░░▒▒▒██████░░░█
█▒▒▒██████░░░▒▒▒██████░░░█
█░░░▒▒▒░░░██████▒▒▒░░░▒▒▒█
█░░░▒▒▒░░░██████▒▒▒░░░▒▒▒█
█▒▒▒░░░████████████▒▒▒░░░█
█▒▒▒░░░████████████▒▒▒░░░█
█░░░▒▒▒████████████░░░▒▒▒█
█░░░▒▒▒████████████░░░▒▒▒█
█▒▒▒░░░███░░░▒▒▒███▒▒▒░░░█
█▒▒▒░░░███░░░▒▒▒███▒▒▒░░░█
█░░░▒▒▒░░░▒▒▒░░░▒▒▒░░░▒▒▒█
█░░░▒▒▒░░░▒▒▒░░░▒▒▒░░░▒▒▒█
██████████████████████████
INSANITY SHADER by Alm
Based on BSL
*/ 

#ifdef SKY_VANILLA
uniform vec3 skyColor;
uniform vec3 fogColor;

vec3 skyCol = pow(skyColor, vec3(2.2)) * SKY_I * SKY_I;
vec3 fogCol = pow(fogColor, vec3(2.2)) * SKY_I * SKY_I;
#else
vec3 skyColSqrt = vec3(SKY_R, SKY_G, SKY_B) * SKY_I / 255.0;
vec3 skyCol = skyColSqrt * skyColSqrt;
vec3 fogCol = skyColSqrt * skyColSqrt;
#endif

#if SKY_STYLE == 1
vec3 sdvDayTopSqrt       = vec3(SDVSKY_DR, SDVSKY_DG, SDVSKY_DB) / 255.0 * SDVSKY_DI;
vec3 sdvDayHorizonSqrt   = vec3(SDVSKY_HR, SDVSKY_HG, SDVSKY_HB) / 255.0 * SDVSKY_HI;
vec3 sdvTwilightHorSqrt  = vec3(SDVSKY_TR, SDVSKY_TG, SDVSKY_TB) / 255.0 * SDVSKY_TI;
vec3 sdvTwilightTopSqrt  = vec3(SDVSKY_UR, SDVSKY_UG, SDVSKY_UB) / 255.0 * SDVSKY_UI;
vec3 sdvNightTopSqrt     = vec3(SDVSKY_NR, SDVSKY_NG, SDVSKY_NB) / 255.0 * SDVSKY_NI;
vec3 sdvNightHorizonSqrt = vec3(SDVSKY_MR, SDVSKY_MG, SDVSKY_MB) / 255.0 * SDVSKY_MI;
vec3 sdvDayTop       = sdvDayTopSqrt * sdvDayTopSqrt;
vec3 sdvDayHorizon   = sdvDayHorizonSqrt * sdvDayHorizonSqrt;
vec3 sdvTwilightHor  = sdvTwilightHorSqrt * sdvTwilightHorSqrt;
vec3 sdvTwilightTop  = sdvTwilightTopSqrt * sdvTwilightTopSqrt;
vec3 sdvNightTop     = sdvNightTopSqrt * sdvNightTopSqrt;
vec3 sdvNightHorizon = sdvNightHorizonSqrt * sdvNightHorizonSqrt;
vec3 skyOverlayCol   = pow(vec3(SKY_OVERLAY_R, SKY_OVERLAY_G, SKY_OVERLAY_B) / 255.0, vec3(2.2));
#endif
