#ifdef OVERWORLD
vec3 GetSkyColor(vec3 viewPos, bool isReflection) {
    vec3 nViewPos = normalize(viewPos);

    float VoU = clamp(dot(nViewPos,  upVec), -1.0, 1.0);
    float VoL = clamp(dot(nViewPos, sunVec), -1.0, 1.0);

    float groundDensity = 0.1 * (4.0 - 3.0 * sunVisibility) *
                          (10.0 * rainStrength * rainStrength + 1.0);
    
    float exposure = exp2(timeBrightness * 0.75 - 0.75 + SKY_EXPOSURE_D);
    float nightExposure = exp2(-3.5 + SKY_EXPOSURE_N);
    float weatherExposure = exp2(SKY_EXPOSURE_W);

    float gradientCurve = mix(SKY_HORIZON_F, SKY_HORIZON_N, VoL);
    float baseGradient = exp(-(1.0 - pow(1.0 - max(VoU, 0.0), gradientCurve)) /
                             SKY_DENSITY_D);

    #if SKY_GROUND > 0
    float groundVoU = clamp(-VoU * 1.015 - 0.015, 0.0, 1.0);
    float ground = 1.0 - exp(-groundDensity * max(FOG_DENSITY, 0.125) / groundVoU);
    #if SKY_GROUND == 1
    if (!isReflection) ground = 1.0;
    #endif
    #else
    float ground = 1.0;
    #endif

    #if SKY_STYLE == 1
    //Super Duper style sky: palette with a gradient from horizon to zenith, soft sun and moon glow, pastel overlay
    float sunElev = dot(sunVec, upVec);
    float dayAmt = smoothstep(-0.06, 0.35, sunElev);
    float twiAmt = 1.0 - smoothstep(0.0, 0.42, abs(sunElev + 0.05));
    float twiDir = 0.3 + 0.7 * pow(VoL * 0.5 + 0.5, 1.5);
    float horizonT = pow(1.0 - clamp(VoU, 0.0, 1.0), 3.0);

    vec3 sky = mix(mix(sdvNightTop, sdvNightHorizon, horizonT), mix(sdvDayTop, sdvDayHorizon, horizonT), dayAmt);
    sky = mix(sky, mix(sdvTwilightTop, sdvTwilightHor, horizonT), clamp(twiAmt * twiDir, 0.0, 1.0));

    //Diffuse glow around the sun or moon, plus a soft halo
    float glow = pow(VoL * VoL, abs(VoU) + 1.0) * SKY_GLOW;
    vec3 glowCol = VoL > 0.0 ? mix(lightSun * lightSun, vec3(0.9, 0.75, 0.6), 0.5) * dayAmt : lightNight * (1.0 - dayAmt) * 1.5;
    sky += glowCol * glow * 0.35;

    float sunHalo = pow(max(VoL, 0.0), 14.0) * SKY_SUN_HALO * dayAmt;
    sky += mix(vec3(0.12, 0.095, 0.07), vec3(0.14, 0.07, 0.06), twiAmt) * sunHalo;
    float moonHalo = pow(max(-VoL, 0.0), 24.0) * SKY_SUN_HALO * (1.0 - dayAmt);
    sky += vec3(0.020, 0.024, 0.045) * moonHalo;

    float horizonLift = pow(1.0 - max(VoU, 0.0), 4.0) * 0.35;
    sky += (sky * 0.5 + skyOverlayCol * 0.1) * horizonLift * dayAmt;

    float overlayAmount = SKY_OVERLAY_I * mix(0.10, 1.0, dayAmt);
    sky = 1.0 - (1.0 - sky) * (1.0 - skyOverlayCol * overlayAmount);

    //Pastel filter: softer saturation, slightly lifted midtones
    vec3 pastelSky = sqrt(max(sky, vec3(0.0)));
    pastelSky = mix(pastelSky, vec3(GetLuminance(pastelSky)), 0.18 * SKY_PASTEL_FILTER);
    pastelSky = pow(pastelSky, vec3(1.0 - 0.06 * SKY_PASTEL_FILTER));
    sky = pastelSky * pastelSky;
    #else
    vec3 sky = skyCol * baseGradient / (SKY_I * SKY_I);
    #ifdef SKY_VANILLA
    sky = mix(sky, fogCol * baseGradient, pow(1.0 - max(VoU, 0.0), 4.0));
    #endif
    sky = sky / sqrt(sky * sky + 1.0) * exposure * sunVisibility * (SKY_I * SKY_I);

    float sunMix = (VoL * 0.5 + 0.5) * pow(clamp(1.0 - VoU, 0.0, 1.0), 2.0 - sunVisibility) *
                   pow(1.0 - timeBrightness * 0.6, 3.0);
    float horizonMix = pow(1.0 - abs(VoU), 2.5) * 0.125 * (1.0 - timeBrightness * 0.5);
    float lightMix = (1.0 - (1.0 - sunMix) * (1.0 - horizonMix));

    vec3 lightSky = pow(lightSun, vec3(4.0 - sunVisibility)) * baseGradient;
    lightSky = lightSky / (1.0 + lightSky * rainStrength);

    sky = mix(
        sqrt(sky * (1.0 - lightMix)), 
        sqrt(lightSky), 
        lightMix
    );
    sky *= sky;

    float nightGradient = exp(-max(VoU, 0.0) / SKY_DENSITY_N);
    vec3 nightSky = lightNight * lightNight * nightGradient * nightExposure;
    sky = mix(nightSky, sky, sunVisibility * sunVisibility);
    #endif

    float rainGradient = exp(-max(VoU, 0.0) / SKY_DENSITY_W);
    vec3 weatherSky = weatherCol.rgb * weatherCol.rgb * weatherExposure;
    weatherSky *= GetLuminance(ambientCol / (weatherSky)) * (0.2 * sunVisibility + 0.2);
    sky = mix(sky, weatherSky * rainGradient, rainStrength);

    sky *= ground;

    #ifdef UNDERGROUND_SKY
    float ug = mix(clamp((cameraPosition.y - 48.0) / 16.0, 0.0, 1.0), 1.0, eBS);
    sky = mix(minLightCol * 0.125, sky, ug);
    #endif

    // sky *= voidFade;
	#if MC_VERSION >= 11800
	sky *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
	#else
	sky *= clamp((cameraPosition.y + 6.0) / 8.0, 0.0, 1.0);
	#endif

    return sky;
}

#endif