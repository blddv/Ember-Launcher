//Pastel-filtered End sky ported from Super Duper Vanilla.
//Minecraft draws the End sky through gbuffers_skytextured, so this is evaluated per pixel there and the vanilla texture is not needed.
//Needs: upVec, sunVec, sunTan, sunNorm, frametime, noisetex and the End colors.
//End sky ported from Super Duper Vanilla (getSkyBasic, getSkyHalf and the black hole of getFullSkyRender).
//Like Super Duper, the black hole sits in the direction of the light of the End.
vec3 GetEndSky(vec3 viewPos, out float hole) {
	vec3 nViewPos = normalize(viewPos);
	float y = dot(nViewPos, upVec);
	vec3 celestialPos = vec3(dot(nViewPos, sunTan), dot(nViewPos, sunNorm), dot(nViewPos, sunVec));
	hole = 0.0;

	//Flat sky color
	vec3 sky = mix(endSkyHorizonCol, endSkyTopCol, sqrt(clamp(y, 0.0, 1.0)));

	//Sky ground: the sky fades into the void below the horizon
	if (y < 0.0) sky *= exp2(-(y * y * 8.0) / max(sky * sky, vec3(0.125)));

	//Diffuse glow around the black hole
	if (celestialPos.z > 0.0) sky += endGlowCol * pow(celestialPos.z * celestialPos.z, abs(y) + 1.0) * END_SKY_GLOW;

	#ifdef END_AETHER
	//Aether, smooth noise that drifts along the sky
	vec2 skyCoord = celestialPos.xy * 256.0 * 0.2;
	float shift = frametime * 8.0 * 0.2 * END_AETHER_SPEED;
	vec2 c0 = vec2(255.0 * 0.2) - skyCoord - shift;
	vec2 c1 = vec2(c0.x, skyCoord.y - shift);
	vec2 c2 = vec2(skyCoord.x - shift, c0.y);
	vec3 aetherNoise = vec3(
		texture2D(noisetex, c0 / 512.0).g,
		texture2D(noisetex, c1 / 512.0).g,
		texture2D(noisetex, c2 / 512.0).g
	);
	vec3 aetherMix = aetherNoise * endGlowCol + (aetherNoise.x + aetherNoise.y + aetherNoise.z) * 0.66666666;
	sky += exp2(-abs(y) * 8.0) * aetherMix * aetherMix * aetherMix * endGlowCol * END_AETHER_INTENSITY;
	#endif

	#ifdef END_STARS
	vec2 starCoord = floor(celestialPos.xy * 256.0 / (abs(celestialPos.z) + sqrt(max(1.0 - celestialPos.z * celestialPos.z, 0.0))));
	float starA = texture2D(noisetex, (mod(starCoord, 512.0) + 0.5) / 512.0).b;
	float starB = texture2D(noisetex, (mod(starCoord + vec2(137.0, 59.0), 512.0) + 0.5) / 512.0).b;
	sky += exp(starA * starB * 64.0 - 64.0) * 16.0 * END_STAR_BRIGHTNESS;
	#endif

	#ifdef END_HOLE
	//Black hole
	float holeSize = 1024.0 - END_HOLE_SIZE * 64.0;
	float holeDist = holeSize - celestialPos.z * 1024.0;

	if (holeDist <= 0.0) {
		hole = 1.0;
	} else {
		float glow = 1.0 / max(1.0, holeDist);
		const float rotationFactor = 6.28318530718 * 16.0;
		float rot = glow * rotationFactor;
		vec2 rotated = vec2(
			cos(rot) * celestialPos.x - sin(rot) * celestialPos.y,
			sin(rot) * celestialPos.x + cos(rot) * celestialPos.y
		);
		float rings = texture2D(noisetex, vec2(rotated.x * glow * 0.5, frametime * 0.0009765625)).b;
		sky += (rings * glow * 0.9 + glow * 0.1) * 16.0 * END_HOLE_INTENSITY * endGlowCol;
	}
	#endif

	return sky * (1.0 - hole);
}
