#ifdef OVERWORLD

float CloudSample(vec2 coord, vec2 wind, float currentStep, float sampleStep, float sunCoverage) {
	float noiseA = texture2D(noisetex, coord * 0.25 + wind).r;
	float noiseB = texture2D(noisetex, coord * 0.45 - wind * 2.0).b;

	float noiseCoverage = abs(currentStep - 0.125) * (currentStep > 0.125 ? 1.14 : 8.0);
	noiseCoverage = noiseCoverage * noiseCoverage * 6.0;
	
	float noise = mix(noiseA * 25.0 + noiseB - noiseCoverage, 21.0, 0.33 * rainStrength);
	float multiplier = CLOUD_THICKNESS * sampleStep * (1.0 - 0.75 * rainStrength);

	noise = max(noise - (sunCoverage * 3.0 + CLOUD_AMOUNT), 0.0) * multiplier;
	noise = noise / sqrt(noise * noise + 0.8);

	return noise;
}

vec4 DrawCloudClassic(vec3 viewPos, float dither, vec3 lightCol, vec3 ambientCol) {
	#ifdef TAA
	dither = fract(16.0 * frameTimeCounter + dither);
	#endif

	int samples = 8;
	
	float cloud = 0.0, cloudLighting = 0.0;

	float sampleStep = 1.0 / samples;
	float currentStep = dither * sampleStep;
	
	vec3 nViewPos = normalize(viewPos);
	float VoU = dot(nViewPos, upVec);
	float VoL = dot(nViewPos, lightVec);
	
	float sunCoverage = pow(clamp(abs(VoL) * 2.0 - 1.0, 0.0, 1.0), 12.0) * (1.0 - rainStrength);

	vec2 wind = vec2(
		frametime * CLOUD_SPEED * 0.0005,
		sin(frametime * CLOUD_SPEED * 0.001) * 0.005
	) * CLOUD_HEIGHT / 15.0;

	vec3 cloudColor = vec3(0.0);

	if (VoU > 0.025) {
		vec3 wpos = normalize((gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz);

		float halfVoL = VoL * shadowFade * 0.5 + 0.5;
		float halfVoLSqr = halfVoL * halfVoL;
		float scattering = pow(halfVoL, 6.0);
		float noiseLightFactor = (2.0 - 1.5 * VoL * shadowFade) * CLOUD_THICKNESS * 0.5;

		for(int i = 0; i < samples; i++) {
			if (cloud > 0.99) break;
			vec3 planeCoord = wpos * ((CLOUD_HEIGHT + currentStep * 4.0) / wpos.y) * 0.004;
			vec2 coord = cameraPosition.xz * 0.00025 + planeCoord.xz;

			float noise = CloudSample(coord, wind, currentStep, sampleStep, sunCoverage);

			float sampleLighting = pow(currentStep, 1.125 * halfVoLSqr + 0.875) * 0.8 + 0.2;
			sampleLighting *= 1.0 - pow(noise, noiseLightFactor);

			cloudLighting = mix(cloudLighting, sampleLighting, noise * (1.0 - cloud * cloud));
			cloud = mix(cloud, 1.0, noise);

			currentStep += sampleStep;
		}	
		cloudLighting = mix(cloudLighting, 1.0, (1.0 - cloud * cloud) * scattering * 0.5);
		cloudColor = mix(
			ambientCol * (0.35 * sunVisibility + 0.5),
			lightCol * (0.85 + 1.15 * scattering),
			cloudLighting
		);
		cloudColor *= 1.0 - 0.6 * rainStrength;
		cloud *= clamp(1.0 - exp(-20.0 * VoU + 0.5), 0.0, 1.0) * (1.0 - 0.6 * rainStrength);
	}
	cloudColor *= CLOUD_BRIGHTNESS * (0.5 - 0.25 * (1.0 - sunVisibility) * (1.0 - rainStrength));
	// cloudColor *= voidFade;
	#if MC_VERSION >= 11800
	cloudColor *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
	#else
	cloudColor *= clamp((cameraPosition.y + 6.0) / 8.0, 0.0, 1.0);
	#endif
	
	#ifdef UNDERGROUND_SKY
	cloud *= mix(clamp((cameraPosition.y - 48.0) / 16.0, 0.0, 1.0), 1.0, eBS);
	#endif
	
	return vec4(cloudColor, cloud * cloud * CLOUD_OPACITY);
}

//Skybox clouds in the style of Super Duper Vanilla (FlameRender Studios, Eldeston)
//The cloud map is stored in the alpha channel of noisetex (256x256 tile, 4 levels: none / layer A / layer B / both)
vec2 SDVCloudMap(vec2 cell) {
	vec2 uv = (mod(floor(cell), 256.0) + 0.5) / 512.0;
	float level = clamp(floor(texture2D(noisetex, uv).a * 5.0 + 0.5) - 1.0, 0.0, 3.0);
	return vec2(mod(level, 2.0), floor(level * 0.5));
}

//Stacked parallax layers: the deepest layer that still hits a cloud gives the cloud its thickness
vec2 SDVCloudParallax(vec2 start, vec2 cameraPos) {
	vec2 stepEnd = start * (SDV_CLOUD_DEPTH / float(SDV_CLOUD_STEPS));
	start += cameraPos * 0.0625;

	vec2 data = vec2(0.0);
	for (int i = 1; i <= SDV_CLOUD_STEPS; i++) {
		vec2 cloudMap = SDVCloudMap(start);
		if (cloudMap.x > 0.5) data.x = float(i);
		if (cloudMap.y > 0.5) data.y = float(i);
		start -= stepEnd;
	}
	return data / float(SDV_CLOUD_STEPS);
}

vec4 DrawCloudSDV(vec3 viewPos, float dither, vec3 lightCol, vec3 ambientCol) {
	vec3 nViewPos = normalize(viewPos);
	float VoL = dot(nViewPos, lightVec);
	vec3 wpos = normalize((gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz);

	float heightFade = wpos.y - 0.1 - rainStrength * 0.2;
	heightFade = clamp(heightFade * (6.0 - rainStrength * 5.0), 0.0, 1.0);
	if (heightFade <= 0.0) return vec4(0.0);

	vec2 planeUv = wpos.xz * (SDV_CLOUD_SCALE / wpos.y);
	vec2 planePos = vec2(cameraPosition.x + frametime * SDV_CLOUD_SPEED, cameraPosition.z);

	vec2 cloudData = SDVCloudParallax(planeUv, planePos);

	#ifdef SDV_CLOUD_DOUBLE
	cloudData = max(SDVCloudParallax(planeUv * 2.0, planePos).yx * 0.25, cloudData);
	#endif

	#ifdef SDV_CLOUD_DYNAMIC
	float fadeTime = clamp(sin(frametime * SDV_CLOUD_FADE_SPEED) * 0.8 + 0.5, 0.0, 1.0);
	float cloud = mix(mix(cloudData.x, cloudData.y, fadeTime), max(cloudData.x, cloudData.y), rainStrength);
	#else
	float cloud = mix(cloudData.x, max(cloudData.x, cloudData.y), rainStrength);
	#endif

	cloud *= heightFade;

	float halfVoL = VoL * shadowFade * 0.5 + 0.5;
	float scattering = pow(halfVoL, 6.0);

	vec3 cloudColor = mix(
		ambientCol * (0.35 * sunVisibility + 0.5),
		lightCol * (0.85 + 1.15 * scattering),
		clamp(cloud * 1.25, 0.0, 1.0)
	);
	cloudColor *= 1.0 - 0.6 * rainStrength;
	cloud *= 1.0 - 0.6 * rainStrength;
	float cloudSunElev = dot(sunVec, upVec);
	float cloudDayAmt = smoothstep(-0.06, 0.35, cloudSunElev);
	float cloudTwiAmt = 1.0 - smoothstep(0.0, 0.42, abs(cloudSunElev + 0.05));
	cloudColor *= mix(vec3(1.0), vec3(1.15, 0.86, 0.90), cloudTwiAmt * SDV_CLOUD_TINT);
	cloudColor *= mix(vec3(1.0), vec3(0.85, 0.85, 1.10), (1.0 - cloudDayAmt) * (1.0 - cloudTwiAmt) * SDV_CLOUD_TINT);
	cloudColor *= SDV_CLOUD_BRIGHTNESS * (0.5 - 0.25 * (1.0 - sunVisibility) * (1.0 - rainStrength));

	#if MC_VERSION >= 11800
	cloudColor *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
	#else
	cloudColor *= clamp((cameraPosition.y + 6.0) / 8.0, 0.0, 1.0);
	#endif

	#ifdef UNDERGROUND_SKY
	cloud *= mix(clamp((cameraPosition.y - 48.0) / 16.0, 0.0, 1.0), 1.0, eBS);
	#endif

	return vec4(cloudColor, clamp(cloud * SDV_CLOUD_OPACITY, 0.0, 1.0));
}

//Cloud style dispatcher (CLOUDS 1 = classic, CLOUDS 3 = Super Duper style skybox)
vec4 DrawCloud(vec3 viewPos, float dither, vec3 lightCol, vec3 ambientCol) {
	#if CLOUDS == 3
	return DrawCloudSDV(viewPos, dither, lightCol, ambientCol);
	#else
	return DrawCloudClassic(viewPos, dither, lightCol, ambientCol);
	#endif
}

float GetNoise(vec2 pos) {
	return fract(sin(dot(pos, vec2(12.9898, 4.1414))) * 43758.5453);
}

void DrawNebulae(inout vec3 color, vec3 viewPos) {
	// TODO SOON
}

void DrawStars(inout vec3 color, vec3 viewPos) {
    vec3 wpos = vec3(gbufferModelViewInverse * vec4(viewPos, 1.0));
	vec3 planeCoord = wpos / (wpos.y + length(wpos.xz));
	vec2 wind = vec2(frametime, 0.0);
	vec2 coord = planeCoord.xz * 0.5 + cameraPosition.xz * 0.0001 + wind * 0.00125;
	coord = floor(coord * 1648.0) / 1024.0;
	
	float VoU = clamp(dot(normalize(viewPos), upVec), 0.0, 1.0);
	float multiplier = sqrt(sqrt(VoU)) * 55 * (1.0 - rainStrength) * moonVisibility;
	
	float star = 1.0;
	if (VoU > 0.0) {
		star *= GetNoise(coord.xy);
		star *= GetNoise(coord.xy + 0.10);
		star *= GetNoise(coord.xy + 0.23);
	}
	star = clamp(star - 0.8125, 0.0, 3.0) * multiplier;
	//star *= voidFade;
	#if MC_VERSION >= 11800
	star *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
	#else
	star *= clamp((cameraPosition.y + 6.0) / 8.0, 0.0, 1.0);
	#endif

	#ifdef UNDERGROUND_SKY
	star *= mix(clamp((cameraPosition.y - 48.0) / 16.0, 0.0, 1.0), 1.0, eBS);
	#endif
		
	color += star * pow(lightNight, vec3(1.8));
}

#ifdef AURORA
#include "/lib/color/auroraColor.glsl"

float AuroraSample(vec2 coord, vec2 wind, float VoU) {
	float noise = texture2D(noisetex, coord * 0.0625  + wind * 0.05).b * 3.0;
		  noise+= texture2D(noisetex, coord * 0.03125 + wind * 0.025).b * 3.0;

	noise = max(1.0 - 4.0 * (0.5 * VoU + 0.5) * abs(noise - 3.0), 0.0);

	return noise;
}

vec3 DrawAurora(vec3 viewPos, float dither, int samples) {
	#ifdef TAA
	dither = fract(16.0 * frameTimeCounter + dither);
	#endif
	
	float sampleStep = 1.0 / samples;
	float currentStep = dither * sampleStep;

	float VoU = dot(normalize(viewPos), upVec);

	float visibility = moonVisibility * (1.0 - rainStrength) * (1.0 - rainStrength);

	#ifdef WEATHER_PERBIOME
	visibility *= isCold * isCold;
	#endif

	vec2 wind = vec2(
		frametime * CLOUD_SPEED * 0.000125,
		sin(frametime * CLOUD_SPEED * 0.05) * 0.00025
	);

	vec3 aurora = vec3(0.0);

	if (VoU > 0.0 && visibility > 0.0) {
		vec3 wpos = normalize((gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz);
		for(int i = 0; i < samples; i++) {
			vec3 planeCoord = wpos * ((8.0 + currentStep * 7.0) / wpos.y) * 0.004;

			vec2 coord = cameraPosition.xz * 0.00044 + planeCoord.xz;
			coord += vec2(coord.y, -coord.x) * 0.3;

			float noise = AuroraSample(coord, wind, VoU);
			
			if (noise > 0.0) {
				noise *= texture2D(noisetex, coord * 0.125 + wind * 0.25).b;
				noise *= 0.5 * texture2D(noisetex, coord + wind * 16.0).b + 0.75;
				noise = noise * noise * 2 * 3.0 * sampleStep;
				noise *= max(sqrt(2.0 - length(planeCoord.xz*2.4) * 4.35), 0.0);

				vec3 auroraColor = mix(auroraLowCol, auroraHighCol, pow(currentStep, 0.4));
				aurora += noise * auroraColor * exp2(-7.0 * i * sampleStep);
			}
			currentStep += sampleStep;
		}
	}
	// visibility *= voidFade;
	#if MC_VERSION >= 11800
	visibility *= clamp((cameraPosition.y + 70.0) / 8.0, 0.0, 1.0);
	#else
	visibility *= clamp((cameraPosition.y + 6.0) / 8.0, 0.0, 1.0);
	#endif

	#ifdef UNDERGROUND_SKY
	visibility *= mix(clamp((cameraPosition.y - 48.0) / 16.0, 0.0, 1.0), 1.0, eBS);
	#endif

	return aurora * visibility;
}

#endif
#endif