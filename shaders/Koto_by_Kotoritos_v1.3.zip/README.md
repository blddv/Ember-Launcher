Koto Shader Pack

Author: Kotoritos
Copyright © 2026 Kotoritos. ARR (All Rights Reserved).

Minecraft shader pack designed for Iris.

Compatibility: Minecraft 1.20.1 → latest, Iris 1.7.0 or newer, GPU with OpenGL 4.3 (not macOS).

Quality presets:
- Potato
- Low
- Medium (default)
- High
- Super

Changelog — v1.3
- Biome-specific variations (Pale Garden sky, jungle fog, desert rain) removed: the same look in every biome and every version.
- 100% original code: own water wave model (golden-angle crest waves, analytic slopes, raindrop rings), own dither noise (replaces the external blue-noise texture, -3 MB), own edge smoothing filter and own filmic tonemap curve. Unused third-party leftovers (bloom, AgX, Uncharted) removed.
- Block selection outline: dedicated gbuffers_line that only writes its colour and a line flag (the block behind keeps its own lighting data), so the outline is always a plain dark line, never orange/red.
- Stability: TAA (and its jitter) is now off in all presets and every per-pixel noise pattern is static. Fog, reflection and AO no longer use frame history, so nothing can flicker when the camera stops or moves. Anti-aliasing is done by FXAA; the static fog dither is smoothed by a wider depth-aware filter.
- Performance: removed 11 empty bloom passes; volumetric fog cost now scales with the preset (Medium: 24 steps x 1 shadow tap instead of 35 x 3); shadow map only renders chunks inside the shadow range; shadow range per preset (Potato 128, Low 192, Medium+ 256).
- Fixed flickering pixels everywhere: TAA now uses YCoCg variance clipping and a tonemapped blend instead of the luma-based rejection that discarded history on every textured pixel.
- Without TAA (Potato/Low), reflection and AO noise is static, so nothing flickers.
- Water: wave detail now fades with pixel footprint (distance and grazing angle), so distant water is smooth instead of sparkling with pixels.
- Shadows: balanced shadow-map distortion (distant shadow texels about 3x smaller), texel-scaled normal bias (no acne speckles) and distance-scaled penumbra - distant terrain no longer looks pixelated.
- Dynamic hand light: holding a torch, lantern, glowstone or any light block lights the area around you (vanilla falloff); soul torches/lanterns glow cyan.
- Anti-aliasing: real TAA with sub-pixel jitter on Medium, High and Super (smooth edges, no more jagged grass and blocks); TAA no longer rejects history on edges. Potato/Low keep FXAA, now tuned for HDR.
- Removed the final sharpening filter that made textures look crunchy.
- Wider shadow penumbra so shadow-map texels are no longer visible.
- Overworld fog reduced to 25% (and the extra morning fog from x2.5 to x1.4): no more white-out hiding the sun. Nether and End fog unchanged.
- Fixed the sky glow in the wrong place: the main cloud texture was sampled without filtering, so each texel became a huge straight-edged panel that lit up near the sun. Clouds are now smooth.
- Volumetric light ignores samples outside the shadow map (no straight-edged light shafts).
- Square pixel-art sun whose colour follows the time of day.

Changelog — v1.2
- Bloom disabled: removed the purple/coloured glow halos around mobs, objects and the sky.
- Fog history now rejects moving entities and waving plants (no glowing ghost trails).
- About 35% fewer clouds.
- New square pixel-art sun (like vanilla and the Koto moon) whose colour follows the time of day: orange at the horizon, golden morning/evening, warm white at noon. Much less bright.
- Fixed straight-edged light panels in the sky: volumetric light no longer reads outside the shadow map.
- Settings menu simplified: only the quality presets (Potato, Low, Medium, High, Super) are shown.
- Block selection outline is now a thin dark line (was lit yellow/orange by sun and torches).
- Reflection history is rejected on fast camera turns (fixes smearing on block edges, portals).
- Clouds: golden-hour tint and stronger silver lining.
- Nether ambient light x1.55 and End ambient x1.40 (new sliders in Lumen Deck > Realm Glow).
- Presets now cycle in order: Potato > Low > Medium > High > Super.
- Removed all dither grain: fog is now accumulated over frames and resolved by a new depth-aware filter pass (composite9) before reaching blocks, sky and clouds; Ray AO is blurred; soft shadows use hardware PCF with no per-pixel noise.
- Fixed translucent blocks (glass, ice, slime, honey...) reading random screen pixels instead of their texture, which flickered when turning the camera.
- Removed unused SSAO calls from translucent and particle shaders (faster).
- SSAO is no longer computed when the Vanilla AO method is selected (faster on Potato–Medium).

Changelog — v1.1
- Fixed the Super preset (an invalid volumetric sample value stopped Iris from recognising it).
- Edge Smoothing (FXAA) and Bloom toggles now compile correctly when switched off/on (on by default, as before).
- All options live in settings.glsl; every program verified to compile on all 5 presets (Overworld + End).
- Removed three empty full-screen copy passes (Overworld and End) for a small performance gain.
- Removed unused floodfill/voxel code and leftover commented-out code.
- Cleaned up option lists and shaders.properties.
- Compatibility: works on Minecraft 1.20.1+ (fallback block lists for older Iris without tag support, old "grass" name, Pale Garden uniform only on 1.21.4+).
- Fixed ochre froglight not glowing (typo) and removed invalid block names.
