// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef BLOCKID_GLSL
#define BLOCKID_GLSL

#define WATER_ID 101
#define TRANSLUCENT_ID 103
#define SSS_ID 104
#define METAL_ID 105
#define PORTAL_ID 106
#define END_PORTAL_ID 107

#endif //BLOCKID_GLSL
