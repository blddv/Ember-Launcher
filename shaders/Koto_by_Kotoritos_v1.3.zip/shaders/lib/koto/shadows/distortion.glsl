// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef DISTORT_GLSL
#define DISTORT_GLSL

#include "/lib/koto/core/settings.glsl"
#include "/lib/koto/core/uniforms.glsl"


const int shadowMapResolution = UMBRA_MAP_SIZE;

float kotoShadowDistortFactor(vec2 clipXY) {
  return 0.15 + 0.85 * length(clipXY);
}

// World-space size of one shadow-map texel at this point of the (distorted) map.
float kotoShadowTexelWorldSize(vec2 clipXY) {
  float f = kotoShadowDistortFactor(clipXY);
  return (2.0 * shadowDistance / float(shadowMapResolution)) * (f * f / 0.15);
}

vec3 distortShadowClipPos(vec3 shadowClipPos) {
  // Balanced distortion: high detail near the player without making far texels several
  // blocks wide (the old len + 0.05 curve made distant shadows blocky and pixelated).
  float distortionFactor = kotoShadowDistortFactor(shadowClipPos.xy);

  shadowClipPos.xy = shadowClipPos.xy / (distortionFactor);
  shadowClipPos.z = shadowClipPos.z * (0.5); // increases shadow distance on the Z axis, which helps when the sun is very low in the sky
  return (shadowClipPos);
}


#endif //DISTORT_GLSL
