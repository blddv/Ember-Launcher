// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef SOFTSHADOWS_GLSL
#define SOFTSHADOWS_GLSL

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/core/settings.glsl"
#include "/lib/koto/shadows/shadow_sampling.glsl"
#include "/lib/koto/shadows/distortion.glsl"

vec4 getShadowClipPos(vec3 feetPlayerPos) {
  vec3 shadowViewPos = (shadowModelView * vec4(feetPlayerPos, 1.)).xyz;
  vec4 shadowClipPos = shadowProjection * vec4(shadowViewPos, 1.);
  return (shadowClipPos);
}

vec3 getSoftShadow(vec4 shadowClipPos, vec3 normal, float SSS) {
  vec3 shadowNormal = mat3(shadowModelView) * normal ;
  const float shadowMapPixelSize = 1. / float(UMBRA_MAP_SIZE);
  float sampleRadius = UMBRA_EDGE_WIDTH * shadowMapPixelSize * 1.6; // wider penumbra hides shadow-map texels
  vec3 biasAdjustFactor = vec3(
    shadowMapPixelSize * 0.45,
    shadowMapPixelSize * 0.45,
    -0.00007803515625
  );

  float faceNdl = dot(normal, worldLightVector);
  if ((faceNdl <= 1e-6 && SSS > 64. / 255.)) {
    sampleRadius = sampleRadius * (max(exp(1.12 * (0.231 + SSS)), 0.));
  }
  // Normal offset scaled to the local texel size (removes acne / speckles far away) and a
  // penumbra that grows with the texel size so distant shadows stay smooth, not blocky.
  float texelWorld = kotoShadowTexelWorldSize(shadowClipPos.xy);
  shadowClipPos.xyz += mat3(shadowProjection) * shadowNormal * (texelWorld * 0.75);
  sampleRadius *= kotoShadowDistortFactor(shadowClipPos.xy) / 0.15;
  vec3 shadowAccum = vec3(0.); // sum of all shadow samples

     for (int i = 0; i < UMBRA_FILTER_TAPS; i++) {
    // Fixed disc rotation (no per-pixel noise): with hardware PCF every tap is already
    // bilinearly filtered, so the penumbra stays smooth instead of dotted.
    const float shadowJitter = 0.37;
    vec2 offset = vogelDisc(i, UMBRA_FILTER_TAPS, shadowJitter) * sampleRadius;
    vec4 offsetShadowClipPos = shadowClipPos + vec4(offset, 0., 0.); // add offset
    offsetShadowClipPos.xyz = distortShadowClipPos(offsetShadowClipPos.xyz); // apply distortion
    vec3 shadowNDCPos = offsetShadowClipPos.xyz / offsetShadowClipPos.w; // convert to NDC space
    vec3 shadowScreenPos = shadowNDCPos * 0.5 + 0.5; // convert to screen space
    shadowScreenPos = shadowScreenPos + (shadowNormal * biasAdjustFactor);
    shadowAccum = shadowAccum + (getShadow(shadowScreenPos)); // take shadow sample
  }



  return (shadowAccum / float(UMBRA_FILTER_TAPS)); // divide sum by count, getting average shadow
}



#endif // SOFTSHADOWS_GLSL
