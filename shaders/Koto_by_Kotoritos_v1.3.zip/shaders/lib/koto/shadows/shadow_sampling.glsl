// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef DRAWSHADOWS_GLSL
#define DRAWSHADOWS_GLSL

#include "/lib/koto/core/uniforms.glsl"

// Hardware PCF (shadowtex*HW, bilinear depth compare) gives smooth penumbras without
// per-pixel noise. Lit where nothing blocks the sun, tinted by translucent casters,
// dark where an opaque block is in the way.
vec3 getShadow(vec3 shadowScreenPos) {
  float transparentShadow = texture(shadowtex0HW, shadowScreenPos);
  if (transparentShadow >= 0.999) {
    return (vec3(1.));
  }

  float opaqueShadow = texture(shadowtex1HW, shadowScreenPos);
  if (opaqueShadow <= 0.001) {
    return (vec3(transparentShadow));
  }

  vec4 shadowColor = texture(shadowcolor0, shadowScreenPos.xy);
  vec3 tinted = shadowColor.rgb * (1. - shadowColor.a) * opaqueShadow;
  return (mix(tinted, vec3(1.), transparentShadow));
}



#endif //DRAWSHADOWS_GLSL
