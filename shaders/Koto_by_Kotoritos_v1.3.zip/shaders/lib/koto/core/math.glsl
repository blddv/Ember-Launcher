// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#define PASS_LAYOUT_V2 1
#ifndef MATH_GLSL
#define MATH_GLSL

float pow2(float x) { return x * x; }

#endif