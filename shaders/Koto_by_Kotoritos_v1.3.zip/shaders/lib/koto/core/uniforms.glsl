// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef UNIFORMS
#define UNIFORMS

#include "/lib/koto/core/settings.glsl"

//Projection Matrices
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousProjection;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferModelView;
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjection;
uniform mat4 shadowProjectionInverse;

//buffers
uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D colortex6;
uniform sampler2D colortex7;
uniform sampler2D colortex8;
uniform sampler2D colortex9;
uniform sampler2D colortex10;
uniform sampler2D colortex11;
uniform sampler2D colortex12;
uniform sampler2D colortex13;
uniform sampler2D colortex14;
uniform sampler2D colortex15;

//depth buffer
uniform sampler2D depthtex0;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform sampler2D depthtex1;
uniform sampler2D depthtex2;

//shadow buffer
uniform sampler2D shadowtex0;
uniform sampler2D shadowtex1;
uniform sampler2D shadowcolor0;
uniform sampler2DShadow shadowtex1HW;
uniform sampler2DShadow shadowtex0HW;

//normal/speculars
uniform sampler2D normals;
uniform sampler2D specular;

//noises
uniform sampler2D puddleTex;
uniform sampler2D waterTex;
uniform sampler2D fogTex;
uniform sampler2D clouds;
uniform sampler2D cloudBase;
uniform sampler2D detail;

// Runtime texture and buffer uniforms

//additional uniforms
uniform vec3 cameraPosition;
#ifdef KOTO_LEGACY
// Older Iris (1.2 - 1.6) has no cameraPositionInt / cameraPositionFract uniforms.
#define cameraPositionInt ivec3(floor(cameraPosition))
#define cameraPositionFract fract(cameraPosition)
#else
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
#endif
uniform ivec3 previousCameraPositionInt;
uniform int frameCounter;
uniform float frameTime;
uniform float far;
uniform float near;
const float PaleGardenSmooth = 0.0; // biome variations removed: same look in every biome
uniform ivec2 eyeBrightnessSmooth;
uniform float frameTimeCounter;
uniform float viewWidth;
uniform float viewHeight;
uniform float wetness;
uniform int isEyeInWater;
uniform int worldTime;
uniform float sunAngle;
uniform vec4 entityColor;
const bool isColdBiome = false;
const float snowBiomeSmooth = 1.0;
const float hotBiomeSmooth = 1.0;
const bool isJungle = false;
const float jungleSmooth = 0.0;
uniform float eyeAltitude;
uniform vec3 previousCameraPosition;
uniform bool hideGUI;
// Iris world/dimension state. Used to keep Overworld-only atmosphere out of Nether/End.
#if defined(KOTO_FORCE_NETHER)
// Legacy world-1 folder: always the Nether (Iris 1.2 has no hasSkylight / hasCeiling).
const bool hasSkylight = false;
const bool hasCeiling = true;
#elif defined(KOTO_LEGACY)
uniform bool hasSkylight = true;
uniform bool hasCeiling = false;
#else
uniform bool hasSkylight;
uniform bool hasCeiling;
#endif
uniform vec3 fogColor;
uniform vec3 skyColor;

// Block light emission (0..1). Modern Iris gives it per vertex (at_midBlock.w); older Iris
// (1.2 - 1.6) only has 3 components there, so Koto Legacy derives it from block IDs.
float kotoLegacyEmission(int id) {
  if (id == 10003) return 14.0 / 15.0; // torches, lanterns, glowstone, lava, fire, froglights
  if (id == 10004) return 10.0 / 15.0; // soul fire, soul torches, soul lanterns
  if (id == 10005) return 13.0 / 15.0; // sea lantern, end rod, beacon, glow lichen
  if (id == 10006) return 7.0 / 15.0;  // redstone torches
  if (id == 10007) return 8.0 / 15.0;  // amethyst, crying obsidian
  if (id == 10008) return 14.0 / 15.0; // copper torches and lanterns
  return 0.0;
}
#ifdef KOTO_LEGACY
#define KOTO_BLOCK_EMISSION(id, w) kotoLegacyEmission(id)
#define KOTO_ENTITY_EMISSION(w) 0.0
#else
#define KOTO_BLOCK_EMISSION(id, w) ((w) / 15.)
#define KOTO_ENTITY_EMISSION(w) clamp((w) / 15., 0., 1.)
#endif

bool kotoIsOverworldDimension() {
#ifdef VOID_REALM_PIPE
  return false;
#else
  // Do not use skyColor as a dimension test: vanilla skyColor can approach
  // zero during the night, which used to make Koto disable the moon and
  // stars mid-night. The End is already separated by dimension.properties.
  return hasSkylight && !hasCeiling;
#endif
}

float kotoNightFactor() {
  float t = fract(float(worldTime) / 24000.0);
  // Keep night fully active until the real pre-dawn transition.
  float dusk = smoothstep(0.510, 0.550, t);
  float dawn = 1.0 - smoothstep(0.982, 0.999, t);
  return clamp(dusk * dawn, 0.0, 1.0);
}


float kotoDayFactor() {
  return 1.0 - kotoNightFactor();
}

//constants

const float PI = float(3.14159);
const float wetnessHalflife = 35.3;
const float drynessHalflife = 75.0;
const float sunPathRotation = ORBIT_SOLAR_SHIFT;
const float eyeBrightnessHalflife = 5.0;
uniform ivec2 eyeBrightness;
const float shadowDistance = UMBRA_DISTANCE;
const float shadowFarPlane = 512.0;

const float shadowDistanceRenderMul = 1.0; // only render shadow casters inside the shadow range

#if CREVICE_METHOD == 1
const float ambientOcclusionLevel = 0.0;
#else
const float ambientOcclusionLevel = CREVICE_BASE_STRENGTH;
#endif

//lights
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 shadowLightPosition;
vec3 lightVector = normalize(shadowLightPosition);
vec3 worldLightVector = mat3(gbufferModelViewInverse) * lightVector;
vec3 sunDir = normalize(sunPosition);
vec3 worldSunDir = mat3(gbufferModelViewInverse) * sunDir;


vec3 moonDir = normalize(moonPosition);
vec3 worldMoonDir = mat3(gbufferModelViewInverse) * moonDir;

vec3 kotoStableMoonDir() {
  // Vanilla moon follows the opposite celestial arc to the sun.
  // Using the sun vector avoids intermittent moonPosition discontinuities.
  return normalize(-worldSunDir);
}

vec2 resolution = vec2(viewWidth, viewHeight);

// Frame index for per-pixel noise that relies on TAA to average out. Without TAA the
// pattern stays fixed so it never flickers.
#if ECHO_ENABLE == 1
#define KOTO_NOISE_FRAME frameCounter
#else
#define KOTO_NOISE_FRAME 0
#endif

// TAA sub-pixel jitter (Halton 2,3 / 8 frames), in NDC units. Applied in the gbuffers
// vertex shaders when TAA (ECHO_ENABLE) is on, so the temporal resolve in composite90
// actually anti-aliases edges instead of only blending frames.
vec2 kotoTaaOffset() {
  const vec2 seq[8] = vec2[8](
    vec2(0.5, 0.333333), vec2(0.25, 0.666667), vec2(0.75, 0.111111), vec2(0.125, 0.444444),
    vec2(0.625, 0.777778), vec2(0.375, 0.222222), vec2(0.875, 0.555556), vec2(0.0625, 0.888889));
  return (seq[frameCounter % 8] * 2.0 - 1.0) / vec2(viewWidth, viewHeight);
}
//boolens
bool inWater = isEyeInWater == 1.0;
#endif //UNIFORMS
