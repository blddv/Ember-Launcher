// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef UTIL_GLSL
#define UTIL_GLSL

#include "/lib/koto/core/settings.glsl"
#include "/lib/koto/core/uniforms.glsl"

vec3 projectAndDivide(mat4 projectionMatrix, vec3 position) {
  vec4 homPos = projectionMatrix * vec4(position, 1.);
  return (homPos.xyz / homPos.w);
}

// Koto dither: an R2 low-discrepancy pattern over the pixel grid with a small hash
// scramble, so neighbouring pixels get well spread values without any noise texture.
float kotoScramble(vec2 p) {
  p = fract(p * vec2(0.1031, 0.1030));
  p += dot(p, p.yx + 75.79);
  return fract((p.x + p.y) * p.x);
}

float kotoDither(vec2 coord, float seed) {
  vec2 p = floor(coord);
  float r2 = fract(0.5 + p.x * 0.7548776662 + p.y * 0.5698402910 + seed * 0.6180339887);
  return fract(r2 + (kotoScramble(p + seed * 84.79) - 0.5) * 0.18);
}

float IGN(vec2 coord) {
  return kotoDither(coord, 0.0);
}

float IGN(vec2 coord, int frame) {
  return kotoDither(coord, float(frame % 64));
}

vec2 vogelDisc(int stepIndex, int stepCount, float noise) {
  float rotation = noise * 2 * PI;
  const float goldenAngle = 2.4;

  float r = sqrt(stepIndex + 0.5) / sqrt(float(stepCount));
  float theta = stepIndex * goldenAngle + rotation;

  return (r * vec2(cos(theta), sin(theta)));
}

vec3 screenSpaceToViewSpace(vec3 screenPosition, mat4 projectionInverse) {
  screenPosition = screenPosition * 2. - 1.;

  vec3 viewPosition = vec3(
    vec2(projectionInverse[0].x, projectionInverse[1].y) * screenPosition.xy +
      projectionInverse[3].xy,
    projectionInverse[3].z
  );

  viewPosition /=
    projectionInverse[2].w * screenPosition.z + projectionInverse[3].w;

  return (viewPosition);
}

float screenSpaceToViewSpace(float depth) {
  depth = depth * 2. - 1.;
  return gbufferProjectionInverse[3].z /
  (gbufferProjectionInverse[2].w * depth + gbufferProjectionInverse[3].w);
}

float luminance(vec3 color) {
  return (dot(color, vec3(0.2126, 0.7152, 0.0722)));
}

float screenSpaceToViewSpace(float depth, mat4 projectionInverse) {
  depth = depth * 2. - 1.;
  return projectionInverse[3].z /
  (projectionInverse[2].w * depth + projectionInverse[3].w);
}

vec3 viewSpaceToScreenSpace(vec3 viewPosition) {
  vec3 screenPosition =
    vec3(
      gbufferProjection[0].x,
      gbufferProjection[1].y,
      gbufferProjection[2].z
    ) *
      viewPosition +
    gbufferProjection[3].xyz;
  screenPosition = screenPosition / (-viewPosition.z);

  return (screenPosition * 0.5 + 0.5);
}
float viewSpaceToScreenSpace(float depth, mat4 projection) {
  return ((projection[2].z * depth + projection[3].z) / -depth * 0.5 + 0.5);
}

float HG(float g, float cosA) {
  cosA = clamp(cosA, -1, 1);

  float g2 = g * g;
  return (1. - g2) / pow(abs(1. + g2 - 2. * g * cosA), 1.5);
}

float CS(float g, float costh) {
  return 3. *
  (1. - g * g) *
  (1. + costh * costh) /
  (4. *
    PI *
    2. *
    (2. + g * g) *
    pow(1. + g * g - 2. * g * costh, 3. / 2.));
}

vec3 screenToView(vec2 texcoord, float depth) {
  vec3 ndcPos = vec3(texcoord.xy, depth) * 2. - 1.;
  vec3 viewPos = projectAndDivide(gbufferProjectionInverse, ndcPos);
  return (viewPos);
}

float DistributionGGX(vec3 N, vec3 H, float roughness) {
  float a = roughness * roughness;
  float a2 = a * a;
  float NdotH = max(dot(N, H), 1e-6);
  float NdotH2 = NdotH * NdotH;

  float num = a2;
  float denom = NdotH2 * (a2 - 1.) + 1.;
  denom = PI * denom * denom;

  return (num / denom);
}

float GeometrySchlickGGX(float NdotV, float roughness) {
  float r = roughness + 1.;
  float k = r * r / 8.;

  float num = NdotV;
  float denom = NdotV * (1. - k) + k;

  return (num / denom);
}
float GeometrySmith(vec3 N, vec3 V, vec3 L, float roughness) {
  float NdotV = max(dot(N, V), 1e-6);
  float NdotL = max(dot(N, L), 1e-6);
  float ggx2 = GeometrySchlickGGX(NdotV, roughness);
  float ggx1 = GeometrySchlickGGX(NdotL, roughness);

  return (ggx1 * ggx2);
}

vec3 fresnelSchlick(float cosTheta, vec3 F0) {
  float f = pow(1. - cosTheta, 5.);
  return (f + F0 * (1. - f));
}

vec3 screenSpaceToViewSpace(vec3 screenPosition) {
  screenPosition = screenPosition * 2. - 1.;

  vec3 viewPosition = vec3(
    vec2(gbufferProjectionInverse[0].x, gbufferProjectionInverse[1].y) *
      screenPosition.xy +
      gbufferProjectionInverse[3].xy,
    gbufferProjectionInverse[3].z
  );

  viewPosition /=
    gbufferProjectionInverse[2].w * screenPosition.z +
    gbufferProjectionInverse[3].w;

  return (viewPosition);
}

float Rayleigh(float mu) {
  return (3. * (1. + mu * mu) / (16. * PI));
}


vec3 blue_noise(vec2 coord, int frame) {
  float f = float(frame % 64);
  return vec3(kotoDither(coord, f), kotoDither(coord + vec2(41.0, 17.0), f + 0.3333), kotoDither(coord + vec2(13.0, 59.0), f + 0.6667));
}

vec3 blue_noise(vec2 coord, int frame, int sampleIndex) {
  const float plastic = 1.32471795724474602596;
  const vec2 invPlastic = vec2(1. / plastic, 1. / pow(plastic, 2.));
  vec2 sequencePoint = fract(vec2(0.5) + invPlastic * float(sampleIndex));
  return (blue_noise(coord + sequencePoint, frame));
}

float linearstep(float edge0, float edge1, float x) {
    return (clamp((x - edge0) / (edge1 - edge0), 0., 1.));
}
vec3 SampleVNDFGGX(
  vec3 viewerDirection,
  vec2 alpha,
  vec2 xy
) {
  vec3 stretchedView = normalize(vec3(viewerDirection.xy * alpha, viewerDirection.z));
  float azimuth = 6.2831853 * xy.x;
  float reflectedZ = fma(1. - xy.y, 1. + stretchedView.z, -stretchedView.z);
  float reflectedR = sqrt(clamp(1. - reflectedZ * reflectedZ, 0., 1.));
  vec2 reflectedXY = vec2(cos(azimuth), sin(azimuth)) * reflectedR;
  vec3 halfway = vec3(reflectedXY, reflectedZ) + stretchedView;
  return (normalize(vec3(halfway.xy * alpha, halfway.z)));
}

float getWorldDirectionToSun(vec3 direction)
{
  //expects direction to be in player/world space
  return (dot(direction, worldLightVector));
}

float linearizeDepth(float depth)
{

    float z = depth * 2. - 1.; // Back to NDC
    return (2. * near * far) / (far + near - z * (far - near));
}


#endif //UTIL_GLSL
