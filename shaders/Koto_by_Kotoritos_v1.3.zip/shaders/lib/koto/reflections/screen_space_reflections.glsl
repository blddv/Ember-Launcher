// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef SSR_GLSL
#define SSR_GLSL

#define BINARY_DECREASE 0.5
uint binarySteps = uint(MIRAGE_REFINE_STEPS);

const float handDepth = MC_HAND_DEPTH * 0.5 + 0.5;

float getDepth(vec2 pos, sampler2D depthBuffer) {
  ivec2 pixel = ivec2(pos * vec2(viewWidth, viewHeight));
  return texelFetch(depthBuffer, pixel, 0).r;
}

vec3 diagonal(mat4 mat) {
  return vec3(mat[0][0], mat[1][1], mat[2][2]);
}

vec3 projectionOrthogonal(mat4 mat, vec3 v) {
  return mat[3].xyz + diagonal(mat) * v;
}

vec3 viewToScreen(vec3 viewPos) {
  vec3 projected = projectionOrthogonal(gbufferProjection, viewPos);
  return projected * (0.5 / -viewPos.z) + 0.5;
}

float minOf(vec3 x) { return min(min(x.x, x.y), x.z); }
float minOf(vec2 x) { return min(x.x, x.y); }

void binarySearch(inout vec3 rayPosition, vec3 rayDirection) {
  for (int i = 0; i < MIRAGE_REFINE_STEPS; i++) {
    rayPosition +=
      sign(
        texelFetch(
          depthtex0,
          ivec2(rayPosition.xy * vec2(viewWidth, viewHeight)),
          0
        ).r -
          rayPosition.z
      ) *
      rayDirection;
    // Going back and forth using the delta of the 2 different depths as a parameter for sign()
    rayDirection *= BINARY_DECREASE;
    // Decreasing the step length (to slowly tend towards the intersection)
  }
}

// The favorite raytracer of your favorite raytracer
bool raytrace(
  vec3 viewPosition,
  vec3 rayDirection,
  int stepCount,
  float smoothLightmap,
  out vec3 rayPosition
) {
  if (rayDirection.z > 0.0 && rayDirection.z >= -viewPosition.z) return false;

  vec3 startScreen = viewToScreen(viewPosition);
  vec3 endScreen = viewToScreen(viewPosition + rayDirection);
  vec3 delta = normalize(endScreen - startScreen);
  float edgeDistance = minOf(abs(sign(delta) - startScreen) / max(abs(delta), vec3(0.00001)));
  delta *= edgeDistance / float(stepCount);

  float depthLenience = max(abs(delta.z), 0.02 / (viewPosition.z * viewPosition.z));
  float viewThickness = max(0.01 * (1.0 + abs(delta.z) * 5.0), 1e-4);
  #if ECHO_ENABLE == 1
  vec3 jitter = blue_noise(floor(gl_FragCoord.xy), frameCounter, stepCount);
  #else
  vec3 jitter = blue_noise(floor(gl_FragCoord.xy), 0, stepCount); // static without TAA: no flicker
  #endif

  rayPosition = startScreen + delta * jitter.x;
  bool hit = false;

  for (int i = 0; i < stepCount; ++i) {
    vec3 previous = rayPosition;
    rayPosition += delta;

    if (any(lessThan(rayPosition.xy, vec2(0.0))) || any(greaterThan(rayPosition.xy, vec2(1.0)))) break;
    if (any(notEqual(clamp(previous, vec3(0.0), vec3(1.0)), previous))) return false;

    float sceneDepth = texelFetch(depthtex0, ivec2(rayPosition.xy * resolution), 0).r;
    float depthGap = rayPosition.z - sceneDepth;
    bool crossed = depthGap > 0.0 && abs(depthLenience - depthGap) < depthLenience && rayPosition.z > handDepth;
    hit = crossed && (sceneDepth < 1.0 || smoothLightmap < 13.5 / 15.0);
    if (hit) break;
  }

#if MIRAGE_HIT_REFINE == 1
  binarySearch(rayPosition, delta);
#endif
  return hit;
}

#endif //SSR_GLSL