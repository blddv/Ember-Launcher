// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_FULLSCREEN_VERTEX
#define KOTO_STAGE_FULLSCREEN_VERTEX

out vec2 texcoord;

void main() {
  vec4 clipVertex = gl_ModelViewProjectionMatrix * gl_Vertex;
  vec4 mappedUv = gl_TextureMatrix[0] * gl_MultiTexCoord0;
  gl_Position = clipVertex;
  texcoord = mappedUv.xy;
}

#endif
