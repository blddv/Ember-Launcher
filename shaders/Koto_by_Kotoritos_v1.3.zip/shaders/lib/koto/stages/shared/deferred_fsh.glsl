// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_SHARED_DEFERRED_FSH
#define KOTO_SHARED_DEFERRED_FSH

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/atmosphere/distance_fog.glsl"
#include "/lib/koto/shadows/ambient_occlusion.glsl"

in vec2 texcoord;


layout(location = 0) out float occlusion ;
void main() {
  occlusion = texture(colortex12, texcoord).r;
  occlusion = 1.;
  #if CREVICE_METHOD != 1
  return; // SSAO is only consumed by the "Ray" AO method; skip the cost otherwise.
  #endif
  float depth = texture(depthtex0, texcoord).r;

    if ((depth == 1.)) {
    return;
  }
const float handDepth = MC_HAND_DEPTH * 0.5 + 0.5;

  vec3 screenPos = vec3(texcoord.xy, depth);
  vec3 NDCPos = vec3(texcoord, depth) * 2. - 1.;
  vec3 viewPos = projectAndDivide(gbufferProjectionInverse, NDCPos);
  vec3 viewDir = normalize(viewPos);
  vec3 feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.)).xyz;

  feetPlayerPos = feetPlayerPos + (cameraPosition);

  //reprojected coords
  feetPlayerPos = feetPlayerPos - (previousCameraPosition);
  vec3 previousView = (gbufferPreviousModelView * vec4(feetPlayerPos, 1.)).xyz;
  vec4 previousClip = gbufferPreviousProjection * vec4(previousView, 1.);
  vec3 previousScreen = (previousClip.xyz / previousClip.w) * 0.5 + 0.5;
  vec2 prevCoord = previousScreen.xy;
  float previousDepth = texture(depthtex0, prevCoord).r;
 vec3 encodedNormal = texture(colortex2, texcoord).rgb;
  vec3 normal = normalize((encodedNormal - 0.5) * 2.);
    vec3 surfNorm = texture(colortex4, texcoord).rgb;
  vec3 geoNormal = normalize((surfNorm - 0.5) * 2.);
  bool historyRejection = clamp(prevCoord,0,1) != prevCoord;

   occlusion = SSAO(viewPos, geoNormal);

    #if defined(CREVICE_SMOOTHING) && ECHO_ENABLE == 1
    float factor = CREVICE_HISTORY;
    bool rejectHistory = false;
    if(depth <= 0.56 )rejectHistory = true;
         if(previousDepth <= 0.56 )rejectHistory = true;

            float historyWeight = factor * float(!historyRejection) * float(!rejectHistory);

    float previousOcclusion = texture(colortex12, prevCoord).r;
    occlusion = mix(occlusion, previousOcclusion, historyWeight);


    #endif

}

#endif
