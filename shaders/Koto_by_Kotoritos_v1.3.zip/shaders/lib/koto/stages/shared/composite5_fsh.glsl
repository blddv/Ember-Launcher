// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_CANONICAL_COMPOSITE5_FSH
#define KOTO_STAGE_CANONICAL_COMPOSITE5_FSH

#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/core/util.glsl"
#include "/lib/koto/lighting/lighting.glsl"
#include "/lib/koto/materials/block_ids.glsl"
#include "/lib/koto/reflections/screen_space_reflections.glsl"
#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/water/waves.glsl"
#include "/lib/koto/atmosphere/sky.glsl"
#include "/lib/koto/atmosphere/clouds.glsl"
#include "/lib/koto/water/water_fog.glsl"
#include "/lib/koto/post/tonemapping.glsl"
#include "/lib/koto/post/post_processing.glsl"

in vec2 texcoord;


layout(location = 0) out vec4 color;
layout(location = 1) out vec4 history;

mat3 tbnMatrix(vec3 N) {
  vec3 up = abs(N.z) < 0.999 ? vec3(0., 0., 1.) : vec3(1., 0., 0.);
  vec3 T = normalize(cross(up, N));
  vec3 B = cross(N, T);
  return (mat3(T, B, N));
}

vec3 skyFallbackBlend(
  vec3 dir,
  vec3 sunColor,
  vec3 viewPos,
  vec2 uv,
  vec3 normal,
  float roughness,
  bool isWater
) {
  // Keep non-Overworld dimensions from reflecting the Overworld atmosphere.
  if (!hasSkylight) return max(fogColor, vec3(0.));
  vec3 feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.)).xyz;
  vec3 eyePlayerPos = feetPlayerPos - gbufferModelViewInverse[3].xyz;
  normal = (gbufferModelViewInverse * vec4(normal, 1.)).xyz;
  normal = normal - gbufferModelViewInverse[3].xyz;
  vec3 dir2;
  #ifdef MIRAGE_ROUGH_ENABLE

  mat3 tbn = tbnMatrix(normal);

  //view direction in tangent space
  vec3 tangentView = normalize(transpose(tbn) * normalize(-eyePlayerPos));

  vec3 accumulated = vec3(0.);

  for (uint i = 0u; i < uint(MIRAGE_ROUGH_SAMPLES); i++) {
    vec3 noise = blue_noise(floor(gl_FragCoord.xy), KOTO_NOISE_FRAME, int(i));
    vec3 microFacit = SampleVNDFGGX(tangentView, vec2(roughness), noise.xy);

    vec3 tangentReflDir = reflect(-tangentView, microFacit);

    vec3 skyDir = normalize(tbn * tangentReflDir);

    vec3 skyCol = skyScattering(skyDir);

    accumulated = accumulated + (skyCol);

  }
  vec3 sky = accumulated / float(MIRAGE_ROUGH_SAMPLES);
  float waterOrZeroMask = float(isWater || roughness <= 0);
  vec3 altDir2 = reflect(eyePlayerPos, normal);
  vec3 altSkyCol = skyScattering(normalize(altDir2));
  vec3 altSunCol = getSun(normalize(altDir2));
  vec3 altSky = altSunCol + altSkyCol;

  dir2 = mix(dir2, altDir2, waterOrZeroMask);
  sky = mix(sky, altSky, waterOrZeroMask);
  #else
  dir2 = reflect(normalize(eyePlayerPos), normal);

  vec3 skyCol = skyScattering(dir2);
  vec3 sunCol = getSun(dir2);
  vec3 sky = sunCol + skyCol;

  #endif


  return (sky);
}


void main() {
  color = texture(colortex0, texcoord);

  float depth = texture(depthtex0, texcoord).r;
  if (depth == 1.) return;
  float rain = texture(colortex8, texcoord).r;
  if(rain == 1.) return;
  vec4 SpecMap = texture(colortex3, texcoord);
  vec3 encodedNormal = texture(colortex2, texcoord).rgb;
  vec2 lightmap = texture(colortex1, texcoord).rg;
  vec4 waterM = texture(colortex5, texcoord);
  vec3 surfNorm = texture(colortex4, texcoord).rgb;
  vec3 geoNormal = normalize((surfNorm - 0.5) * 2.);

  vec3 albedo = texture(colortex0, texcoord).rgb;

  int blockID = int(waterM) + 100;

  bool isWater = blockID == WATER_ID;
  bool isMetal = SpecMap.g >= 230. / 255.;

  //Space conversions
  vec3 screenPos = vec3(texcoord.xy, depth);
  vec3 NDCPos = vec3(texcoord, depth) * 2. - 1.;
  vec3 viewPos = projectAndDivide(gbufferProjectionInverse, NDCPos);
  vec3 viewDir = normalize(viewPos);
  vec3 feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.)).xyz;

  vec3 previousView = (gbufferPreviousModelView * vec4(feetPlayerPos, 1.)).xyz;
  vec4 previousClip = gbufferPreviousProjection * vec4(previousView, 1.);
  vec3 previousScreen = (previousClip.xyz / previousClip.w) * 0.5 + 0.5;
  vec2 prevCoord = previousScreen.xy;
  vec3 prevCol = texture(colortex9, prevCoord).rgb;
  vec3 prevViewDir = normalize(previousView);

  float farPlane = far / 0.75;


  vec3 worldPos = feetPlayerPos + cameraPosition;
  vec3 normal = normalize((encodedNormal - 0.5) * 2.);
  normal = mat3(gbufferModelView) * normal;

  vec2 noisePos = fract(worldPos.xz /64.);


  const float handDepth = MC_HAND_DEPTH * 0.5 + 0.5;
  float flatness = max(dot(normalize(geoNormal), vec3(0., 1., 0.)), 0.);
  float baseRoughness = pow(1. - SpecMap.r, 2.);
  float roughness = isWater ? 0. : baseRoughness;
  float smoothLightmap = clamp(smoothstep(13.5 / 15., 14.5 / 15., lightmap.y),0,1);

  float handMask = step(handDepth, depth);
  float waterMaskF = float(!isWater);
  float rainFactor = clamp(smoothstep(13.5 / 15., 14.5 / 15., lightmap.y), 0, 1) * wetness;
  rainFactor *= smoothstep(
    -0.45,
    0.75,
    texture(
      puddleTex,
      noisePos
    ).r
  ) * flatness * snowBiomeSmooth * hotBiomeSmooth;
  rainFactor = rainFactor * (handMask * waterMaskF);


 float waveNoise =  texture(waterTex,mod((feetPlayerPos.xz + cameraPosition.xz) / 2., 128.) / 128.).r;
  // Wave LOD: world size covered by one pixel (larger far away and at grazing angles).
  // When a pixel spans many ripples the per-pixel normal turns into sparkling noise, so the
  // ripples are widened and faded towards a flat surface instead.
  float wavePixelWorld = length(feetPlayerPos) * 2.0 / (viewHeight * gbufferProjection[1][1]);
  wavePixelWorld /= max(abs(normalize(feetPlayerPos).y), 0.08);
  float waveLodFade = 1.0 - smoothstep(0.04, 0.45, wavePixelWorld);
  #ifdef TIDE_MOTION_ENABLE
  if ((isWater)) {
    if(flatness >= 1e-6)
    {
      float waveFalloff = length(feetPlayerPos) / farPlane;
    float waveIntensityRolloff = exp(
      12. * TIDE_RIPPLE_HEIGHT * (0.05 - waveFalloff)
    );
    float waveIntensity = 0.67 * TIDE_RIPPLE_HEIGHT * waveIntensityRolloff;
    float waveSoftness = 0.13 * TIDE_RIPPLE_SOFTNESS;
    waveIntensity *= waveLodFade;
    waveSoftness = max(waveSoftness, wavePixelWorld * 1.5);

    normal = waveNormal(
      feetPlayerPos.xz + cameraPosition.xz,
      waveSoftness,
      waveIntensity
    );
    normal = mat3(gbufferModelView) * normal;
    }
  }
  if(inWater && isWater)
  {
       float waveFalloff = length(feetPlayerPos) / farPlane;
    float waveIntensityRolloff = exp(
      12. * TIDE_RIPPLE_HEIGHT * (0.05 - waveFalloff)
    );
  float waveIntensity = 0.67 * TIDE_RIPPLE_HEIGHT * waveIntensityRolloff;
    float waveSoftness = 0.2 * TIDE_RIPPLE_SOFTNESS;
    waveIntensity *= waveLodFade;
    waveSoftness = max(waveSoftness, wavePixelWorld * 1.5);

    normal = waveNormal(
      feetPlayerPos.xz + cameraPosition.xz,
      waveSoftness,
      waveIntensity
    );
    normal = mat3(gbufferModelView) * normal;
  }

   float waveFalloff = length(feetPlayerPos) / farPlane;
    float waveIntensityRolloff = exp(
      12. * TIDE_RIPPLE_HEIGHT * (0.05 - waveFalloff)
    );
   float waveIntensity = 0.137 * TIDE_RIPPLE_HEIGHT * waveIntensityRolloff;
    float waveSoftness = 0.018 * TIDE_RIPPLE_SOFTNESS;
    waveIntensity *= waveLodFade;
    waveSoftness = max(waveSoftness, wavePixelWorld * 1.5);

    vec3 rainNormal = rainNormals(
      feetPlayerPos.xz + cameraPosition.xz,
      waveSoftness,
      waveIntensity, rainFactor
    );
    rainNormal = mat3(gbufferModelView) * rainNormal;

      normal = mix(normal, rainNormal, rainFactor);
  #else
  // no additional normal modification for non-wave mode
  #endif

  // --- F0 and roughness
  vec3 f0 = vec3(SpecMap.g);
  f0 = mix(f0, vec3(0.02), float(isWater));
  f0 = mix(f0, albedo * 16., float(isMetal));
  f0 = mix(f0, vec3(1.), float(inWater && isWater));

  f0 = mix(f0, vec3(0.02), rainFactor);
  float bRough = roughness;
  float wetRoughness = mix(roughness* 0.5, roughness * 0.01, rainFactor);


  roughness = mix(roughness,wetRoughness, wetness);

  bool canReflect = roughness < 1.;





  float jitter = IGN(gl_FragCoord.xy, KOTO_NOISE_FRAME);
  vec2 offset = vec2(0., 0.);
  // --- Reflection vectors

  vec3 reflectedDir;
  #ifdef MIRAGE_ROUGH_ENABLE

  mat3 tbn = tbnMatrix(normal);

  //view direction in tangent space
  vec3 tangentView = normalize(transpose(tbn) * -viewDir);
  float NdoV = max(dot(normal, -tangentView), 0.);
  vec3 accumulated = vec3(0.);
  float ndotL = dot(normal, lightVector);
  vec3 noise = vec3(0.);
  for (uint i = 0u; i < uint(MIRAGE_ROUGH_SAMPLES); i++) {
    noise  = blue_noise(floor(gl_FragCoord.xy), KOTO_NOISE_FRAME, int(i));
    vec3 microFacit = clamp(
      SampleVNDFGGX(tangentView, vec2(roughness), noise.xy),
      0,
      1
    );

    vec3 tangentReflDir = reflect(-tangentView, microFacit);

    accumulated = accumulated + (normalize(tbn * tangentReflDir));
  }
  reflectedDir = normalize(accumulated / float(MIRAGE_ROUGH_SAMPLES));

  #else
  reflectedDir = reflect(viewDir, normal);
  #endif
  float waterOrZeroMask2 = float(isWater || roughness <= 0);
  vec3 altReflectedDir = reflect(viewDir, normal);
  reflectedDir = mix(reflectedDir, altReflectedDir, waterOrZeroMask2);
  vec3 reflectedPos = vec3(0.);
  vec3 reflectedColor = vec3(0.);



  // --- Fresnel
  float NdotV = max(dot(normal, -viewDir), 0.);
  vec3 F = fresnelSchlick(NdotV, f0);

  #ifdef MIRAGE_ENABLE
  // SSR raytrace
  bool noSky = lightmap.g < .955;
 bool reflectionHit = raytrace(
    viewPos,
    reflectedDir,
    MIRAGE_TRACE_STEPS,
    smoothLightmap,
    reflectedPos
  );

  vec3 reflectedViewPos = screenSpaceToViewSpace(reflectedPos);
  vec3 reflectedFeetPlayer = (gbufferModelViewInverse *
    vec4(reflectedViewPos, 1.)).xyz;
  vec3 reflectedEyePlayer = reflectedFeetPlayer - gbufferModelViewInverse[3].xyz;
  vec3 prevReflView = (gbufferPreviousModelView * vec4(reflectedFeetPlayer, 1.)).xyz;
  vec4 prevReflClip = gbufferPreviousProjection * vec4(prevReflView, 1.);
  vec3 previousReflPos = (prevReflClip.xyz / prevReflClip.w) * 0.5 + 0.5;
  float fadeFactor = 1. - smoothstep(0.9, 1., max(abs(reflectedPos.x - 0.5),abs(reflectedPos.y - 0.5)) * 2);
  float reflDist = distance(reflectedViewPos,viewPos);

  float lod =  3.62 * (1. - exp(-9. - sqrt(roughness)));
  float lodOverride = float(roughness <= 0. || isWater);
  lod = mix(lod, 0., lodOverride);

    vec3 sky = skyFallbackBlend(
      reflectedDir,
      vec3(1., 0.898, 0.698),
      viewPos,
      texcoord,
      normal,
      roughness,
      isWater
    ) ;

   float roughMask = step(0., roughness);
   sky = sky * (mix(1., max(exp(4.32 * (0.101 - roughness)), 0.), roughMask));

    if ((reflectionHit)) {
    if ((canReflect || isMetal || isWater)) {

      #ifdef MIRAGE_ROUGH_ENABLE
      #if MIRAGE_SOFTENING == 1
      reflectedColor = texture2DLod(colortex0, reflectedPos.xy, lod).rgb;
      #else
      reflectedColor = texture2DLod(colortex0, reflectedPos.xy, 0).rgb;
      #endif //MIP_BLUR
      #else
      reflectedColor = texture2DLod(colortex0, reflectedPos.xy, 0).rgb;
      #endif //MIRAGE_ROUGH_ENABLE

      // bilateral filter for denoising


      if (any(isnan(reflectedColor))) reflectedColor = vec3(0.);
      float roughMask2 = step(0., roughness);
      reflectedColor = reflectedColor * (mix(1., max(exp(12.02 * (0.061 - roughness)), 0.), roughMask2));

    }
  }

  if ((!reflectionHit && canReflect)) {

       reflectedColor =sky;


      reflectedColor = mix(color.rgb, reflectedColor, smoothLightmap);
  }



  reflectedColor = reflectedColor * (F);



  vec3 wetReflectedColor = mix(color.rgb, reflectedColor  , rainFactor);
  reflectedColor = mix(reflectedColor, wetReflectedColor, rainFactor);

       // --- temporal reprojection for reflections --------------------------------
  #if defined(MIRAGE_STABILIZER) && ECHO_ENABLE == 1
  {
    float depthCheck = texture(depthtex0, texcoord).r;
    const float handDepth = MC_HAND_DEPTH * 0.5 + 0.5;

      // reproject current pixel
      vec3 screenPos = vec3(texcoord.xy, depthCheck);
      vec3 NDCPos = screenPos * 2. - 1.;
      vec3 viewPos = projectAndDivide(gbufferProjectionInverse, NDCPos);
      vec3 feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.)).xyz;
      feetPlayerPos = feetPlayerPos + (cameraPosition);
      feetPlayerPos = feetPlayerPos - (previousCameraPosition);
      vec3 previousView = (gbufferPreviousModelView * vec4(feetPlayerPos, 1.)).xyz;
      vec4 previousClip = gbufferPreviousProjection * vec4(previousView, 1.);
      vec3 previousScreen = (previousClip.xyz / previousClip.w) * 0.5 + 0.5;
      vec2 prevCoord = previousScreen.xy;
      depth = linearizeDepth(depth);
      // rejection checks
      bool historyRejection = clamp(prevCoord, 0, 1) != prevCoord;
      float prevDepth = texture(depthtex0, prevCoord).r;
      float previousDepth = linearizeDepth(texture(depthtex0, prevCoord).r);
       float sampleNDCDepth = depth * 2. - 1.;
        float sampleViewDepth = gbufferProjectionInverse[3].z / (gbufferProjectionInverse[2].w * sampleNDCDepth + gbufferProjectionInverse[3].w);
      float prevViewZ = projectAndDivide(gbufferProjectionInverse, vec3(prevCoord, previousDepth) * 2. - 1.).z;
      float depthDelta = abs(depth - previousDepth);
      float depthThreshold = max(0.01, abs(prevViewZ) * 0.01);
      float depthConfidence = pow(clamp(1. - depthDelta / depthThreshold, 0, 1), 1.);
      float response = pow(roughness, 2.) * reflDist;
      float reflLum = luminance(reflectedColor);

      float factor = 0.85;
      //factor = max(factor, clamp(reflLum, 0, 1) * factor);
      if(roughness < 0.05) factor = 0.35;
      bool rejectHistory = false;
        if(depthCheck <= 0.56 )rejectHistory = true;
         if(prevDepth <= 0.56 )rejectHistory = true;
      vec4 historyColor = texture(colortex14, prevCoord);
      float historyWeight = factor * float(!historyRejection) * float(!rejectHistory)  ;
      // Fast camera turns: drop history where the surface moved a lot on screen or the
      // reprojected depth disagrees, so reflections stop smearing onto block edges.
      float pixelMotion = length((texcoord - prevCoord) * vec2(viewWidth, viewHeight));
      float reflDepthConf = 1. - smoothstep(0.02, 0.08, depthDelta / max(depth, 1e-3));
      historyWeight *= reflDepthConf * (1. - smoothstep(2., 24., pixelMotion));

      reflectedColor = mix(reflectedColor, historyColor.rgb, historyWeight);
      if (any(isnan(reflectedColor))) reflectedColor = vec3(0.);

  }
  #endif
  // Soft firefly limiter: very bright reflection samples are compressed.
  reflectedColor = reflectedColor / (1.0 + 0.25 * sqrt(max(luminance(reflectedColor), 0.0)));


  if(isMetal)
  {
    color.rgb = reflectedColor;
  }

  color.rgb = color.rgb + (reflectedColor);

  #else


  vec3 fb = skyFallbackBlend(reflectedDir,  vec3(1., 0.898, 0.698), viewPos, texcoord, normal, roughness, isWater);

  if ((canReflect && !inWater)) {
    reflectedColor = fb;
     float smoothLightmap = smoothstep(0.882, 1., lightmap.g);
    reflectedColor = mix(color.rgb, reflectedColor, smoothLightmap);
    float roughMask3 = step(0., roughness);
    reflectedColor = reflectedColor * (mix(1., max(exp(5.02 * (0.031 - roughness)), 0.), roughMask3));
  }

  reflectedColor = reflectedColor * (F);

   if(isMetal)
    {
      color.rgb = color.rgb + (reflectedColor);
    }
    color.rgb = color.rgb + (reflectedColor);
  #endif // MIRAGE_ENABLE



  // write reflection history buffer (colortex14) for next frame
  history = vec4(reflectedColor, 1.);

}

#endif
