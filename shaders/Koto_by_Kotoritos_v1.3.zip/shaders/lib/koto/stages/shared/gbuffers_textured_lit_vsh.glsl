// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_CANONICAL_GBUFFERS_TEXTURED_LIT_VSH
#define KOTO_STAGE_CANONICAL_GBUFFERS_TEXTURED_LIT_VSH

#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/materials/block_ids.glsl"

in vec4 at_tangent;
out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
out vec3 normal;
out mat3 tbnMatrix;
out vec3 modelPos;
out vec3 viewPos;
out vec3 worldPos;
out vec3 feetPlayerPos;
out vec3 eyePlayerPos;
flat out int blockID;
in vec2 mc_Entity;
out float emission;
in vec4 at_midBlock;

vec2 kotoAdjustedLightmap() {
  vec2 uv = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
  uv = uv * 33.05 / 32. - 1.05 / 32.;
  return (uv);
}

vec3 kotoPlayerNormal() {
  vec3 viewNormal = gl_NormalMatrix * gl_Normal;
  return (mat3(gbufferModelViewInverse) * viewNormal);
}

mat3 kotoBuildTBN(vec3 n) {
  const float tangentInfinity = uintBitsToFloat(0x7f800000u);
  float signValue = clamp(at_tangent.w * tangentInfinity, -1., 1.);
  vec3 t = mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * at_tangent.xyz);
  vec3 b = normalize(cross(t, n) * signValue);
  return (mat3(t, b, n));
}

void main() {
  gl_Position = ftransform();
  #if ECHO_ENABLE == 1
  gl_Position.xy += kotoTaaOffset() * gl_Position.w;
  #endif
  texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  lmcoord = kotoAdjustedLightmap();
  glcolor = gl_Color;

  normal = kotoPlayerNormal();
  tbnMatrix = kotoBuildTBN(normal);

  modelPos = gl_Vertex.xyz;
  viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
  feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.)).xyz;
  eyePlayerPos = feetPlayerPos - gbufferModelViewInverse[3].xyz;
  worldPos = cameraPosition + feetPlayerPos;
  blockID = int(mc_Entity.x + 0.5);
  emission = KOTO_BLOCK_EMISSION(blockID, at_midBlock.w);
}

#endif
