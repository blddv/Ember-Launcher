// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_SHARED_COMPOSITE3_FSH
#define KOTO_SHARED_COMPOSITE3_FSH

#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/materials/block_ids.glsl"
#include "/lib/koto/water/water_fog.glsl"
in vec2 texcoord;


layout(location = 0) out vec4 color;

void main() {
  color = texture(colortex0, texcoord);

  vec4 waterMask = texture(colortex5, texcoord);
float rain = texture(colortex8, texcoord).r;
  if(rain == 1.) return;
  float depth = texture(depthtex0, texcoord).r;
  float depth1 = texture(depthtex1, texcoord).r;

  int blockID = int(waterMask) + 100;

  bool isWater = blockID == WATER_ID;
  vec2 lightmap = texture(colortex1, texcoord).rg;

  if ((isWater && !inWater)) {
    color.rgb = waterExtinction(color.rgb, texcoord, lightmap, depth, depth1);
  }

  if ((inWater)) {
    vec3 waterScatter = waterFog(color.rgb, texcoord, lightmap, depth);

    color.rgb = waterScatter;

  }

}

#endif
