// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_CANONICAL_GBUFFERS_BEACONBEAM_FSH
#define KOTO_STAGE_CANONICAL_GBUFFERS_BEACONBEAM_FSH

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/materials/block_ids.glsl"
#include "/lib/koto/post/post_processing.glsl"
uniform sampler2D gtexture;

uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 normal;
in mat3 tbnMatrix;
flat in int blockID;
in float emission;


layout(location = 0) out vec4 color;
layout(location = 1) out vec4 lightmap;
layout(location = 2) out vec4 encodedNormal;
layout(location = 3) out vec4 specData;
layout(location = 4) out vec4 geoNormal;
layout(location = 5) out vec4 bloom;
layout(location = 6) out vec4 mask;
layout(location = 7) out vec4 ao;

void main() {
  color = texture(gtexture, texcoord) * glcolor;

  float depth = texture(depthtex0, texcoord).r;

  vec3 normalMaps = texture(normals, texcoord).rgb;
  normalMaps = normalMaps * 2. - 1.;
  normalMaps.xy = normalMaps.xy / (254. / 255.);
  normalMaps.z = sqrt(max(0., 1. - dot(normalMaps.xy, normalMaps.xy)));
  vec3 mappedNormal = tbnMatrix * normalMaps;
  ao = texture(gtexture, texcoord) * glcolor;
  ao = pow(ao, vec4(2.2));
  lightmap = vec4(lmcoord, 0., 1.);
  encodedNormal = vec4(mappedNormal * 0.5 + 0.5, 1.);
  specData = texture(specular, texcoord);

  geoNormal = vec4(normal * 0.5 + 0.5, 1.);
  if ((color.a < alphaTestRef)) {
    discard;
  }

  if ((blockID == SSS_ID)) {
    mask = vec4(1., 1., 1., 1.);
  } else {
    mask = vec4(0., 0., 0., 1.);
  }


  color.rgb = color.rgb * (1.5);
  ao.a = texture(normals,texcoord).z * 0.5 + 0.5;

}

#endif
