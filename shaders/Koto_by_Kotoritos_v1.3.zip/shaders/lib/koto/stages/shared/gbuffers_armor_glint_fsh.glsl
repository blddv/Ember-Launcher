// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_SHARED_GBUFFERS_ARMOR_GLINT_FSH
#define KOTO_SHARED_GBUFFERS_ARMOR_GLINT_FSH

uniform sampler2D gtexture;

uniform float alphaTestRef = 0.1;

in vec2 texcoord;
in vec4 glcolor;
in vec3 normal;
in vec2 lmcoord;

layout(location = 0) out vec4 color;
layout(location = 1) out vec4 encodedNormal;

void main() {
  color = texture(gtexture, texcoord) * glcolor;
  if ((color.a < alphaTestRef)) {
    discard;
  }
  color.rgb = pow(color.rgb, vec3(2.2));

  color = color * (2);

  encodedNormal = vec4(normal * 0.5 + 0.5, 1.);

}

#endif
