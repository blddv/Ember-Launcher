// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_CANONICAL_GBUFFERS_HAND_WATER_FSH
#define KOTO_STAGE_CANONICAL_GBUFFERS_HAND_WATER_FSH

#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/materials/block_ids.glsl"

uniform sampler2D gtexture;

uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 normal;
in mat3 tbnMatrix;
flat in int blockID;


layout(location = 0) out vec4 color;
layout(location = 1) out vec4 lightmap;
layout(location = 2) out vec4 encodedNormal;
layout(location = 3) out vec4 specData;
layout(location = 4) out vec4 geoNormal;
layout(location = 5) out vec4 bloom;
layout(location = 6) out vec4 mask;
layout(location = 7) out vec4 wMask;

void main() {
  color = texture(gtexture, texcoord) * glcolor;

  vec3 normalMaps = texture(normals, texcoord).rgb;
  normalMaps = normalMaps * 2. - 1.;
  normalMaps.xy = normalMaps.xy / (254. / 255.);
  normalMaps.z = sqrt(max(0., 1. - dot(normalMaps.xy, normalMaps.xy)));
  vec3 mappedNormal = tbnMatrix * normalMaps;

  lightmap = vec4(lmcoord, 0., 1.);
  encodedNormal = vec4(mappedNormal * 0.5 + 0.5, 1.);
  specData = texture(specular, texcoord);

  geoNormal = vec4(normal * 0.5 + 0.5, 1.);
  if ((color.a < alphaTestRef)) {
    discard;
  }

  if ((blockID == SSS_ID)) {
    mask = vec4(1., 1., 1., 1.);
  } else {
    mask = vec4(0., 0., 0., 1.);
  }

    if ((blockID == WATER_ID)) {
    wMask = vec4(1., 1., 1., 1.);
    color.a = color.a * (0.);

  } else {
    wMask  = vec4(0., 0., 0., 1.);
  }
}

#endif
