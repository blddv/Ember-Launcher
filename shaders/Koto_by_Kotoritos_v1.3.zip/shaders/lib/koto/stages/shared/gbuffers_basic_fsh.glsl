// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_CANONICAL_GBUFFERS_BASIC_FSH
#define KOTO_STAGE_CANONICAL_GBUFFERS_BASIC_FSH

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/materials/block_ids.glsl"
#include "/lib/koto/post/post_processing.glsl"
#include "/lib/koto/shadows/ambient_occlusion.glsl"

uniform sampler2D gtexture;

uniform float alphaTestRef = 0.1;
uniform int renderStage;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 normal;
in mat3 tbnMatrix;
in vec3 viewPos;
flat in int blockID;
in float emission;
in vec3 feetPlayerPos;


layout(location = 0) out vec4 color;
layout(location = 1) out vec4 lightmap;
layout(location = 2) out vec4 encodedNormal;
layout(location = 3) out vec4 specData;
layout(location = 4) out vec4 geoNormal;
layout(location = 5) out vec4 bloom;
layout(location = 6) out vec4 mask;
layout(location = 7) out vec4 blocklight;

void main() {
  color = texture(gtexture, texcoord) * glcolor;


  vec3 normalMaps = texture(normals, texcoord).rgb;
  normalMaps = normalMaps * 2. - 1.;
  normalMaps.xy = normalMaps.xy / (254. / 255.);
  normalMaps.z = sqrt(max(0., 1. - dot(normalMaps.xy, normalMaps.xy)));
  vec3 mappedNormal = tbnMatrix * normalMaps;


  lightmap = vec4(lmcoord, 0., 1.);
  encodedNormal = vec4(mappedNormal * 0.5 + 0.5, 1.);
  encodedNormal.a = texture(normals, texcoord).z * 0.5 + 0.5;
  specData = texture(specular, texcoord);

  geoNormal = vec4(normal * 0.5 + 0.5, 1.);
  if ((color.a < alphaTestRef)) {
    discard;
  }

  if ((blockID == SSS_ID)) {
    mask = vec4(1., 1., 1., 1.);
  } else {
    mask = vec4(0., 0., 0., 1.);
  }
 vec3 emissive = vec3(0.);
 vec3 greyAlbedo = CSB(color.rgb,1., 0.,2.915);
  #ifdef MATTER_EMISSION_RESPONSE


  if ((emission > 0)) {

    emissive = color.rgb * emission ;
    emissive = emissive + (max(luminance(greyAlbedo ), float(greyAlbedo)));
    emissive = emissive * (max(0.85 * pow(emissive, vec3(1.3528)), 0.));

    emissive = CSB(emissive, 1., 0.95, 1.);

  }
  #endif
  if(specData.a == 0. && emission > 0)
  {
     emissive = color.rgb * emission ;
    emissive = emissive + (max(luminance(greyAlbedo ), float(greyAlbedo)));
    emissive = emissive * (max(0.85 * pow(emissive, vec3(1.3528)), 0.));

    emissive = CSB(emissive, 1., 0.95, 1.);
  }

 color.rgb = color.rgb + (emissive);
  bool isEmissive = emission > 0;
blocklight.rgb =  vec3(1., 0.8, 0.5843) * lightmap.r ;

  // Line geometry (block selection outline, debug lines): flag it in colortex7 (G only) so
  // the deferred lighting, reflections and fog skip it. It stays a thin dark vanilla line.
  bool kotoIsLine = max(glcolor.r, max(glcolor.g, glcolor.b)) < 0.05;
  #ifdef MC_RENDER_STAGE_OUTLINE
  kotoIsLine = kotoIsLine || renderStage == MC_RENDER_STAGE_OUTLINE;
  #endif
  if (kotoIsLine) {
    color = vec4(0., 0., 0., 0.4);
    lightmap = vec4(0., 0., 0., 1.); // never light the block behind the line
    specData = vec4(0.);
    bloom = vec4(0.);
    blocklight = vec4(0.);
    mask = vec4(0., 1., 0., 1.);
  }

}

#endif
