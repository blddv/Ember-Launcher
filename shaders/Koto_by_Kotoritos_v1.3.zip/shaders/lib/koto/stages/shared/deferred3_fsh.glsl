// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_DEFERRED3_FSH
#define KOTO_STAGE_DEFERRED3_FSH

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/atmosphere/distance_fog.glsl"
#include "/lib/koto/materials/block_ids.glsl"
#include "/lib/koto/atmosphere/volumetrics.glsl"
in vec2 texcoord;


layout(location=0)out vec4 color;

void main(){
    color=texture(colortex0,texcoord);
     vec2 lightmap = texture(colortex1, texcoord).rg;
  float depth = texture(depthtex0, texcoord).r;
  if (depth == 1.) return;

  vec4 SpecMap = texture(colortex3, texcoord);
  bool isMetal = SpecMap.g >= 230. / 255.;

  //space conversions
  vec3 NDCPos = vec3(texcoord.xy, depth) * 2. - 1.;
  vec3 viewPos = projectAndDivide(gbufferProjectionInverse, NDCPos);
  vec3 feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.)).xyz;
  vec3 eyePlayerPos = feetPlayerPos - gbufferModelViewInverse[3].xyz;



  color.rgb = borderFog(color.rgb, eyePlayerPos, depth);


}

#endif
