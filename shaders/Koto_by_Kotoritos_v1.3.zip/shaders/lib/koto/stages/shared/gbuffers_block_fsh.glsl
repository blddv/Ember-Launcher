// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_GBUFFERS_BLOCK_FSH
#define KOTO_STAGE_GBUFFERS_BLOCK_FSH

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/materials/block_ids.glsl"
#include "/lib/koto/post/post_processing.glsl"
#include "/lib/koto/shadows/ambient_occlusion.glsl"

uniform sampler2D gtexture;
uniform int blockEntityId;

uniform float alphaTestRef = 0.1;


mat2 kotoPortalRot(float a) {
  float c = cos(a);
  float s = sin(a);
  return mat2(c, -s, s, c);
}

mat4 kotoPortalLayerMatrix(float layer) {
  float gameTime = fract(frameTimeCounter / 1200.0);
  mat4 translate = mat4(
    1.0, 0.0, 0.0, 17.0 / layer,
    0.0, 1.0, 0.0, (2.0 + layer / 1.5) * (gameTime * 1.5),
    0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 1.0
  );

  float angle = radians((layer * layer * 4321.0 + layer * 9.0) * 2.0);
  mat2 sr = kotoPortalRot(angle) * ((4.5 - layer / 4.0) * 2.0);
  mat4 scaleRotate = mat4(
    sr[0][0], sr[0][1], 0.0, 0.0,
    sr[1][0], sr[1][1], 0.0, 0.0,
    0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 1.0
  );
  mat4 scaleTranslate = mat4(
    0.5, 0.0, 0.0, 0.25,
    0.0, 0.5, 0.0, 0.25,
    0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 1.0
  );
  return scaleRotate * translate * scaleTranslate;
}

vec3 kotoPortalTint(int index) {
  float x = float(index) / 14.0;
  vec3 cyan = vec3(0.022, 0.100, 0.112);
  vec3 teal = vec3(0.075, 0.180, 0.175);
  vec3 violet = vec3(0.150, 0.105, 0.235);
  vec3 bright = vec3(0.105, 0.330, 0.355);
  vec3 tint = mix(cyan, teal, smoothstep(0.0, 0.45, x));
  tint = mix(tint, violet, smoothstep(0.35, 0.72, x) * 0.38);
  tint = mix(tint, bright, smoothstep(0.62, 1.0, x));
  return tint;
}

float kotoPortalHash(vec2 p) {
  vec3 q = fract(vec3(p.xyx) * vec3(0.11369, 0.13787, 0.10993));
  q += dot(q, q.yzx + 17.17);
  return fract((q.x + q.y) * q.z);
}

float kotoPortalStar(vec2 uv, float scale, float seed) {
  vec2 g = uv * scale;
  vec2 cell = floor(g);
  vec2 p = fract(g) - 0.5;
  float h = kotoPortalHash(cell + seed);
  float exists = step(0.965, h);
  float r = mix(0.055, 0.18, kotoPortalHash(cell + seed + 9.7));
  float sq = max(abs(p.x), abs(p.y));
  return exists * (1.0 - smoothstep(r * 0.35, r, sq));
}

vec3 kotoEndPortalEffect(vec4 projected) {
  vec2 uv = projected.xy / max(abs(projected.w), 1e-5);
  uv = uv * 0.5 + 0.5;

  // Dark teal-black base similar to the vanilla portal background.
  vec3 portal = vec3(0.0025, 0.010, 0.013);
  float t = frameTimeCounter * 0.055;

  for (int i = 0; i < 12; ++i) {
    float fi = float(i);
    float ang = fi * 0.71 + t * (0.10 + fi * 0.006);
    mat2 r = kotoPortalRot(ang);
    float sc = 3.2 + fi * 0.82;
    vec2 q = r * (uv - 0.5) * sc;
    q += vec2(fi * 0.173, t * (0.12 + fi * 0.011));

    float star = kotoPortalStar(q, 6.0 + fi * 0.55, fi * 13.37);
    float haze = 0.5 + 0.5 * sin((q.x + q.y * 0.63 + t * 0.6) * 2.1);
    vec3 tint = kotoPortalTint(i);
    portal += tint * (star * 0.62 + haze * 0.0065);
  }

  // A few brighter square points, still fully procedural and stable.
  float bright = kotoPortalStar(uv + vec2(t * 0.008, -t * 0.004), 34.0, 91.0);
  portal += vec3(0.18, 0.46, 0.56) * bright * 0.55;
  return clamp(portal, vec3(0.0), vec3(1.0));
}

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 normal;
in mat3 tbnMatrix;
in vec3 viewPos;
flat in int blockID;
in float emission;
in vec3 feetPlayerPos;
in vec4 portalProj;


layout(location = 0) out vec4 color;
layout(location = 1) out vec4 lightmap;
layout(location = 2) out vec4 encodedNormal;
layout(location = 3) out vec4 specData;
layout(location = 4) out vec4 geoNormal;
layout(location = 5) out vec4 bloom;
layout(location = 6) out vec4 mask;
layout(location = 7) out vec4 blocklight;

void main() {
  bool isEndPortal = (blockEntityId == END_PORTAL_ID) || (blockID == END_PORTAL_ID);
  if (isEndPortal) {
    color = vec4(kotoEndPortalEffect(portalProj), 1.0);
    lightmap = vec4(1.0);
    encodedNormal = vec4(0.5, 1.0, 0.5, 1.0);
    specData = vec4(0.0);
    geoNormal = vec4(0.5, 1.0, 0.5, 1.0);
    bloom = vec4(0.0);
    mask = vec4(0.0, 0.0, 1.0, 1.0);
    blocklight = vec4(0.0);
    return;
  }
  color = texture(gtexture, texcoord) * glcolor;


  vec3 normalMaps = texture(normals, texcoord).rgb;
  normalMaps = normalMaps * 2.0 - 1.0;
  normalMaps.xy /= 254.0 / 255.0;
  normalMaps.z = sqrt(max(0.0, 1.0 - dot(normalMaps.xy, normalMaps.xy)));
  vec3 mappedNormal = tbnMatrix * normalMaps;


  lightmap = vec4(lmcoord, 0.0, 1.0);
  encodedNormal = vec4(mappedNormal * 0.5 + 0.5, 1.0);
  encodedNormal.a = texture(normals,texcoord).z * 0.5 + 0.5;
  specData = texture(specular, texcoord);

  geoNormal = vec4(normal * 0.5 + 0.5, 1.0);
  if (color.a < alphaTestRef) {
    discard;
  }

  if (blockID == SSS_ID) {
    mask = vec4(1.0, 1.0, 1.0, 1.0);
  } else {
    mask = vec4(0.0, 0.0, 0.0, 1.0);
  }
 vec3 emissive = vec3(0.0);
  #ifdef MATTER_EMISSION_RESPONSE
  vec3 greyAlbedo = CSB(color.rgb,1.0, 0.0,2.915);

  if (emission > 0) {

    emissive = color.rgb * emission ;
    emissive += max(luminance(greyAlbedo ), float(greyAlbedo));
    emissive *= max(0.85 * pow(emissive, vec3(1.3528)), 0.0);

    emissive = CSB(emissive, 1.0, 0.95, 1.0);

  }
  #endif


  bool isEmissive = emission > 0;
blocklight.rgb =  vec3(1.0, 0.8, 0.5843) * lightmap.r ;
    color.rgb = mix(color.rgb, entityColor.rgb, entityColor.a);
}

#endif
