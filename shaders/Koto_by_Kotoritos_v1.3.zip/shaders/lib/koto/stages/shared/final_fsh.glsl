// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_FINAL_FSH
#define KOTO_STAGE_FINAL_FSH

#include "/lib/koto/post/tonemapping.glsl"
#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/post/post_processing.glsl"
in vec2 texcoord;


layout(location = 0) out vec4 color;

void main() {
  color = texture(colortex0, texcoord);
  vec4 kotoMask = texture(colortex7, texcoord);
  bool kotoEndPortalPixel = kotoMask.b > 0.5 && kotoMask.r < 0.5 && kotoMask.g < 0.5;
  if (kotoEndPortalPixel) {
    color.rgb = pow(max(color.rgb, vec3(0.0)), vec3(1.0 / 2.2));
    color.a = 1.0;
    return;
  }

  // Koto clarity pass: a restrained full-resolution unsharp mask.
  // It restores local block/foliage detail lost to temporal filtering without
  // changing the underlying textures or introducing a separate blur pass.
  vec2 px = 1.0 / vec2(viewWidth, viewHeight);
  vec3 n = texture(colortex0, texcoord + vec2( 0.0, -px.y)).rgb;
  vec3 s = texture(colortex0, texcoord + vec2( 0.0,  px.y)).rgb;
  vec3 w = texture(colortex0, texcoord + vec2(-px.x,  0.0)).rgb;
  vec3 e = texture(colortex0, texcoord + vec2( px.x,  0.0)).rgb;
  vec3 localMean = (n + s + w + e) * 0.25;
  vec3 detail = color.rgb - localMean;
  float limiter = 1.0 / (1.0 + dot(abs(detail), vec3(1.25)));
  color.rgb = max(color.rgb + detail * (PRISM_DETAIL_RESTORE * limiter), vec3(0.0));

  color.rgb = kotoFilmic(color.rgb);
    color.rgb = pow(color.rgb, vec3(1.0 / 2.2));
  color.rgb = CSB(color.rgb, PRISM_LIFT, PRISM_CHROMA, PRISM_CONTRAST);




}

#endif
