// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_SHARED_GBUFFERS_WEATHER_FSH
#define KOTO_SHARED_GBUFFERS_WEATHER_FSH

#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/materials/block_ids.glsl"

uniform sampler2D gtexture;

uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 normal;
in mat3 tbnMatrix;
flat in int blockID;


layout(location = 0) out vec4 color;
layout(location = 1) out vec4 lightmap;
layout(location = 2) out vec4 encodedNormal;
layout(location = 3) out vec4 bloom;
layout(location = 4) out vec4 rainMask;


void main() {
  color = texture(gtexture, texcoord) * glcolor;



  lightmap = vec4(lmcoord, 0., 1.);
  encodedNormal = vec4(normal * 0.5 + 0.5, 1.);

  if ((color.a < alphaTestRef)) {
    discard;
  }

  if ((color.r == color.g)) {
    // snow
    rainMask = vec4(0.);
    return;
  } else {
    color = vec4(0., 0., 0., 0.);
    rainMask = vec4(1., 1., 1., 1.);
  }

  rainMask = vec4(1., 1., 1., 1.);

}

#endif
