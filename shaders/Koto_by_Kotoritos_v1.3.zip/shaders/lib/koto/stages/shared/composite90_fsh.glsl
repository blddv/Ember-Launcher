// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_SHARED_COMPOSITE90_FSH
#define KOTO_SHARED_COMPOSITE90_FSH

#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/core/util.glsl"

//Full screen Reprojection

vec3 kotoRGBToYCoCg(vec3 c) {
  return vec3(0.25 * c.r + 0.5 * c.g + 0.25 * c.b, 0.5 * c.r - 0.5 * c.b, -0.25 * c.r + 0.5 * c.g - 0.25 * c.b);
}
vec3 kotoYCoCgToRGB(vec3 c) {
  return max(vec3(c.x + c.y - c.z, c.x + c.z, c.x - c.y - c.z), vec3(0.));
}

in vec2 texcoord;

const ivec2 offsets[9] = ivec2[9](
    ivec2( 0,  0),
    ivec2( 1,  0),
    ivec2(-1,  0),
    ivec2( 0,  1),
    ivec2( 0, -1),
    ivec2( 1,  1),
    ivec2(-1,  1),
    ivec2( 1, -1),
    ivec2(-1, -1)
);



layout(location = 0) out vec4 color;
layout(location = 1) out vec4 history;
void main() {
  color = texture(colortex0, texcoord);
  vec4 SpecMap = texture(colortex3, texcoord);
  float roughness = pow(1. - SpecMap.r, 2.);

  #if ECHO_ENABLE ==1
  float depth = texture(depthtex0, texcoord).r;
  const float handDepth = MC_HAND_DEPTH * 0.5 + 0.5;

  //main coords
  vec3 screenPos = vec3(texcoord.xy, depth);
  vec3 NDCPos = vec3(texcoord, depth) * 2. - 1.;
  vec3 viewPos = projectAndDivide(gbufferProjectionInverse, NDCPos);
  vec3 viewDir = normalize(viewPos);
  vec3 feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.)).xyz;

  feetPlayerPos = feetPlayerPos + (cameraPosition);

  //reprojected coords
  feetPlayerPos = feetPlayerPos - (previousCameraPosition);
  vec3 previousView = (gbufferPreviousModelView * vec4(feetPlayerPos, 1.)).xyz;
  vec4 previousClip = gbufferPreviousProjection * vec4(previousView, 1.);
  vec3 previousScreen = (previousClip.xyz / previousClip.w) * 0.5 + 0.5;
  vec2 prevCoord = previousScreen.xy;
  float previousDepth = texture(depthtex0, prevCoord).r;
  bool historyRejection = clamp(prevCoord,0,1) != prevCoord;

  float currentViewDepth = viewPos.z;
  float prevViewZ = projectAndDivide(gbufferProjectionInverse, vec3(prevCoord, previousDepth) * 2. - 1.).z;
  float depthDelta = abs(currentViewDepth - prevViewZ);

  // threshold scales with distance to avoid far-plane flicker
  float depthThreshold = max(0.01, abs(currentViewDepth) * 0.01);

  float depthConfidence = clamp(1. - depthDelta / depthThreshold, 0, 1);

  vec2 texelSize = 1. / vec2(textureSize(colortex0, 0));

  vec3 neighborhoodMin = vec3(1e20);
  vec3 neighborhoodMax = vec3(0.);

  vec3 momentA = vec3(0.);
  vec3 momentB = vec3(0.);
  for (int i = 0; i < 9; i++) {
    vec2 sampleUV = texcoord + vec2(offsets[i]) * texelSize;
    vec3 sampleCol = texture(colortex0, sampleUV).rgb;

    neighborhoodMin = min(neighborhoodMin, sampleCol);
    neighborhoodMax = max(neighborhoodMax, sampleCol);
    vec3 sampleYCoCg = kotoRGBToYCoCg(sampleCol);
    momentA += sampleYCoCg;
    momentB += sampleYCoCg * sampleYCoCg;
  }
  // Variance clipping (YCoCg): a tight colour box around the current neighbourhood.
  // It removes ghosting without throwing history away, so jittered frames accumulate
  // into a stable, anti-aliased image instead of flickering.
  vec3 momentMean = momentA / 9.0;
  vec3 momentSigma = sqrt(max(momentB / 9.0 - momentMean * momentMean, vec3(0.)));
  vec3 clipMin = momentMean - 1.25 * momentSigma;
  vec3 clipMax = momentMean + 1.25 * momentSigma;

  vec4 historyColor = texture(colortex10, prevCoord);

  // Reactive history rejection: block placement and abrupt lighting updates should
  // resolve immediately instead of animating through several accumulated frames.
  // Compare against the neighbourhood-clamped history: with sub-pixel jitter, raw edge
  // pixels change every frame and would otherwise reject history exactly where AA is needed.
  // (Old luma-based reactive rejection removed: with jitter it rejected history on every
  // textured pixel and caused the flicker. Variance clipping handles real changes.)
  float reactiveConfidence = 1.0;

  #if ECHO_STILL_CAPTURE == 0
  historyColor.rgb = kotoYCoCgToRGB(clamp(kotoRGBToYCoCg(historyColor.rgb), clipMin, clipMax));
  float factor = ECHO_WEIGHT;
  if(depth <= handDepth) factor = 0.;
  // Reject history at depth edges and whenever lighting/material response changes.
  float historyWeight = factor * float(!historyRejection) * depthConfidence * reactiveConfidence;

  // Blend in a compressed (x/(1+x)) space so very bright pixels do not flicker.
  vec3 curT = color.rgb / (1.0 + color.rgb);
  vec3 hisT = historyColor.rgb / (1.0 + historyColor.rgb);
  vec3 outT = mix(curT, hisT, historyWeight);
  color.rgb = outT / max(1.0 - outT, vec3(1e-4));
  #elif ECHO_STILL_CAPTURE == 1
  if(hideGUI == true)
  {
  neighborhoodMin = vec3(0.);
  neighborhoodMax = vec3(99999999999999.);
  historyColor.rgb = clamp(historyColor.rgb, neighborhoodMin, neighborhoodMax);
  float historyWeight =0.985 * float(!historyRejection);
  color = mix(color, historyColor, historyWeight);
  }
  else
  {
  historyColor.rgb = clamp(historyColor.rgb, neighborhoodMin, neighborhoodMax);
  float historyWeight = ECHO_WEIGHT * float(!historyRejection);
  historyWeight = historyWeight * (depthConfidence * reactiveConfidence);
  color = mix(color, historyColor, historyWeight);
  }
  #elif ECHO_STILL_CAPTURE == 2
    if(hideGUI == true)
  {
  neighborhoodMin = vec3(0.);
  neighborhoodMax = vec3(99999999999999.);
  historyColor.rgb = clamp(historyColor.rgb, neighborhoodMin, neighborhoodMax);
  float historyWeight =1.015 * float(!historyRejection);
  historyWeight = historyWeight * (depthConfidence);
  color = mix(color, historyColor, historyWeight);
  }
  else
  {
    historyColor.rgb = clamp(historyColor.rgb, neighborhoodMin, neighborhoodMax);
  float historyWeight = ECHO_WEIGHT * float(!historyRejection);
  historyWeight = historyWeight * (depthConfidence * reactiveConfidence);
  color = mix(color, historyColor, historyWeight);
  }
  #endif
  #endif


  history = color;

}

#endif
