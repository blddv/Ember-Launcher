// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_GBUFFERS_ENTITIES_VSH
#define KOTO_STAGE_GBUFFERS_ENTITIES_VSH

#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/materials/block_ids.glsl"

in vec4 at_tangent;
out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
out vec3 normal;
out mat3 tbnMatrix;
out vec3 modelPos;
out vec3 viewPos;
out vec3 feetPlayerPos;
flat out int blockID;
in vec4 at_midBlock;
out float emission;
in vec2 mc_Entity;

void main() {
  gl_Position = ftransform();
  #if ECHO_ENABLE == 1
  gl_Position.xy += kotoTaaOffset() * gl_Position.w;
  #endif
  texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
  lmcoord = lmcoord * 33.05 / 32. - 1.05 / 32.;
  glcolor = gl_Color;

  normal = gl_NormalMatrix * gl_Normal; // this gives us the normal in view space
  normal = mat3(gbufferModelViewInverse) * normal; // this converts the normal to world/player space

  const float inf = uintBitsToFloat(0x7f800000u);
  float handedness = clamp(at_tangent.w * inf, -1., 1.); // -1.0 when at_tangent.w is negative, and 1.0 when it's positive

  vec3 tangent =
    mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * at_tangent.xyz);
  vec3 binormal = normalize(cross(tangent, normal) * handedness);
  tbnMatrix = mat3(tangent, binormal, normal);

  modelPos = gl_Vertex.xyz;
  viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
  feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.)).xyz;

  blockID = int(mc_Entity.x + 0.5);
  emission = KOTO_ENTITY_EMISSION(at_midBlock.w);

}

#endif
