// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_COMPOSITE2_FSH
#define KOTO_STAGE_COMPOSITE2_FSH

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/atmosphere/distance_fog.glsl"

in vec2 texcoord;


layout(location = 0) out vec4 color;

void main() {
  color = texture(colortex0, texcoord);
  vec4 translucents = texture(colortex15, texcoord);

  float translucentAlpha = translucents.a;
  vec2 lightmap = texture(colortex1, texcoord).rg;
  float depth = texture(depthtex0, texcoord).r;

  vec3 translucentColor = translucents.rgb;

  //space conversions
  vec3 NDCPos = vec3(texcoord.xy, depth) * 2. - 1.;
  vec3 viewPos = projectAndDivide(gbufferProjectionInverse, NDCPos);
  vec3 feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.)).xyz;
  vec3 eyePlayerPos = feetPlayerPos - gbufferModelViewInverse[3].xyz;
  color.rgb  = mix(color.rgb,translucentColor , clamp(translucentAlpha, 0,1));
  vec4 kotoLineMask = texture(colortex7, texcoord);
  if (kotoLineMask.g > 0.5 && kotoLineMask.r < 0.5 && kotoLineMask.b < 0.5) {
    color.rgb = (texture(colortex0, texcoord).rgb) * 0.55; // selection outline: plain darkening
  }


}

#endif
