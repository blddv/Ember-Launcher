// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_CANONICAL_GBUFFERS_SKYBASIC_VSH
#define KOTO_STAGE_CANONICAL_GBUFFERS_SKYBASIC_VSH

#include "/lib/koto/core/uniforms.glsl"

out vec4 glcolor;
out vec2 texcoord;
out vec3 modelPos;
out vec3 viewPos;
out vec3 normal;
out vec3 feetPlayerPos;
out vec3 eyePlayerPos;

vec3 kotoSkyPlayerPosition(vec3 vpos) {
  return ((gbufferModelViewInverse * vec4(vpos, 1.)).xyz);
}

vec3 kotoSkyWorldNormal() {
  vec3 viewNormal = gl_NormalMatrix * gl_Normal;
  return (mat3(gbufferModelViewInverse) * viewNormal);
}
void main() {
  gl_Position = ftransform();
  #if ECHO_ENABLE == 1
  gl_Position.xy += kotoTaaOffset() * gl_Position.w;
  #endif
  glcolor = gl_Color;
  texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  modelPos = gl_Vertex.xyz;
  viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
  feetPlayerPos = kotoSkyPlayerPosition(viewPos);
  eyePlayerPos = feetPlayerPos - gbufferModelViewInverse[3].xyz;
  normal = kotoSkyWorldNormal();

}

#endif
