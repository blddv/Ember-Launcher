// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_CANONICAL_GBUFFERS_HAND_WATER_VSH
#define KOTO_STAGE_CANONICAL_GBUFFERS_HAND_WATER_VSH

#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/materials/block_ids.glsl"

in vec4 at_tangent;
out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
out vec3 normal;
out mat3 tbnMatrix;
flat out int blockID;
in vec2 mc_Entity;

vec2 kotoAdjustedLightmap() {
  vec2 uv = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
  uv = uv * 33.05 / 32. - 1.05 / 32.;
  return (uv);
}

vec3 kotoPlayerNormal() {
  vec3 viewNormal = gl_NormalMatrix * gl_Normal;
  return (mat3(gbufferModelViewInverse) * viewNormal);
}

mat3 kotoBuildTBN(vec3 n) {
  const float tangentInfinity = uintBitsToFloat(0x7f800000u);
  float signValue = clamp(at_tangent.w * tangentInfinity, -1., 1.);
  vec3 t = mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * at_tangent.xyz);
  vec3 b = normalize(cross(t, n) * signValue);
  return (mat3(t, b, n));
}


void main() {
  gl_Position = ftransform();
  #if ECHO_ENABLE == 1
  gl_Position.xy += kotoTaaOffset() * gl_Position.w;
  #endif
  texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  lmcoord = kotoAdjustedLightmap();
  glcolor = gl_Color;

  normal = kotoPlayerNormal();
  tbnMatrix = kotoBuildTBN(normal);

  blockID = int(mc_Entity.x + 0.5);

}

#endif
