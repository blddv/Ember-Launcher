// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_COMPOSITE9_FSH
#define KOTO_STAGE_COMPOSITE9_FSH

#include "/lib/koto/core/util.glsl"

// Koto fog resolve: the volumetric fog is ray-marched with a per-pixel dithered start
// (composite8) and accumulated over frames. Here it is filtered with a depth-aware
// 5x5 kernel before being composited, so no dither grain reaches blocks, sky or clouds.

in vec2 texcoord;

layout(location = 0) out vec4 color;

void main() {
  color = texture(colortex0, texcoord);

  #if defined(VEIL_LIGHTING) && defined(VEIL_TRACE_PRECISION)
  vec2 px = 1.0 / vec2(viewWidth, viewHeight);
  float centerZ = linearizeDepth(texture(depthtex0, texcoord).r);
  float depthTolerance = max(centerZ * 0.03, 0.05);

  vec4 fogSum = vec4(0.0);
  float weightSum = 0.0;
  for (int x = -2; x <= 2; x++) {
    for (int y = -2; y <= 2; y++) {
      vec2 uv = texcoord + vec2(x, y) * px * 1.5; // covers ~7x7 px: smooths the static fog dither
      float sampleZ = linearizeDepth(texture(depthtex0, uv).r);
      float spatial = exp(-float(x * x + y * y) * 0.18);
      float w = spatial * exp(-abs(sampleZ - centerZ) / depthTolerance);
      fogSum += texture(colortex13, uv) * w;
      weightSum += w;
    }
  }
  vec4 fog = fogSum / max(weightSum, 1e-4);
  float transmittance = clamp(fog.a, 0.0, 1.0);

  color.rgb = mix(color.rgb, fog.rgb, 1.0 - transmittance);
  float inWaterMask = float(inWater);
  color.rgb = color.rgb * mix(vec3(1.0), fog.rgb + 1.0 - transmittance, inWaterMask);
  #endif
}

#endif
