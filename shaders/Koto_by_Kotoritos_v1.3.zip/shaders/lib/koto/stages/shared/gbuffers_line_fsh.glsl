// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_GBUFFERS_LINE_FSH
#define KOTO_STAGE_GBUFFERS_LINE_FSH

// Block selection outline / debug lines. Writes ONLY the translucent colour (colortex15)
// and the line flag (colortex7), so the lightmap, normals and material data of the
// block behind the line are untouched and it can never be tinted by any lighting.

uniform sampler2D gtexture;
uniform float alphaTestRef = 0.1;

in vec2 texcoord;
in vec4 glcolor;

layout(location = 0) out vec4 color;
layout(location = 1) out vec4 mask;

void main() {
  if ((texture(gtexture, texcoord) * glcolor).a < alphaTestRef) discard;
  color = vec4(0., 0., 0., 0.4);
  mask = vec4(0., 1., 0., 1.);
}

#endif
