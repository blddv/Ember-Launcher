// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_CANONICAL_GBUFFERS_TEXTURED_LIT_FSH
#define KOTO_STAGE_CANONICAL_GBUFFERS_TEXTURED_LIT_FSH

#include "/lib/koto/lighting/lighting.glsl"
#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/shadows/soft_shadows.glsl"
#include "/lib/koto/post/post_processing.glsl"
#include "/lib/koto/materials/block_ids.glsl"
#include "/lib/koto/atmosphere/distance_fog.glsl"
#include "/lib/koto/shadows/ambient_occlusion.glsl"
uniform sampler2D gtexture;

uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 normal;
in mat3 tbnMatrix;
in vec3 modelPos;
in vec3 viewPos;
in vec3 feetPlayerPos;
in vec3 worldPos;
flat in int blockID;
in float emission;


layout(location = 0) out vec4 color;
layout(location = 1) out vec4 lightmap;
layout(location = 2) out vec4 encodedNormal;
layout(location = 3) out vec4 specData;
layout(location = 4) out vec4 geoNormal;
layout(location = 5) out vec4 mask;
layout(location = 6) out vec4 blocklight;

void main() {
  color = texture(gtexture, texcoord) * glcolor;
  vec3 normalMaps = texture(normals, texcoord, 0).rgb;
  normalMaps = normalMaps * 2. - 1.;
  normalMaps.xy = normalMaps.xy / (254. / 255.);
  normalMaps.z = sqrt(max(0., 1. - dot(normalMaps.xy, normalMaps.xy)));
  vec3 mappedNormal = tbnMatrix * normalMaps;

  lightmap = vec4(lmcoord, 0., 1.);
  encodedNormal = vec4(mappedNormal * 0.5 + 0.5, 1.);
  specData = texture(specular, texcoord);

  geoNormal = vec4(normal * 0.5 + 0.5, 1.);
  if ((color.a < 0.1)) {
    discard;
  }
  vec3 shadowViewPos = (shadowModelView * vec4(feetPlayerPos, 1.)).xyz;
  vec4 shadowClipPos = shadowProjection * vec4(shadowViewPos, 1.);
  vec3 viewDir = normalize(viewPos);
  vec3 V = normalize(cameraPosition - worldPos);
  vec3 L = normalize(worldLightVector);
  vec3 H = normalize(V + L);
  float VdotL = dot(normalize(feetPlayerPos), worldLightVector);

  bool isMetal = specData.g >= 230. / 255.;

  //PBR
  float roughness = pow(1. - specData.r, 2.);
  float sss = specData.b;
  float emission = specData.a;
  vec3 emissive = vec3(0.);
  if ((emission < 255. / 255.)) {
    emissive = emissive + (color.rgb * emission);
    emissive = emissive + (max(0.55 * pow(emissive, vec3(0.8)), 0.));

    emissive += min(
      luminance(emissive * 6.05) * pow(emissive, vec3(1.25)),
      33.15
    );
    emissive = CSB(emissive, 1. * 1., 1., 1.);
  }

  vec3 shadow = getSoftShadow(shadowClipPos, geoNormal.rgb, sss);
  vec3 f0 = vec3(0.);
  if ((isMetal)) {
    f0 = color.rgb;
  } else {
    f0 = vec3(specData.g);
  }


  if ((blockID == WATER_ID)) {
    mask = vec4(1., 1., 1., 1.);
    color.a = color.a * (0.);

  } else {
    mask = vec4(0., 0., 0., 1.);

  }
  float ao = texture(normals,texcoord).z * 0.5 + 0.5;


blocklight.rgb =  vec3(1., 0.8, 0.5843) * lightmap.r ;


  color.a = 1.;
  float depth = texture(depthtex0, texcoord).r;
  vec3 eyePlayerPos = feetPlayerPos - gbufferModelViewInverse[3].xyz;
  color = vec4(borderFog(color.rgb, eyePlayerPos, depth), color.a);
}

#endif
