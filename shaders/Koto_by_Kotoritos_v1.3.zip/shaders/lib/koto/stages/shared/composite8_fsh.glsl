// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_STAGE_CANONICAL_COMPOSITE8_FSH
#define KOTO_STAGE_CANONICAL_COMPOSITE8_FSH

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/atmosphere/distance_fog.glsl"
#include "/lib/koto/materials/block_ids.glsl"
#include "/lib/koto/atmosphere/volumetrics.glsl"
in vec2 texcoord;


layout(location=0)out vec4 color;
layout(location = 1) out vec4 history;

// Hardware PCF already filters each tap; one tap is enough up to Medium.
#if VEIL_SAMPLE_COUNT <= 24
#define KOTO_FOG_SHADOW_TAPS 1
#else
#define KOTO_FOG_SHADOW_TAPS 3
#endif
void main(){
    color=texture(colortex0,texcoord);
    vec2 lightmap=texture(colortex1,texcoord).rg;
    float depth=texture(depthtex0,texcoord).r;



    vec3 surfNorm=texture(colortex4,texcoord).rgb;
    vec3 normal=normalize((surfNorm-.5)*2.);
    //space conversions
    vec3 NDCPos=vec3(texcoord.xy,depth)*2.-1.;
    vec3 viewPos=projectAndDivide(gbufferProjectionInverse,NDCPos);
    vec3 feetPlayerPos=(gbufferModelViewInverse*vec4(viewPos,1.)).xyz;
    vec3 eyePlayerPos=feetPlayerPos-gbufferModelViewInverse[3].xyz;
    vec3 worldPos=feetPlayerPos+cameraPosition;
    vec4 waterMask=texture(colortex5,texcoord);
    int blockID=int(waterMask)+100;
    bool isWater=blockID==WATER_ID;

    vec3 noise= blue_noise(floor(gl_FragCoord.xy),KOTO_NOISE_FRAME,VEIL_DITHER_CYCLE);

    vec3 shadowViewPos_start=(shadowModelView*vec4(vec3(0.),1.)).xyz;
    vec4 shadowClipPos_start=shadowProjection*vec4(shadowViewPos_start,1.);

    vec3 shadowViewPos_end=(shadowModelView*vec4(feetPlayerPos,1.)).xyz;
    vec4 shadowClipPos_end=shadowProjection*vec4(shadowViewPos_end,1.);

    #ifdef VEIL_LIGHTING
    #ifndef VEIL_TRACE_PRECISION
    color.rgb+=volumetricRaymarch(
        shadowClipPos_start,
        shadowClipPos_end,
        VEIL_SAMPLE_COUNT,
        noise.x,
        feetPlayerPos,
        color.rgb,
        normal,
        lightmap
    );
    #endif
    #ifdef VEIL_TRACE_PRECISION

    float t=fract(worldTime/24000.);
    const int keys=7;
    const float keyFrames[keys]=float[keys](
        0.,//sunrise
        .0417,//day
        .45,//noon
        .5192,//sunset
        .5417,//night
        .9527,//midnight
        1.//sunrise
    );

    const float morningFogPhase=PHASE_DAWN;
    const float dayFogPhase=PHASE_DAY;
    const float noonFogPhase=PHASE_MIDDAY;
    const float eveningFogPhase=PHASE_DUSK;
    const float nightFogPhase=PHASE_NIGHT;

    const float fogPhase[keys]=float[keys](
        morningFogPhase,
        dayFogPhase,
        noonFogPhase,
        eveningFogPhase,
        nightFogPhase,
        nightFogPhase,
        morningFogPhase
    );
    const float intensity[keys]=float[keys](
        0.65,
        1.,
        1.,
        0.65,
        0.65,
        0.65,
        0.65
    );

    int i=0;
    //assings the keyframes
    for(int k=0;k<keys-1;++k){
        i = i + (int(step(keyFrames[k+1],t)));
    }
    i=clamp(i,0,keys-2);

    //Interpolation factor based on the time
    float timeInterp=
    (t-keyFrames[i])/max(1e-6,keyFrames[i+1]-keyFrames[i]);
    timeInterp=smoothstep(0.,1.,timeInterp);

    float phaseVal=mix(fogPhase[i],fogPhase[i+1],timeInterp);
     float skyIntensity=mix(intensity[i],intensity[i+1],timeInterp);
    const float UNIFORM_PHASE=1./(4.*PI);
    // Step length follows the preset sample count (fog cost now scales with quality).
    const float _StepSize = float(VEIL_REACH) / float(VEIL_SAMPLE_COUNT);
    const float _NoiseOffset=16.05;
    const float MULTI_SCATTER_GAIN= VEIL_BOUNCE_GAIN;// how much single scatter feeds MS
    const float MULTI_SCATTER_DECAY= VEIL_BOUNCE_DECAY;// energy loss per step

    float phaseIncFactor=smoothstep(225,0,eyeBrightnessSmooth.y);
    float scatterReduce=smoothstep(0,185,eyeBrightnessSmooth.y);
    vec3 lightScattering=vec3(11.) * PHASE_MULTIPLIER;



    vec3 entryPoint=cameraPosition;
    vec3 viewDir=worldPos-cameraPosition;
    float viewLength=length(viewDir);
    vec3 rayDir=normalize(viewDir);
    float farPlane=far*4.;
    float distLimit=min(viewLength,VEIL_REACH);
    float distTravelled=noise.x*_StepSize; // dither within one step
     vec3 absCoeff = vec3(0.5686, 0.5686, 0.5686);

    float transmittance= 1.;
    vec3 transmission = vec3(1.);
     float rayleigh = Rayleigh(dot(rayDir, worldLightVector));
    vec3 jungleCol = vec3(0.5373, 0.8196, 0.7451)  / (4 * PI);



    vec3 jungleTint = vec3(0.7412, 0.9333, 0.702) ;
    vec3 fogCol=computeSkyColoring(vec3(0.))  / (4 * PI);

    vec3 sunCol=currentSunColor(vec3(0.));
    sunCol = mix(sunCol, sunCol * jungleTint, jungleSmooth);

    fogCol = mix(fogCol, jungleCol * skyIntensity, jungleSmooth);


    fogCol=pow(fogCol,vec3(2.2));

    jungleCol = jungleCol * (195);
    fogCol = fogCol * (195);
       if(inWater)
    {

        scatterReduce = 1.;
        fogCol = WATER_SCATTERING * 0.81;
        absCoeff = WATER_ABOSRBTION * 4 ;
    }
    vec3 shadowNormal=mat3(shadowModelView)*normal;
    const float shadowMapPixelSize=1./float(UMBRA_MAP_SIZE);

    vec3 biasAdjustFactor=vec3(
        shadowMapPixelSize*1.,
        shadowMapPixelSize*1.,
    -.0003803515625);

    float sampleRadius=UMBRA_EDGE_WIDTH*shadowMapPixelSize*.34;
    vec3 multiScatterEnergy=vec3(0.);
    while(distTravelled<distLimit){
        vec3 rayPos=entryPoint+rayDir*distTravelled;
        float height=smoothstep(143,64,rayPos.y);
        vec3 shadowRayPos=rayDir*distTravelled;
        float density=getFogDensity(rayPos);
        if(density>0)
        {
            vec4 shadowClip=getShadowClipPos(shadowRayPos);
            vec3 shadow=vec3(0.);
            for(int s=0;s<KOTO_FOG_SHADOW_TAPS;s++){
                vec2 offset=vogelDisc(s,KOTO_FOG_SHADOW_TAPS,noise.x)*sampleRadius;
                vec4 offsetShadowClipPos=shadowClip+vec4(offset,0.,0.);
                offsetShadowClipPos.xyz=distortShadowClipPos(offsetShadowClipPos.xyz);// apply distortion
                vec3 shadowNDCPos=offsetShadowClipPos.xyz/offsetShadowClipPos.w;// convert to NDC space
                vec3 shadowScreenPos=shadowNDCPos*.5+.5;// convert to screen space
                // Outside the shadow map there is no information: count it as lit, with a soft
                // fade near the border, so the fog never shows straight-edged light panels.
                vec2 shadowEdge = min(shadowScreenPos.xy, 1.0 - shadowScreenPos.xy);
                float shadowInside = smoothstep(0.0, 0.06, min(shadowEdge.x, shadowEdge.y)) * step(shadowScreenPos.z, 1.0);
                shadow = shadow + mix(vec3(1.0), getShadow(shadowScreenPos), shadowInside); // take shadow sample
            }
            shadow = shadow / float(KOTO_FOG_SHADOW_TAPS);
            float shadowRangeFade = 1.0 - smoothstep(UMBRA_DISTANCE * 0.75, UMBRA_DISTANCE, distTravelled);
            shadow = mix(vec3(1.0), shadow, shadowRangeFade);

            transmission = transmission * (exp(-absCoeff * _StepSize));
            vec3 lightDir=worldLightVector;
            float phase=CS(phaseVal,dot(rayDir,lightDir)) + 0.13 * CS(-0.1,dot(rayDir,lightDir));
            if(inWater)  phase = waterPhase(dot(rayDir,lightDir));
            float scatter=density*_StepSize* float(transmittance);

            float msFactor=clamp(1.-float(transmittance),0.,1.);
            float msPhase=mix(phase,UNIFORM_PHASE,msFactor);
            vec3 singleScatter=
            sunCol*
            lightScattering*
            phase*
            scatter*
            shadow;

            multiScatterEnergy+=
            singleScatter*
            MULTI_SCATTER_GAIN*
            density;

            // decay MS energy over distance
            multiScatterEnergy = multiScatterEnergy * (MULTI_SCATTER_DECAY);
            vec3 multiScatter=
            multiScatterEnergy*
            msPhase*
            scatter;
            vec3 sampleExtinction = ( multiScatter + absCoeff);
            float sampleTransmittance = exp(-_StepSize * 1.);
            // accumulate fog

            fogCol=mix(color.rgb,fogCol,scatterReduce);
            vec3 totalInscatter = singleScatter + multiScatter ;

    fogCol +=
      (totalInscatter - totalInscatter * sampleTransmittance) /
      sampleExtinction;
        transmission = transmission * (sampleTransmittance);

            transmittance = transmittance * (exp(-density*_StepSize));
        }

        distTravelled = distTravelled + (_StepSize);
    }

    // Fog history is always accumulated (not only with TAA): the raymarch is dithered
    // per pixel, and without accumulation that dither shows up as grain on blocks,
    // very visible in the dense End and Nether fog.
    {
        float depth = texture(depthtex0, texcoord).r;
        // skip reprojecting sky/hand
        const float handDepth = MC_HAND_DEPTH * 0.5 + 0.5;

            //gather reprojection coords
            vec3 screenPos = vec3(texcoord.xy, depth);
            vec3 NDCPos = screenPos * 2. - 1.;
            vec3 viewPos = projectAndDivide(gbufferProjectionInverse, NDCPos);
            vec3 feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.)).xyz;
            feetPlayerPos = feetPlayerPos + (cameraPosition);
            feetPlayerPos = feetPlayerPos - (previousCameraPosition);
            vec3 previousView = (gbufferPreviousModelView * vec4(feetPlayerPos, 1.)).xyz;
            vec4 previousClip = gbufferPreviousProjection * vec4(previousView, 1.);
            vec3 previousScreen = (previousClip.xyz / previousClip.w) * 0.5 + 0.5;
            vec2 prevCoord = previousScreen.xy;

            // rejection checks
            bool historyRejection = clamp(prevCoord, 0, 1) != prevCoord;
            float previousDepth = texture(depthtex0, prevCoord).r;
            float currentViewDepth = viewPos.z;
            float prevViewZ = projectAndDivide(gbufferProjectionInverse, vec3(prevCoord, previousDepth) * 2. - 1.).z;
            float depthDelta = abs(currentViewDepth - prevViewZ);
               float depthThreshold = max(0.01, abs(currentViewDepth) * 0.01);
      float depthConfidence = pow(clamp(1. - depthDelta / depthThreshold, 0, 1), 1.5);

            vec4 historyColor = texture(colortex13, prevCoord) ;
            float factor = 0.85;
             bool rejectHistory = false;
            if(depth <= 0.56 )rejectHistory = true;
         if(previousDepth <= 0.56 )rejectHistory = true;

            float historyWeight = factor * float(!historyRejection) * float(!rejectHistory);
            float fogPixelMotion = length((texcoord - prevCoord) * vec2(viewWidth, viewHeight));
            historyWeight *= depthConfidence * (1. - smoothstep(4., 40., fogPixelMotion));
            // Moving entities and waving plants change the fog ray length without the camera
            // moving; reject history whose transmittance no longer matches (no ghost trails).
            float transDiff = abs(clamp(transmittance, 0., 1.) - historyColor.a);
            historyWeight *= 1. - smoothstep(0.03, 0.12, transDiff);
            #if ECHO_ENABLE == 0
            historyWeight = 0.0; // no TAA: static dither + spatial filter only, nothing can flicker
            #endif

            fogCol = mix(fogCol, historyColor.rgb, historyWeight);
            transmittance = mix(transmittance, historyColor.a, historyWeight);
            if (any(isnan(fogCol))) fogCol = vec3(0.);

    }
        // Fog colour + transmittance go to colortex13 (also next frame's history).
        // composite9 denoises them spatially and composites them over the scene.
    history = vec4(max(fogCol, vec3(0.)), clamp(transmittance, 0., 1.));
    #endif
    #endif




}

#endif
