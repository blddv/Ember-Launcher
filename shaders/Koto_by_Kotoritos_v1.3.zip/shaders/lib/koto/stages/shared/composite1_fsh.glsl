// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_SHARED_COMPOSITE1_FSH
#define KOTO_SHARED_COMPOSITE1_FSH

#include "/lib/koto/lighting/lighting.glsl"
#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/shadows/soft_shadows.glsl"
#include "/lib/koto/post/post_processing.glsl"
#include "/lib/koto/materials/block_ids.glsl"
#include "/lib/koto/post/tonemapping.glsl"
#include "/lib/koto/water/waves.glsl"
#include "/lib/koto/shadows/ambient_occlusion.glsl"

in vec2 texcoord;







layout(location = 0) out vec4 color;

void main() {
  //assign colortex buffers
  vec4 rawColor = texture(colortex15, texcoord);
  vec4 mask = texture(colortex7, texcoord);
  bool isEndPortal = mask.b > 0.5 && mask.r < 0.5 && mask.g < 0.5;
  if ((isEndPortal)) {
    color = vec4(pow(max(rawColor.rgb, vec3(0.)), vec3(2.2)), rawColor.a);
    return;
  }
  // Block selection outline (written as pure black, alpha 0.4 by gbuffers_basic): keep it a
  // plain dark line, never lit by sun, hand light or reflections.
  if (mask.g > 0.5 && mask.r < 0.5 && mask.b < 0.5) {
    color = vec4(0.0, 0.0, 0.0, 0.4);
    return;
  }
  color = pow(rawColor, vec4(2.2));
  if(color.a < 0.1) return;
  vec3 albedo = color.rgb;

  vec2 lightmap = texture(colortex1, texcoord).rg;
  vec4 SpecMap = texture(colortex3, texcoord);
  vec3 encodedNormal = texture(colortex2, texcoord).rgb;
  float ao = texture(colortex2, texcoord).a;
  vec3 normal = normalize((encodedNormal - 0.5) * 2.);
  vec3 surfNorm = texture(colortex4, texcoord).rgb;
  vec3 geoNormal = normalize((surfNorm - 0.5) * 2.);

  float depth = texture(depthtex0, texcoord).r;


  int blockID = int(mask) + 103;
   //return out of function to prevent lighting interating with sky

  //space conversions
  vec3 NDCPos = vec3(texcoord.xy, depth) * 2. - 1.;
  vec3 viewPos = projectAndDivide(gbufferProjectionInverse, NDCPos);
  vec3 feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.)).xyz;
  vec3 worldPos = cameraPosition + feetPlayerPos;
  vec3 viewDir = normalize(viewPos);
  vec3 shadowViewPos = (shadowModelView * vec4(feetPlayerPos, 1.)).xyz;
  vec4 shadowClipPos = shadowProjection * vec4(shadowViewPos, 1.);



  vec3 V = normalize(-feetPlayerPos);
  vec3 L = worldLightVector;
  vec3 H = normalize(V + L);
  float VdotL = dot(normalize(feetPlayerPos), worldLightVector);

  vec2 noisePos = fract(worldPos.xz /128.);
  float noise = texture(puddleTex, noisePos).r;
  noise = noise * (wetness);
  noise = noise * (clamp(dot(geoNormal, gbufferModelView[1].xyz),0,1));
  bool isMetal = SpecMap.g >= 230. / 255.;
  bool canScatter = blockID == SSS_ID;
  const float handDepth = MC_HAND_DEPTH * 0.5 + 0.5;
  float flatness = max(dot(normalize(geoNormal), vec3(0., 1., 0.)), 0.);


  float rainFactor = 0.;
    if(depth > handDepth )
    {

         rainFactor =
    clamp(smoothstep(13.5 / 15., 14.5 / 15., lightmap.y),0,1) * wetness;
      rainFactor *= smoothstep(
    -0.55,
    0.65,
    texture(
      puddleTex,
      noisePos
    ).r
  ) * flatness * snowBiomeSmooth * hotBiomeSmooth;
    }

  //PBR
  float roughness = pow(1. - SpecMap.r, 2.);
  float sss = 0.;
  vec3 greyAlbedo = clamp(CSB(albedo, 1., 0., 2.115), 0., 1.);

  #ifdef MATTER_TRANSMISSION
  if ((canScatter)) {
    greyAlbedo = clamp(CSB(albedo, 1., 0., 0.4), 0., 1.);
    sss = clamp(max(luminance(greyAlbedo), float(greyAlbedo)), 0, 1);
  } else {
    sss = 0.;
  }
  #else
  sss = SpecMap.b;
  #endif

   float porosity = 0.;
   #ifndef MATTER_TRANSMISSION
   if (SpecMap.b <= 64./255.)
   {
    porosity = SpecMap.b * 6.;
    sss = 0.;
   }
   else
   {
    sss = (SpecMap.b - 0.15) * 4. / 3.;
    porosity = 0.;
   }
#endif


  float emission = SpecMap.a;
 vec3 emissive = vec3(0.);
  #ifndef MATTER_EMISSION_RESPONSE
  if ((emission < 1.)) {
    emission = min(emission, 1.);
    emissive = emissive + (color.rgb * emission);
    emissive = emissive + (max(105.25 * pow(emissive, vec3(2.58)), 0.));

    emissive = CSB(emissive, 1., 0.95, 1.);
    //emissive = pow(emissive, vec3(2.2));
  }
#endif //MATTER_EMISSION_RESPONSE


  vec3 shadow = getSoftShadow(shadowClipPos, geoNormal, sss);

  vec3 f0 = vec3(0.);
  if ((isMetal)) {
    f0 = albedo;
  } else {
    f0 = vec3(SpecMap.g);
  }

  float ambientOcclusion = 1.;
  #if CREVICE_METHOD == 1
   {
     // Depth-aware 3x3 blur: the SSAO is dithered per pixel and otherwise shows as grain.
     vec2 aoPx = 1.0 / vec2(viewWidth, viewHeight);
     float aoCenterZ = linearizeDepth(depth);
     float aoSum = 0.0;
     float aoW = 0.0;
     for (int ax = -1; ax <= 1; ax++) {
       for (int ay = -1; ay <= 1; ay++) {
         vec2 aoUv = texcoord + vec2(ax, ay) * aoPx * 1.5;
         float aoZ = linearizeDepth(texture(depthtex0, aoUv).r);
         float w = exp(-abs(aoZ - aoCenterZ) / max(aoCenterZ * 0.02, 0.01));
         aoSum += texture(colortex12, aoUv).r * w;
         aoW += w;
       }
     }
     ambientOcclusion = aoSum / max(aoW, 1e-4);
   }
  #endif
  roughness = mix(roughness,roughness *0.013, noise * (1. - porosity) * 0.8);
  color.rgb = color.rgb * (1. - 0.5 * noise * porosity);

  color.rgb =
    getLighting(
      color.rgb,
      lightmap,
      normal,
      shadow,
      H,
      f0,
      roughness,
      V,
      ambientOcclusion,
      sss,
      VdotL,
      isMetal,
       ao,
      geoNormal,
      texcoord
    ) +
    emissive;



}

#endif
