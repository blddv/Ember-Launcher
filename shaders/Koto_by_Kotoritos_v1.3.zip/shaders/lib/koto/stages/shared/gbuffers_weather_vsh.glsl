// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_SHARED_GBUFFERS_WEATHER_VSH
#define KOTO_SHARED_GBUFFERS_WEATHER_VSH

#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/materials/block_ids.glsl"

in vec4 at_tangent;
out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
out vec3 normal;
out mat3 tbnMatrix;
flat out int blockID;
in vec2 mc_Entity;
out vec3 viewPos;

void main() {
  gl_Position = ftransform();
  #if ECHO_ENABLE == 1
  gl_Position.xy += kotoTaaOffset() * gl_Position.w;
  #endif
  texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
  lmcoord = lmcoord * 33.05 / 32. - 1.05 / 32.;
  glcolor = gl_Color;

  normal = gl_NormalMatrix * gl_Normal; // this gives us the normal in view space


  const float inf = uintBitsToFloat(0x7f800000u);
  float handedness = clamp(at_tangent.w * inf, -1., 1.); // -1.0 when at_tangent.w is negative, and 1.0 when it's positive

  vec3 tangent =
    mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * at_tangent.xyz);
  vec3 binormal = normalize(cross(tangent, normal) * handedness);
  tbnMatrix = mat3(tangent, binormal, normal);

  blockID = int(mc_Entity.x + 0.5);
  viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
  vec3 feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.)).xyz;
  feetPlayerPos.xz = feetPlayerPos.xz + (feetPlayerPos.y * -0.15);
  viewPos = (gbufferModelView * vec4(feetPlayerPos, 1.)).xyz;

  gl_Position = gbufferProjection * vec4(viewPos, 1.);
  #if ECHO_ENABLE == 1
  gl_Position.xy += kotoTaaOffset() * gl_Position.w;
  #endif
}

#endif
