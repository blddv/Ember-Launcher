// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef LIGHTING
#define LIGHTING

#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/core/util.glsl"
#include "/lib/koto/lighting/brdf.glsl"
#include "/lib/koto/lighting/phase.glsl"
#include "/lib/koto/post/tonemapping.glsl"

//Sun/moon
const vec4 sunlightColor = vec4(1.0, 0.860, 0.692, 1.18);
const vec4 noonSunlightColor = vec4(0.6824, 0.6824, 0.6824, 1.0);
const vec4 morningSunlightColor = vec4(0.9569, 0.4745, 0.2333, 0.85);
const vec4 eveningSunlightColor = vec4(0.9569, 0.4745, 0.2333, 1.0);
const vec4 moonlightColor = vec4(0.113, 0.138, 0.223, 0.49);

const vec4 skylightColor = vec4(0.6902, 0.8196, 0.9961, 0.831);
const vec4 morningSkylightColor = vec4(0.6353, 0.7333, 0.851, 0.831);
const vec4 eveningSkylightColor = vec4(0.6353, 0.7333, 0.851, 0.731);
const vec4 nightSkylightColor = vec4(0.336, 0.442, 0.693, 1.06);

const vec4 blocklightColor = vec4(1.0, 0.8, 0.5843, 1.0);
const vec4 ambientColor = vec4(0.015);
const vec4 caveAmbient = vec4(0.8353, 0.8353, 0.8353, 1.0);
const vec3 rainTint = vec3(0.6122, 0.5549, 0.4627);

vec3 getLighting(
    vec3 color,
    vec2 lightmap,
    vec3 normal,
    vec3 shadow,
    vec3 H,
    vec3 F0,
    float roughness,
    vec3 V,
    float ao,
    float sss,
    float VdotL,
    bool isMetal,
    float materialAo,
    vec3 faceNormal,
    vec2 uv) {

    vec3 vxBlocklight = texture(colortex9, uv).rgb;
#if HAND_LIGHT == 1
    {
        // Dynamic hand light: a torch, lantern, glowstone... held in either hand lights the
        // surroundings with vanilla falloff (1 light level per block).
        float heldLight = float(max(heldBlockLightValue, heldBlockLightValue2));
        if (heldLight > 0.0) {
            vec3 handNdc = vec3(uv, texture(depthtex0, uv).r) * 2.0 - 1.0;
            float handDist = length(projectAndDivide(gbufferProjectionInverse, handNdc));
            float handLevel = clamp((heldLight - handDist) / 15.0, 0.0, 1.0);
            // Soul torches/lanterns emit level 10: give them their cyan tint.
            vec3 handColor = abs(heldLight - 10.0) < 0.5 ? vec3(0.45, 0.85, 1.0) : vec3(1.0, 0.8, 0.5843);
            vxBlocklight = max(vxBlocklight, handColor * handLevel);
        }
    }
#endif

    float t = fract(worldTime / 24000.0);
    const int keys = 7;
    const float keyFrames[keys] = float[keys](
        0.0, //sunrise
        0.0417, //day
        0.415, //noon
        0.5122, //sunset
        0.5417, //night
        0.9527, //midnight
        1.0 //sunrise
    );
        //sunlight Keyframes
        const vec4 sunCol[keys] = vec4[keys](
            morningSunlightColor,
            sunlightColor,
            noonSunlightColor,
            eveningSunlightColor,
            moonlightColor,
            moonlightColor,
            morningSunlightColor);

        const vec4 skyCol[keys] = vec4[keys](
            morningSkylightColor,
            skylightColor,
            skylightColor,
            eveningSkylightColor,
            nightSkylightColor,
            nightSkylightColor,
            morningSkylightColor);

        const float rainLight[keys] = float[keys](
            0.15,
            0.25,
            0.25,
            0.075,
            0.33,
            0.33,
            0.15);

        int i = 0;
        //assings the keyframes
        for (int k = 0; k < keys - 1; ++k) {
            i += int(step(keyFrames[k + 1], t));
        }
        i = clamp(i, 0, keys - 2);

        //Interpolation factor based on the time
        float timeInterp =
        (t - keyFrames[i]) / max(1e-6, keyFrames[i + 1] - keyFrames[i]);
        timeInterp = smoothstep(0.0, 1.0, timeInterp);

        vec3 sunlight = mix(sunCol[i].rgb, sunCol[i + 1].rgb, timeInterp);
        float sunIntensity = mix(sunCol[i].a, sunCol[i + 1].a, timeInterp);
        float rain = mix(rainLight[i], rainLight[i + 1], timeInterp);
        float sunHeight = dot(worldLightVector, vec3(0.0, 1.0, 0.0));
        float shadowFade = smoothstep(0.005, 0.1, worldLightVector.y);
        float shadowSmooth = exp(-5.0 * UMBRA_DISTANCE);
        float shadowSmoothFade = smoothstep(0.0, 1.0, shadowSmooth);

        float wetMask = step(0.0, wetness);
        float wetFactor = wetness * hotBiomeSmooth;
        vec3 baseSunlight = sunlight;
        vec3 wetSunlight = mix(baseSunlight, rainTint, wetFactor);
        float wetMul = mix(1.0, rain, wetFactor);
        sunlight *= mix(vec3(1.0), wetSunlight, wetMask);
        sunlight *= mix(1.0, wetMul, wetMask);

        sunlight *= sunIntensity;
        sunlight *= shadowFade;
        sunlight *= mix(1.0, 0.82, kotoNightFactor());
        // The End never receives Overworld sun/moon.
#ifdef VOID_REALM_PIPE
        sunlight = vec3(0.0);
#else
        if (!hasSkylight) sunlight = vec3(0.0);
#endif

        vec3 skylight =
        mix(skyCol[i].rgb, skyCol[i + 1].rgb, timeInterp) * lightmap.g;
        skylight = mix(skylight, vec3(0.3961, 0.4627, 0.5451) * rain * lightmap.g * 2.7, wetness * hotBiomeSmooth);
        float skyIntensity = mix(skyCol[i].a, skyCol[i + 1].a, timeInterp);

        skylight *= skyIntensity;
#ifdef VOID_REALM_PIPE
        // Dim, cool ambient skylight keeps End terrain readable without looking like day.
        skylight = vec3(0.032, 0.025, 0.050) * END_AMBIENT * lightmap.g;
#else
        if (!hasSkylight) skylight = vec3(0.040, 0.010, 0.008) * NETHER_AMBIENT * lightmap.g;
#endif
        skylight *= max(1.95 * pow(skylight, vec3(2.55)), 0.0);
        skylight += min(1.7 * pow(skylight, vec3(1.25)), 1.9);
#ifndef VOID_REALM_PIPE
        // Stable nocturnal floor: prevents the world from collapsing to black
        // when the moon approaches the horizon or a celestial uniform glitches.
        skylight += vec3(0.0260, 0.0375, 0.0720) * lightmap.g * kotoNightFactor();
#endif


        vec3 blocklight = vxBlocklight;
        float blocklightIntensity = blocklightColor.a;
        blocklight *= max(5.59 * pow(blocklight, vec3(1.15)), 0.0);
        blocklight += min(0.77 * pow(blocklight, vec3(0.65)), 0.9);
         blocklight  *= smoothstep(0.0, 0.121, blocklight);

        blocklight *= blocklightIntensity;

        float faceNdl = dot(faceNormal, worldLightVector);

        float hasSSS = step(64.0 / 255.0, sss);
        float LdotH = dot(worldLightVector, H);
        float VdotH = dot(V, H);
        vec3 sssFresnel = fresnelSchlick(max(abs(LdotH), 0.0001), vec3(0.04));
        float phase =
        henyeyGreensteinPhase(VdotL, 0.72) *8;
        float uniformPhase = 1.0 / (4.0 * PI);
        vec3 scatter = vec3(0.0);

        scatter = sunlight * phase * shadow;
        vec3 baseScatter = sunlight * shadow;
        scatter += baseScatter * 2.75 * (1.0 - sssFresnel)  ;
        scatter *= hasSSS;
        scatter *= sss ;
        vec3 ambientSSS = skylight * 0.75 * sss;
        vec3 blockSSS = blocklight * 5  * sss;
        vec3 indirectSSS = ambientSSS + blockSSS * ao  * uniformPhase;
        scatter += indirectSSS;
        float faceNdlMask = step(1e-6, faceNdl);
        scatter *= mix(1.0, 0.45, faceNdlMask);

        float smoothLightmap = clamp(smoothstep(13.5 / 15.0, 14.5 / 15.0, lightmap.y),0,1);
        float ambientFactor = smoothstep(141, 0, eyeBrightnessSmooth.y);

        //ao *= ao * (1.0 - float(shadow));
        vec3 ambientLight = (mix(ambientColor.rgb,caveAmbient.rgb * 0.06, ambientFactor)* ao * materialAo) * color  ;
        ambientLight = mix(ambientLight, ambientLight * rain, wetness * hotBiomeSmooth);
#ifdef VOID_REALM_PIPE
        ambientLight *= 0.56 * END_AMBIENT;
        // Extra low-level End fill light: improves island readability without introducing a sun.
        ambientLight += color * vec3(0.010, 0.008, 0.017) * END_AMBIENT * ao * materialAo;
#else
        if (!hasSkylight) {
          ambientLight *= 0.82 * NETHER_AMBIENT;
          ambientLight += color * vec3(0.022, 0.006, 0.005) * NETHER_AMBIENT * ao * materialAo;
        }
#endif

        vec3 indirect = (skylight + blocklight) * ao * materialAo;
        float metalMask = isMetal ? 1.0 : 0.0;
        bool noSky = lightmap.g < smoothstep(0.0, 0.682, lightmap.g);
        vec3 metalIndirect = mix(indirect * 0.1,indirect  * 0 , smoothLightmap);
        indirect = mix(indirect, metalIndirect, metalMask);

        vec3 specular = brdf(
            color,
            F0,
            sunlight,
            normal,
            H,
            V,
            roughness,
            indirect,
            shadow,
            isMetal,
            smoothLightmap);

        //specular = pow(specular, vec3(2.2));

        scatter *= color;

        return specular + scatter + ambientLight ;
    }

    vec3 currentSunColor(vec3 color) {
#ifdef VOID_REALM_PIPE
        return vec3(0.0);
#else
        if (!hasSkylight) return vec3(0.0);
#endif
        float t = fract(worldTime / 24000.0);
        const int keys = 7;
        const float keyFrames[keys] = float[keys](
            0.0, //sunrise
            0.0417, //day
            0.415, //noon
            0.5122, //sunset
            0.5417, //night
            0.9527, //midnight
            1.0); //sunrise;

            //sunlight Keyframes
            const vec4 sunCol[keys] = vec4[keys](
                morningSunlightColor,
                sunlightColor,
                sunlightColor,
                eveningSunlightColor,
                moonlightColor,
                moonlightColor,
                morningSunlightColor );

            int i = 0;
            //assings the keyframes
            for (int k = 0; k < keys - 1; ++k) {
                i += int(step(keyFrames[k + 1], t));
            }
            i = clamp(i, 0, keys - 2);

            //Interpolation factor based on the time
            float timeInterp =
            (t - keyFrames[i]) / max(1e-6, keyFrames[i + 1] - keyFrames[i]);
            timeInterp = smoothstep(0.0, 1.0, timeInterp);
            float phaseIncFactor = smoothstep(225, 0, eyeBrightnessSmooth.y);
            float ambientMult = mix(1.0, 0.0, phaseIncFactor);
            vec3 sunlight = mix(sunCol[i].rgb, sunCol[i + 1].rgb, timeInterp);
            float sunIntensity = mix(sunCol[i].a, sunCol[i + 1].a, timeInterp);
            float sunHeight = dot(worldLightVector, vec3(0.0, 1.0, 0.0));
            float shadowFade = smoothstep(0.05, 0.1, worldLightVector.y);

            float wetMask = step(0.0, wetness);
            float wetFactor = wetness * hotBiomeSmooth;
            vec3 baseSunlight = sunlight;
            vec3 wetSunlight = mix(baseSunlight, rainTint, wetFactor);
            float wetMul = mix(1.0, 0.77, wetFactor);
            sunlight *= mix(vec3(1.0), wetSunlight, wetMask);
            sunlight *= mix(1.0, wetMul, wetMask);
            sunlight *= sunIntensity;
            sunlight *= shadowFade;
            return sunlight;
        }

#endif //LIGHTING_GLSL
        