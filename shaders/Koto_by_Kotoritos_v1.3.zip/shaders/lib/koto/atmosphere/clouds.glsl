// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef CLOUDS_GLSL
#define CLOUDS_GLSL

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/materials/block_ids.glsl"


float remap(float value, float originalMin, float originalMax, float newMin, float newMax)
{
    return newMin + (((value - originalMin) / (originalMax - originalMin) * (newMax - newMin)));
}


float cirrusHash12(vec2 p)
{
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 19.19);
    return fract((p3.x + p3.y) * p3.z);
}

float kotoCloudLayerMask(float h)
{
    float bottom = smoothstep(0.03, 0.24, h);
    float top = 1.0 - smoothstep(0.70, 0.98, h);
    return clamp(bottom * top, 0.0, 1.0);
}


vec3 intersectRayPlane(vec3 ray, vec3 plane) {
    return ray / dot(ray, plane) * dot(plane, plane);
}

float softCloudTexSample(sampler2D tex, vec2 uv, float radius)
{
    vec2 o = vec2(radius);
    float s = texture(tex, uv).r * 0.28;
    s += texture(tex, uv + vec2( o.x, 0.0)).r * 0.12;
    s += texture(tex, uv + vec2(-o.x, 0.0)).r * 0.12;
    s += texture(tex, uv + vec2(0.0,  o.y)).r * 0.12;
    s += texture(tex, uv + vec2(0.0, -o.y)).r * 0.12;
    s += texture(tex, uv + vec2( o.x,  o.y)).r * 0.06;
    s += texture(tex, uv + vec2(-o.x,  o.y)).r * 0.06;
    s += texture(tex, uv + vec2( o.x, -o.y)).r * 0.06;
    s += texture(tex, uv + vec2(-o.x, -o.y)).r * 0.06;
    return s;
}

vec2 boxIntersection(vec3 boundsMin, vec3 boundsMax, vec3 origin, vec3 direction)
{
    vec3 t0 = (boundsMin - origin.y) / direction.y;
    vec3 t1 = (boundsMax - origin.y) / direction.y;
    vec3 tMin = min(t0, t1);
    vec3 tMax = max(t0, t1);

    float distA = max(max(tMin.x, tMin.y), tMin.z);
    float distB = min(tMax.x, min(tMax.y, tMax.z));

    float distToBox = max(0,distA);
    float distInsideBox = max(0, distB - distToBox);
    return vec2(distToBox,distInsideBox);

}

float sampleDensity(vec3 pos)
{
    float height = 0.0;
    #if CIRRUS_STYLE == 0
        height = smoothstep(CIRRUS_FLOOR, CIRRUS_CEILING, pos.y);
        if (pos.y > CIRRUS_CEILING + CIRRUS_BODY_DEPTH) return 0.0;
        if (pos.y < CIRRUS_FLOOR) return 0.0;
    #else
        height = smoothstep(170.0, 210.0, pos.y);
        if (pos.y > 180.0 + CIRRUS_BODY_DEPTH) return 0.0;
        if (pos.y < 171.0) return 0.0;
    #endif

    vec3 uvw = pos * CIRRUS_PATTERN_SCALE * 0.0001 + 0.1;
    float layerMask = kotoCloudLayerMask(height);
    if (layerMask <= 0.0001) return 0.0;

    // Wide coverage with soft erosion for stable cloud shaping.
    // but removes the ugly pixel stairs and stippled breakup.
    float baseMain = softCloudTexSample(clouds, uvw.xz, 0.0022);
    float baseWide = softCloudTexSample(clouds, uvw.xz, 0.0048);
    float baseLarge = softCloudTexSample(cloudBase, uvw.xz * 0.36 + vec2(0.17, -0.09), 0.0010);
    float detailA = softCloudTexSample(detail, uvw.xz * 1.30, 0.0012);
    float detailB = softCloudTexSample(fogTex, uvw.xz * 0.82 + vec2(0.11), 0.0018);

    float coverage = mix(baseMain, baseWide, 0.58);
    coverage = mix(coverage, baseLarge, 0.24);
    float erosion = mix(detailA, detailB, 0.42);

    // Smooth density field. Wider thresholding avoids chunked silhouettes.
    float shape = coverage - (1.0 - erosion) * 0.065;
    float density = smoothstep(CIRRUS_THRESHOLD - 0.14,
                               CIRRUS_THRESHOLD + 0.20,
                               shape);

    // Add a little soft inner body, so clouds feel full instead of posterized.
    density += smoothstep(CIRRUS_THRESHOLD + 0.03,
                          CIRRUS_THRESHOLD + 0.24,
                          coverage) * 0.33;

    density *= layerMask;

    #if CIRRUS_STYLE == 0
        density *= 0.96 * CIRRUS_COVERAGE;
    #else
        density *= 5.15 * CIRRUS_COVERAGE;
    #endif

    return clamp(density, 0.0, 1.0);
}




float kotoCloudCoverage2D(vec2 uv, float radius)
{
    float broad = softCloudTexSample(clouds, uv, radius * 1.35);
    float wide  = softCloudTexSample(cloudBase, uv * 0.42 + vec2(0.173, -0.091), radius * 0.80);
    float soft  = softCloudTexSample(fogTex, uv * 0.78 + vec2(-0.061, 0.127), radius * 1.05);
    float fine  = softCloudTexSample(detail, uv * 1.18 + vec2(0.037, 0.019), radius * 0.55);

    float field = broad * 0.58 + wide * 0.24 + soft * 0.18;
    field -= (1.0 - fine) * 0.035;

    return smoothstep(CIRRUS_THRESHOLD - 0.16,
                      CIRRUS_THRESHOLD + 0.18,
                      field);
}


float kotoCloudDetail2D(vec2 uv, float radius)
{
    float mainPuff = softCloudTexSample(clouds, uv * 1.05 + vec2(0.021, -0.015), radius * 0.90);
    float secondary = softCloudTexSample(detail, uv * 1.95 + vec2(-0.083, 0.061), radius * 0.55);
    float tertiary = softCloudTexSample(fogTex, uv * 1.36 + vec2(0.117, -0.032), radius * 0.75);
    float breakup = softCloudTexSample(detail, uv * 2.80 + vec2(0.041, 0.099), radius * 0.35);

    float puffs = mix(mainPuff, secondary, 0.42);
    puffs = mix(puffs, tertiary, 0.28);
    puffs -= (1.0 - breakup) * 0.06;
    return clamp(puffs, 0.0, 1.0);
}

float kotoCloudWisp2D(vec2 uv, float radius)
{
    float streakA = softCloudTexSample(fogTex, uv * 0.63 + vec2(0.193, 0.074), radius * 1.20);
    float streakB = softCloudTexSample(detail, uv * 1.42 + vec2(-0.129, 0.051), radius * 0.48);
    float wisps = smoothstep(0.48, 0.78, streakA * 0.72 + streakB * 0.28);
    return wisps;
}


float kotoCloudMacro2D(vec2 uv, float radius)
{
    float macroA = softCloudTexSample(cloudBase, uv * 0.27 + vec2(-0.043, 0.071), radius * 1.60);
    float macroB = softCloudTexSample(clouds, uv * 0.52 + vec2(0.081, -0.057), radius * 1.25);
    float macro = macroA * 0.62 + macroB * 0.38;
    return smoothstep(0.46, 0.72, macro);
}

float kotoCloudPuffMask(vec2 uv, float radius)
{
    float puffA = softCloudTexSample(clouds, uv * 1.55 + vec2(0.062, -0.041), radius * 0.62);
    float puffB = softCloudTexSample(detail, uv * 2.35 + vec2(-0.071, 0.036), radius * 0.38);
    float puff = puffA * 0.76 + puffB * 0.24;
    return smoothstep(0.42, 0.78, puff);
}


vec4 kotoCloudLayerSample(vec3 rayDir, float sceneDistance, float layerY,
                          float maxCloudDistance, float night, vec2 wind,
                          float layerPhase)
{
    float t = (layerY - cameraPosition.y) / rayDir.y;
    if (t <= 0.0 || t > maxCloudDistance || t > sceneDistance + 4.0) return vec4(0.0);

    vec3 cloudPos = cameraPosition + rayDir * t;
    float distanceFactor = clamp(t / max(maxCloudDistance, 1.0), 0.0, 1.0);
    float filterRadius = mix(0.00085, 0.0046, smoothstep(0.10, 0.96, distanceFactor));

    vec2 phaseOffset = vec2(layerPhase * 0.021, -layerPhase * 0.017);
    vec2 uv = cloudPos.xz * CIRRUS_PATTERN_SCALE * 0.0001 + 0.1 + wind + phaseOffset;

    float base = kotoCloudCoverage2D(uv, filterRadius);
    float macro = kotoCloudMacro2D(uv * (0.94 + layerPhase * 0.025) + phaseOffset,
                                   filterRadius * 1.05);
    float detailShape = kotoCloudDetail2D(uv * (1.05 + layerPhase * 0.035) - phaseOffset * 0.7,
                                          filterRadius * 0.82);
    float puff = kotoCloudPuffMask(uv * (1.02 + layerPhase * 0.045) + phaseOffset * 0.4,
                                   filterRadius * 0.70);
    float wisps = kotoCloudWisp2D(uv * (0.84 + layerPhase * 0.02) - phaseOffset,
                                  filterRadius * 0.94);

    float verticalProfile = 1.0 - abs(layerPhase * 2.0 - 1.0);
    verticalProfile = pow(clamp(verticalProfile, 0.0, 1.0), 0.72);

    float shape = base * (0.56 + macro * 0.56);
    shape = mix(shape, shape * (0.66 + detailShape * 0.46), 0.64);
    shape -= (1.0 - puff) * mix(0.055, 0.11, 1.0 - verticalProfile);
    shape += wisps * 0.07 * (1.0 - shape);
    shape *= mix(0.74, 1.04, verticalProfile);
    shape = clamp(shape, 0.0, 1.0);
    if (shape <= 0.001) return vec4(0.0);

    float horizonFade = smoothstep(0.020, 0.115, abs(rayDir.y));
    float distanceFade = 1.0 - smoothstep(0.86, 1.0, distanceFactor);
    float edge = smoothstep(0.025, 0.50, shape);

    float layerAlpha = mix(0.23, 0.40, verticalProfile);
    float alpha = edge * horizonFade * distanceFade * layerAlpha;

    #if CIRRUS_STYLE == 0
        alpha *= clamp(CIRRUS_COVERAGE * 0.86, 0.0, 1.0);
    #else
        alpha *= clamp(CIRRUS_COVERAGE * 1.04, 0.0, 1.0);
    #endif

    // Surface normal from the continuous density field.
    float gradStep = max(filterRadius * 1.65, 0.00165);
    float sx = kotoCloudCoverage2D(uv + vec2(gradStep, 0.0), filterRadius);
    float sz = kotoCloudCoverage2D(uv + vec2(0.0, gradStep), filterRadius);
    vec3 normal = normalize(vec3((shape - sx) * 4.0,
                                 mix(0.68, 1.05, verticalProfile),
                                 (shape - sz) * 4.0));

    vec3 lightDir = normalize(worldLightVector);
    float lightFacing = clamp(dot(normal, lightDir) * 0.5 + 0.5, 0.0, 1.0);

    // Cheap self-shadow: sample the cloud field a little toward the light.
    vec2 lightXZ = lightDir.xz;
    float lightXZLen = max(length(lightXZ), 0.001);
    lightXZ /= lightXZLen;
    float shadowNear = kotoCloudCoverage2D(uv + lightXZ * 0.0065,
                                           filterRadius * 1.04);
    float shadowFar = kotoCloudCoverage2D(uv + lightXZ * 0.0130,
                                          filterRadius * 1.10);
    float selfShadow = clamp(1.0 - (shadowNear * 0.24 + shadowFar * 0.16), 0.52, 1.0);

    float depthDarken = mix(0.68, 1.0, layerPhase);
    float body = clamp(shape * 0.88 + detailShape * 0.24, 0.0, 1.0);
    float topLight = smoothstep(0.15, 0.95, lightFacing) * selfShadow;
    float denseCore = smoothstep(0.48, 0.92, body);

    vec3 dayBase = mix(vec3(0.34, 0.41, 0.55), vec3(0.78, 0.85, 0.93), body);
    dayBase = mix(dayBase, vec3(0.99, 0.995, 1.0), topLight * 0.72);
    dayBase *= depthDarken;
    dayBase -= vec3(0.07, 0.065, 0.055) * denseCore * (1.0 - topLight);

    vec3 nightBase = mix(vec3(0.045, 0.070, 0.145), vec3(0.19, 0.27, 0.46), body);
    nightBase = mix(nightBase, vec3(0.40, 0.50, 0.79), topLight * 0.60);
    nightBase *= mix(0.82, 1.0, layerPhase);
    nightBase -= vec3(0.025, 0.022, 0.018) * denseCore * (1.0 - topLight);

    // Golden hour: tint the sunlit side of the clouds with the current sun colour.
    vec3 sunTint = currentSunColor(vec3(0.0));
    float sunTintLum = max(dot(sunTint, vec3(0.2126, 0.7152, 0.0722)), 1e-3);
    vec3 sunHue = clamp(sunTint / sunTintLum, vec3(0.0), vec3(1.8));
    float goldenHour = (1.0 - smoothstep(0.04, 0.32, abs(lightDir.y))) * (1.0 - night);
    dayBase = mix(dayBase, dayBase * sunHue, goldenHour * (0.30 + 0.45 * topLight));

    vec3 cloudColor = mix(dayBase, nightBase, night);

    // Silver lining: thin cloud edges glow brighter when looking toward the light.
    float silver = pow(clamp(dot(rayDir, lightDir) * 0.5 + 0.5, 0.0, 1.0), 7.0);
    vec3 silverCol = mix(vec3(0.09, 0.10, 0.13), vec3(0.045, 0.055, 0.09), night);
    silverCol = mix(silverCol, silverCol * sunHue, goldenHour);
    cloudColor += silverCol * silver * edge * (0.35 + 0.65 * layerPhase) * (1.25 - 0.55 * body);

    alpha *= mix(0.82, 1.05, shape);
    return vec4(cloudColor, clamp(alpha, 0.0, 0.52));
}

vec3 cloudRaymarch(vec3 worldPos, vec3 noise, vec3 color)
{
    if (!kotoIsOverworldDimension()) return color;

    vec3 eyeVector = worldPos - cameraPosition;
    float sceneDistance = length(eyeVector);
    if (sceneDistance < 0.001) return color;

    vec3 rayDir = eyeVector / sceneDistance;
    if (abs(rayDir.y) < 0.015) return color;

    #if CIRRUS_STYLE == 0
        float cloudMid = mix(CIRRUS_FLOOR, CIRRUS_CEILING + CIRRUS_BODY_DEPTH, 0.56);
        float cloudDepth = max(18.0, CIRRUS_BODY_DEPTH * 0.90);
    #else
        float cloudMid = 176.0 + CIRRUS_BODY_DEPTH * 0.50;
        float cloudDepth = max(16.0, CIRRUS_BODY_DEPTH * 0.82);
    #endif

    float maxCloudDistance;
    #if CIRRUS_RANGE_RULE == 1
        maxCloudDistance = far * 3.0;
    #else
        maxCloudDistance = CIRRUS_REACH;
    #endif

    float tMid = (cloudMid - cameraPosition.y) / rayDir.y;
    if (tMid <= 0.0 || tMid > maxCloudDistance || tMid > sceneDistance + 4.0) return color;

    float night = kotoNightFactor();
    vec2 wind = vec2(frameTimeCounter * 0.000010,
                     frameTimeCounter * 0.0000035);

    // Five fixed layers: true parallax/depth without unstable volumetric loops.
    float y0 = cloudMid - cloudDepth * 0.50;
    float y1 = cloudMid - cloudDepth * 0.25;
    float y2 = cloudMid;
    float y3 = cloudMid + cloudDepth * 0.25;
    float y4 = cloudMid + cloudDepth * 0.50;

    vec4 l0 = kotoCloudLayerSample(rayDir, sceneDistance, y0, maxCloudDistance, night, wind * 0.92, 0.00);
    vec4 l1 = kotoCloudLayerSample(rayDir, sceneDistance, y1, maxCloudDistance, night, wind * 0.96, 0.25);
    vec4 l2 = kotoCloudLayerSample(rayDir, sceneDistance, y2, maxCloudDistance, night, wind,        0.50);
    vec4 l3 = kotoCloudLayerSample(rayDir, sceneDistance, y3, maxCloudDistance, night, wind * 1.03, 0.75);
    vec4 l4 = kotoCloudLayerSample(rayDir, sceneDistance, y4, maxCloudDistance, night, wind * 1.06, 1.00);

    vec3 result = color;

    // Composite back-to-front depending on whether the camera is below or above the cloud volume.
    if (cameraPosition.y <= cloudMid)
    {
        result = mix(result, l4.rgb, l4.a);
        result = mix(result, l3.rgb, l3.a);
        result = mix(result, l2.rgb, l2.a);
        result = mix(result, l1.rgb, l1.a);
        result = mix(result, l0.rgb, l0.a);
    }
    else
    {
        result = mix(result, l0.rgb, l0.a);
        result = mix(result, l1.rgb, l1.a);
        result = mix(result, l2.rgb, l2.a);
        result = mix(result, l3.rgb, l3.a);
        result = mix(result, l4.rgb, l4.a);
    }

    return result;
}


#endif//CLOUDS_GLSL