// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef SKY
#define SKY

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/lighting/lighting.glsl"

//Pale Garden
const vec3 paleZenCol = vec3(1.0, 1.0, 1.0);
const vec3 paleHorCol = vec3(0.7137, 0.7137, 0.7137);
const vec3 paleGrndCol = vec3(0.4314, 0.4314, 0.4314);

//rain
const vec3 rainZenCol = vec3(0.3804, 0.3922, 0.4078);
const vec3 rainHorCol = vec3(0.3843, 0.3843, 0.3843);
const vec3 rainGrndCol = vec3(0.1176, 0.1333, 0.149);

//Day
const vec3 dayZenCol = vec3(CELESTIA_DAY_ZENITH_RED, CELESTIA_DAY_ZENITH_GREEN, CELESTIA_DAY_ZENITH_BLUE);
const vec3 dayHorCol = vec3(CELESTIA_DAY_HORIZON_RED, CELESTIA_DAY_HORIZON_GREEN, CELESTIA_DAY_HORIZON_BLUE);
const vec3 dayGrndCol = vec3(CELESTIA_DAY_NADIR_RED, CELESTIA_DAY_NADIR_GREEN, CELESTIA_DAY_NADIR_BLUE);

const vec3 noonHorCol = vec3(NOON_HORIZON_COLOR_R, NOON_HORIZON_COLOR_G, NOON_HORIZON_COLOR_B);
const vec3 noonGrndCol = vec3(NOON_GROUND_COLOR_R, NOON_GROUND_COLOR_G, NOON_GROUND_COLOR_B);

//Dawn
const vec3 dawnZenCol = vec3(CELESTIA_DAWN_ZENITH_RED, CELESTIA_DAWN_ZENITH_GREEN, CELESTIA_DAWN_ZENITH_BLUE);
const vec3 dawnHorCol = vec3(CELESTIA_DAWN_HORIZON_RED, CELESTIA_DAWN_HORIZON_GREEN, CELESTIA_DAWN_HORIZON_BLUE);
const vec3 dawnGrndCol = vec3(CELESTIA_DAWN_NADIR_RED, CELESTIA_DAWN_NADIR_GREEN, CELESTIA_DAWN_NADIR_BLUE);

//Dusk
const vec3 duskZenCol = vec3(CELESTIA_DUSK_ZENITH_RED, CELESTIA_DUSK_ZENITH_GREEN, CELESTIA_DUSK_ZENITH_BLUE);
const vec3 duskHorCol = vec3(CELESTIA_DUSK_HORIZON_RED, CELESTIA_DUSK_HORIZON_GREEN, CELESTIA_DUSK_HORIZON_BLUE);
const vec3 duskGrndCol = vec3(CELESTIA_DUSK_NADIR_RED, CELESTIA_DUSK_NADIR_GREEN, CELESTIA_DUSK_NADIR_BLUE);

//Night
const vec3 nightZenCol = vec3(CELESTIA_NIGHT_ZENITH_RED, CELESTIA_NIGHT_ZENITH_GREEN, CELESTIA_NIGHT_ZENITH_BLUE);
const vec3 nightHorCol = vec3(CELESTIA_NIGHT_HORIZON_RED, CELESTIA_NIGHT_HORIZON_GREEN, CELESTIA_NIGHT_HORIZON_BLUE);
const vec3 nightGrndCol = vec3(CELESTIA_NIGHT_NADIR_RED, CELESTIA_NIGHT_NADIR_GREEN, CELESTIA_NIGHT_NADIR_BLUE);


const vec4 sunriseScatter = vec4(0.3294, 0.2196, 0.1725, 0.753);
const vec4 eveningScatter = vec4(0.8745, 0.3961, 0.1765, 0.83);
const vec4 dayScatter = vec4(0.5608, 0.3529, 0.1176, 0.715);
const vec4 noonScatter = vec4(0.7569, 0.6588, 0.5255, 0.845);
const vec4 nightScatter = vec4(0.6471, 0.4667, 0.2275, 0.65);

float kotoSquareMask(vec2 p, float halfSize, float feather) {
  float d = max(abs(p.x), abs(p.y));
  return 1.0 - smoothstep(max(0.0, halfSize - feather), halfSize + feather, d);
}

vec2 kotoCelestialUV(vec3 dir, vec3 centerDir) {
  vec3 refUp = abs(centerDir.y) > 0.94 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
  vec3 right = normalize(cross(refUp, centerDir));
  vec3 up = normalize(cross(centerDir, right));
  return vec2(dot(dir, right), dot(dir, up));
}

vec3 getSun(vec3 dir) {
  if (!kotoIsOverworldDimension()) return vec3(0.0);

  float nightFactor = kotoNightFactor();
  float dayFactor = 1.0 - nightFactor;

  vec3 sunDirection = normalize(worldSunDir);
  vec3 moonDirection = kotoStableMoonDir();

  float sunAngular = clamp(1.0 - dot(dir, sunDirection), 0.0, 1.0);
  float moonAngular = clamp(1.0 - dot(dir, moonDirection), 0.0, 1.0);

  float sunRadius = max(0.00034 * ORBIT_SOLAR_SCALE, 1e-5);
  float moonRadius = max(0.00030 * ORBIT_LUNAR_SCALE, 1e-5);

  // Koto sun: square pixel-art sun (matches the vanilla shape and the Koto moon),
  // 16 texels wide, with a brighter core and a darker rim. Its colour follows the time
  // of day: deep orange at the horizon, golden in the morning/evening, warm white at noon.
  float sunHalf = sqrt(2.0 * sunRadius);
  vec2 sunUv = kotoCelestialUV(dir, sunDirection) / sunHalf;
  float sunFacing = step(0.0, dot(dir, sunDirection));
  vec2 sunTexel = (floor(sunUv * 8.0) + 0.5) / 8.0;
  float sunTexelR = max(abs(sunTexel.x), abs(sunTexel.y));
  float sunDisk = step(sunTexelR, 1.0) * sunFacing;
  float sunCoreMask = step(sunTexelR, 0.55);
  float sunRimMask = step(0.80, sunTexelR);
  float sunElev = clamp(sunDirection.y, 0.0, 1.0);
  vec3 sunStageColor = mix(vec3(1.00, 0.42, 0.18), vec3(1.00, 0.70, 0.36), smoothstep(0.00, 0.12, sunElev));
  sunStageColor = mix(sunStageColor, vec3(1.00, 0.95, 0.82), smoothstep(0.12, 0.42, sunElev));
  vec3 sunPixelColor = sunStageColor * mix(1.0, 1.18, sunCoreMask) * mix(1.0, 0.82, sunRimMask);
  float sunSquareR = max(abs(sunUv.x), abs(sunUv.y));
  float sunAureole = exp(-max(sunSquareR - 1.0, 0.0) * 2.6) * (1.0 - sunDisk) * sunFacing;
  float moonCore = 1.0 - smoothstep(moonRadius * 0.72, moonRadius, moonAngular);

  vec2 moonUv = kotoCelestialUV(dir, moonDirection);
  float moonHalf = sqrt(max(moonRadius * 2.0, 1e-6)) * 0.92;
  float moonSquare = kotoSquareMask(moonUv, moonHalf, moonHalf * 0.10);
  float moonInner = kotoSquareMask(moonUv, moonHalf * 0.78, moonHalf * 0.07);
  float moonGlowSquare = 1.0 - smoothstep(moonHalf * 1.02, moonHalf * 2.6, max(abs(moonUv.x), abs(moonUv.y)));
  float craterA = kotoSquareMask(moonUv - vec2(-moonHalf * 0.22, moonHalf * 0.08), moonHalf * 0.12, moonHalf * 0.03);
  float craterB = kotoSquareMask(moonUv - vec2(moonHalf * 0.18, -moonHalf * 0.15), moonHalf * 0.09, moonHalf * 0.03);
  float craterC = kotoSquareMask(moonUv - vec2(0.0, moonHalf * 0.22), moonHalf * 0.07, moonHalf * 0.025);

  float sunAboveHorizon = smoothstep(-0.055, 0.075, sunDirection.y);
  float moonAboveHorizon = smoothstep(-0.055, 0.075, moonDirection.y);

  vec3 sunBase;
  sunBase = currentSunColor(sunBase);
  vec3 sunColor = mix(vec3(1.0, 0.92, 0.72), sunBase, 0.48);
  vec3 sunCoreColor = mix(sunColor, vec3(1.10, 1.02, 0.90), 0.35);
  vec3 moonColor = vec3(0.82, 0.88, 1.08);

  vec3 sunBody = sunPixelColor * (sunDisk * (3.0 * ORBIT_SOLAR_INTENSITY));
  sunBody += sunStageColor * (sunAureole * (0.08 * ORBIT_SOLAR_INTENSITY));

  float moonCraterShade = clamp(craterA * 0.18 + craterB * 0.16 + craterC * 0.12, 0.0, 0.32);
  vec3 moonTex = moonColor * mix(1.05, 0.78, moonCraterShade);
  vec3 moonBody = moonTex *
    (moonSquare * (6.0 * ORBIT_LUNAR_INTENSITY) +
     moonInner * (1.2 * ORBIT_LUNAR_INTENSITY) +
     moonGlowSquare * (0.54 * ORBIT_LUNAR_INTENSITY));

  sunBody *= dayFactor * sunAboveHorizon;
  moonBody *= nightFactor * moonAboveHorizon;

  float weatherFade = mix(1.0, 0.08, wetness * hotBiomeSmooth);
  return (sunBody + moonBody) * weatherFade;
}

vec3 skyScattering(vec3 pos) {
  // Nether and The End keep their dimension-provided background instead of the Overworld atmosphere.
  if (!kotoIsOverworldDimension()) return max(fogColor, vec3(0.0));
  vec3 dir = normalize(pos);
  float nightFactor = kotoNightFactor();
  vec3 skyLightDir = normalize(mix(worldSunDir, kotoStableMoonDir(), nightFactor));
  float VoL = dot(dir, skyLightDir);
  float rayleigh = Rayleigh(VoL) * mix(15.1, 11.2, nightFactor);

  float upPos = clamp(dir.y, 0, 1);
  float downPos = clamp(dir.y, -1, 0);
  float negatedDownPos = -1.0 * downPos;
  float midPos = upPos + negatedDownPos;
  float negatedMidPos = 1.0 - midPos;

  float t = fract(worldTime / 24000.0);

  const int keys = 7;
  const float keyFrames[keys] = float[keys](
    0.0, //sunrise
    0.0417, //day
    0.45, //noon
    0.5192, //sunset
    0.5417, //night
    0.9527, //midnight
    1.0 //sunrise
  );

    const vec3 zenithColors[keys] = vec3[keys](
    dawnZenCol,
    dayZenCol * 1.25,
    dayZenCol* 1.25,
    duskZenCol,
    nightZenCol,
    nightZenCol,
    dawnZenCol
  );
  const vec3 horizonColors[keys] = vec3[keys](
    dawnHorCol,
    dayHorCol,
    noonHorCol,
    duskHorCol,
    nightHorCol * 1.34,
    nightHorCol * 1.34,
    dawnHorCol
  );
  const vec3 groundColors[keys] = vec3[keys](
    dawnGrndCol,
    dayGrndCol,
    noonGrndCol,
    duskGrndCol,
    nightGrndCol,
    nightGrndCol,
    dawnGrndCol
  );

  const vec4 mieColor[keys] = vec4[keys](
    sunriseScatter,
    dayScatter,
    noonScatter,
    eveningScatter,
    nightScatter,
    nightScatter,
    sunriseScatter
  );
  const float weatherIntensity[keys] = float[keys](
    0.75,
    1.0,
    1.0,
    0.65,
    0.25,
    0.25,
    0.75
  );
     const float paleIntensity[keys] = float[keys](
    0.75,
    1.0,
    1.0,
    0.65,
    0.45,
    0.45,
    0.75
  );

  int i = 0;
  for (int k = 0; k < keys - 1; ++k) {
    i += int(step(keyFrames[k + 1], t));
  }
  i = clamp(i, 0, keys - 2);

  float timeInterp =
    (t - keyFrames[i]) / max(1e-6, keyFrames[i + 1] - keyFrames[i]);
  timeInterp = smoothstep(0.0, 1.0, timeInterp);

  vec3 zenithCol = mix(zenithColors[i], zenithColors[i + 1], timeInterp);
  vec3 horizonCol = mix(horizonColors[i], horizonColors[i + 1], timeInterp);
  vec3 groundCol = mix(groundColors[i], groundColors[i + 1], timeInterp);

  float weatherStrength = mix(
    weatherIntensity[i],
    weatherIntensity[i + 1],
    timeInterp
  );
  float paleStrength = mix(
    paleIntensity[i],
    paleIntensity[i + 1],
    timeInterp
  );

  zenithCol = mix(zenithCol, paleZenCol * paleStrength, PaleGardenSmooth);
  horizonCol = mix(horizonCol, paleHorCol * paleStrength, PaleGardenSmooth);
  groundCol = mix(groundCol, paleGrndCol * paleStrength, PaleGardenSmooth);

  zenithCol = mix(zenithCol, rainZenCol * weatherStrength, wetness * hotBiomeSmooth);
  horizonCol = mix(horizonCol, rainHorCol * weatherStrength, wetness * hotBiomeSmooth);
  groundCol = mix(groundCol, rainGrndCol * weatherStrength, wetness * hotBiomeSmooth);

  float zenithBlend = clamp(pow(upPos, 0.45), 0, 1);
  float horizonBlend = clamp(pow(negatedMidPos, 4.5), 0, 1);
  float groundBlend = clamp(pow(negatedDownPos, 0.55), 0, 1);

  zenithCol *= rayleigh * zenithBlend;
  horizonCol *= rayleigh * horizonBlend;
  groundCol *= rayleigh * groundBlend;

  vec3 sky = zenithCol + horizonCol + groundCol;

  vec3 sunColor;
  sunColor = currentSunColor(sunColor);

  vec3 moonMieScatterColor = vec3(0.0941, 0.0941, 0.2196);
  vec3 mieScat = mix(mieColor[i].rgb, mieColor[i + 1].rgb, timeInterp);
  mieScat = mix(mieScat, vec3(0.0), wetness);
  moonMieScatterColor = mix(moonMieScatterColor, vec3(0.0), wetness);
  float mieScale = mix(mieColor[i].a, mieColor[i + 1].a, timeInterp);

  float sVoL = dot(dir, normalize(worldSunDir));
  float mVoL = dot(dir, kotoStableMoonDir());

  float dayMask = 1.0 - nightFactor;
  float miePhase = CS(mieScale, sVoL);
  vec3 mieColors = mieScat * miePhase * 0.95 * dayMask;

  float moonPhase = CS(0.86, mVoL);
  vec3 mieNight = moonMieScatterColor * moonPhase * 0.105 * nightFactor;

  vec3 finalMie = mieColors + mieNight ;
  float sunHeightFactor = smoothstep(groundBlend, groundBlend + 0.041, dir.y);
  finalMie *=sunHeightFactor;

    sky *= mix(1.0, 0.88, nightFactor);
    vec3 color = sky + finalMie;
   color = pow(max(color, vec3(0.0)), vec3(2.2));
  return color;
}

vec3 computeSkyColoring(vec3 pos)
{
  vec3 dir = normalize(pos);
  float nightFactor = kotoNightFactor();
  vec3 skyLightDir = normalize(mix(worldSunDir, kotoStableMoonDir(), nightFactor));
  float VoL = dot(dir, skyLightDir);
  float rayleigh = Rayleigh(VoL) * mix(12.1, 9.4, nightFactor);
  float t = fract(float(worldTime) / 24000.0);

  const int keys = 7;
  const float keyFrames[keys] = float[keys](
    0.0, //sunrise
    0.0417, //day
    0.45, //noon
    0.5192, //sunset
    0.5417, //night
    0.9527, //midnight
    1.0 //sunrise
  );

    const vec3 zenithColors[keys] = vec3[keys](
    dawnZenCol * 0.81 ,
    dayZenCol,
    dayZenCol,
    duskZenCol * 0.81 ,
    nightZenCol * 1.07,
    nightZenCol * 1.07,
    dawnZenCol * 0.81
  );
  const float weatherIntensity[keys] = float[keys](
    0.75,
    1.0,
    1.0,
    0.65,
    0.45,
    0.45,
    0.75
  );
    const float paleIntensity[keys] = float[keys](
    0.75,
    1.0,
    1.0,
    0.65,
    0.45,
    0.45,
    0.75
  );

  int i = 0;
  for (int k = 0; k < keys - 1; ++k) {
    i += int(step(keyFrames[k + 1], t));
  }
  i = clamp(i, 0, keys - 2);

  float timeInterp =
    (t - keyFrames[i]) / max(1e-6, keyFrames[i + 1] - keyFrames[i]);
  timeInterp = smoothstep(0.0, 1.0, timeInterp);
   float weatherStrength = mix(
    weatherIntensity[i],
    weatherIntensity[i + 1],
    timeInterp
  );
  float paleStrength = mix(
    paleIntensity[i],
    paleIntensity[i + 1],
    timeInterp
  );

  vec3 zenithCol = mix(zenithColors[i], zenithColors[i + 1], timeInterp);
  zenithCol = mix(zenithCol, rainZenCol * weatherStrength, wetness * hotBiomeSmooth);
  zenithCol = mix(zenithCol, paleZenCol * paleStrength, PaleGardenSmooth);
  zenithCol *= mix(1.0, 0.92, nightFactor);

  return zenithCol;
}

#endif
