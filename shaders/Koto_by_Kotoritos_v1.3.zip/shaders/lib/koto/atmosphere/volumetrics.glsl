// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef VOLUMETRICS_GLSL
#define VOLUMETRICS_GLSL

#include "/lib/koto/shadows/soft_shadows.glsl"
#include "/lib/koto/core/util.glsl"
#include "/lib/koto/water/water_fog.glsl"
#include "/lib/koto/lighting/lighting.glsl"
#include "/lib/koto/post/tonemapping.glsl"
#include "/lib/koto/atmosphere/distance_fog.glsl"



vec3 volumetricRaymarch(
  vec4 startPos,
  vec4 endPos,
  int stepCount,
  float jitter,
  vec3 feetPlayerPos,
  vec3 sceneColor,
  vec3 normal,
  vec2 lightmap
) {
  float t = fract(worldTime / 24000.);
  const int keys = 7;
  const float keyFrames[keys] = float[keys](
    0., //sunrise
    0.0417, //day
    0.45, //noon
    0.5192, //sunset
    0.5417, //night
    0.9527, //midnight
    1. //sunrise
  );

  const float morningFogPhase = PHASE_DAWN;
  const float dayFogPhase = PHASE_DAY;
  const float noonFogPhase = PHASE_MIDDAY;
  const float eveningFogPhase = PHASE_DUSK;
  const float nightFogPhase = PHASE_NIGHT;

  const float fogPhase[keys] = float[keys](
    morningFogPhase,
    dayFogPhase,
    noonFogPhase,
    eveningFogPhase,
    nightFogPhase,
    nightFogPhase,
    morningFogPhase
  );

   const float rainFog[keys] = float[keys](
    1.55,
    0.95,
    0.85,
    0.75,
    0.75,
    0.75,
    0.84

  );
  const float ambientI[keys] = float[keys](1.4, 1.64, 1.64, 1.3, 9.27, 9.27, 1.4);
  int i = 0;
  //assings the keyframes
  for (int k = 0; k < keys - 1; ++k) {
    i = i + (int(step(keyFrames[k + 1], t)));
  }
  i = clamp(i, 0, keys - 2);

  //Interpolation factor based on the time
  float timeInterp =
    (t - keyFrames[i]) / max(1e-6, keyFrames[i + 1] - keyFrames[i]);
  timeInterp = smoothstep(0., 1., timeInterp);

  float phaseVal = mix(fogPhase[i], fogPhase[i + 1], timeInterp);
  float rain = mix(rainFog[i], rainFog[i + 1], timeInterp);
  float ambientIntensity = mix(ambientI[i], ambientI[i + 1], timeInterp);
  vec4 rayPos = endPos - startPos;
  vec4 stepSize = rayPos * (1. / stepCount);
  vec3 eyePlayerPos = feetPlayerPos - gbufferModelViewInverse[3].xyz;
  vec3 worldPos = feetPlayerPos + cameraPosition;

  float rayLength = clamp(length(eyePlayerPos) + 1, 0, far);
  vec4 stepLength = startPos + (jitter + 0.5) * stepSize;
 const float falloffScale = 0.001 / log(2.);
  float fogMaxHeight = smoothstep(157, 8, worldPos.y);

  vec3 absCoeff = vec3(0.4706, 0.5333, 0.6353);
  vec3 scatterCoeff = vec3(0.00335, 0.00291, 0.00231);

  //absCoeff = mix(absCoeff, vec3(1.0), PaleGardenSmooth);
  scatterCoeff = mix(scatterCoeff, vec3(0.00715), PaleGardenSmooth);

  scatterCoeff = mix(scatterCoeff, vec3(0.0040, 0.0043, 0.00519), wetness);

  if ((inWater)) {
    absCoeff = WATER_ABOSRBTION * 0.35;
    scatterCoeff = WATER_SCATTERING * 0.085;
  }

  vec3 scatter = vec3(0.);
  vec3 transmission = vec3(1.);

  float VdotL = dot(normalize(feetPlayerPos), worldLightVector);
  float phaseIncFactor = smoothstep(225, 0, eyeBrightnessSmooth.y);
  float scatterReduce = smoothstep(0, 185, eyeBrightnessSmooth.y);
  float phaseMult = 1.;

  float ambientMult = mix(1., 0., phaseIncFactor);
   if(!inWater)
  {
   phaseMult = mix(1., 4., phaseIncFactor);
  }
  else{
    phaseMult = 1.;
    ambientMult = 0.;
  }

  float phase =
    CS(phaseVal,VdotL) * PHASE_FORWARD_GAIN +
    CS(-0.25, VdotL) * PHASE_BACKWARD_GAIN * 0.85;

  phase = mix(phase,CS(0.65, VdotL) * rain +
    CS(-0.25, VdotL) * rain, wetness);
  phase = phase * (phaseMult);

 if(inWater)
 {
    phase = CS(0.885, VdotL);
 }

  vec3 sunColor;

  sunColor = currentSunColor(sunColor);
   const float shadowMapPixelSize = 1. / float(UMBRA_MAP_SIZE);

    vec3 biasAdjustFactor = vec3(
    shadowMapPixelSize * 1.,
    shadowMapPixelSize * 1.,
    -0.0003803515625
  );
  float sampleRadius = UMBRA_EDGE_WIDTH * shadowMapPixelSize * 0.54;
  vec3 shadowNormal = mat3(shadowModelView) * normal;

  vec3 shadow = vec3(0.);
  for (int i = 0; i < stepCount; i++) {
      vec4 prevStep = stepLength;
    stepLength = stepLength + (stepSize);

    for (int s = 0; s < 3; s++) {
      vec2 offset = vogelDisc(s, 3, jitter) * sampleRadius;
      vec4 offsetShadowClipPos = prevStep + vec4(offset, 0., 0.);
      offsetShadowClipPos.xyz = distortShadowClipPos(offsetShadowClipPos.xyz); // apply distortion
    vec3 shadowNDCPos = offsetShadowClipPos.xyz / offsetShadowClipPos.w; // convert to NDC space
    vec3 shadowScreenPos = shadowNDCPos * 0.5 + 0.5; // convert to screen space
    shadowScreenPos = shadowScreenPos + (shadowNormal * biasAdjustFactor);
    vec2 shadowEdge = min(shadowScreenPos.xy, 1.0 - shadowScreenPos.xy);
    float shadowInside = smoothstep(0.0, 0.06, min(shadowEdge.x, shadowEdge.y)) * step(shadowScreenPos.z, 1.0);
    shadow = shadow + mix(vec3(1.0), getShadow(shadowScreenPos), shadowInside); // outside the map = lit
    }
    shadow = shadow / (float(3));

    transmission = transmission * (exp(-absCoeff * length(stepLength)));


    vec3 directLight = sunColor * shadow;


  vec3 singleScatter = scatterCoeff * phase * rayLength * directLight * ambientIntensity ;

    vec3 msLight = sunColor * (0.35 + 0.63 * shadow);
    vec3 multiScatter = scatterCoeff * msLight * 45. * ambientMult;
    multiScatter = multiScatter * (exp(-absCoeff * (float(i) / length(stepLength))));

    vec3 sampleExtinction = (absCoeff + multiScatter) * VEIL_EXTINCTION;
    float sampleTransmittance = exp(-length(stepLength) * 1.);

    // combine single + multiple scattering
    vec3 totalInscatter = singleScatter + multiScatter ;

    scatter +=
      (totalInscatter - totalInscatter * sampleTransmittance) /
      sampleExtinction;
    transmission = transmission * (sampleTransmittance);

  }
  float fogDistFalloff = length(feetPlayerPos) / far;
  float fogReduction = exp( 0.525 * (1. - fogDistFalloff));


 scatter = scatter * (0.045 * fogReduction);
  vec3 totalScatter = scatter  ;

  return (mix(sceneColor, scatter, 1. - clamp(transmission,0,1)));

}

#endif //VOLUMETRICS_GLSL
