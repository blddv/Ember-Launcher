// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef FOG
#define FOG
#include "/lib/koto/atmosphere/sky.glsl"
#include "/lib/koto/shadows/distortion.glsl"
#include "/lib/koto/shadows/shadow_sampling.glsl"

vec3 borderFog(vec3 color, vec3 dir, float depth) {
    vec3 fogColor = skyScattering(normalize(dir));
    float dist = length(dir) / far;
    float fogFactor = exp(-18. * (1. - dist));
    float rainFogFactor = exp(-7.37 * (1. - dist));
    fogFactor = mix(fogFactor, rainFogFactor, wetness);
    return (mix(color, fogColor, clamp(fogFactor, 0., 1.)));
}




float remap1(float value, float originalMin, float originalMax, float newMin, float newMax)
{
    return (newMin + (((value - originalMin) / (originalMax - originalMin) * (newMax - newMin))));
}

float getFogDensity(vec3 pos)
{
    const float totalDensity = 0.0055;
    float jungleHeight = smoothstep(101, 75, pos.y);
    float height = smoothstep(mix(VEIL_CEILING, VEIL_CEILING + 30, wetness), mix(VEIL_FLOOR, VEIL_FLOOR + 30, wetness), pos.y);

    height = mix(height, jungleHeight, jungleSmooth);

    vec4 shape = vec4(0.);
    vec4 detail1 = vec4(0.);
    vec4 detail2 = vec4(0.);
    float density = 0.;

    vec3 uvw = pos * VEIL_PATTERN_SCALE * 0.0001 + 1. * 0.1 * (frameTimeCounter * 0.003) * VEIL_DRIFT;
    float baseDensity = 0.0025;
    shape = texture(fogTex, uvw.xz);
    if(!inWater)
    {
    #if VEIL_VARIATION == 1
    detail1 = texture(cloudBase, uvw.xz);
    detail2 = texture(detail, uvw.xz);
    shape.r = remap1(shape.r, 1. - detail1.r , 1., 0., 1.);
    shape.r = mix(shape.r * 3, shape.r , jungleHeight);
    shape = mix(shape, vec4(1.), wetness);
    float threshold = max(0, shape.r - VEIL_PATTERN_GATE);
    float jungleThreshold =   max(0.3, shape.r - 0.025);
    threshold = mix(threshold, jungleThreshold, jungleSmooth);

    density = threshold * VEIL_DENSITY;
    #else
    density = 0.325;
    #endif
    float morningFog = smoothstep(0.3, 0.1, worldLightVector.y);
    density = mix(density, density * 1.4, morningFog);
    density = mix(density, density * 2.5, jungleSmooth);

    density = density * (totalDensity * height);
    density = density + (baseDensity * height);
    }
    else
    {
        density = 0.04;
    }
    if(inWater) density = 0.04;
     if(pos.y < 55 && eyeBrightness.y < 0.2 && !inWater) density = 0;
      density = mix(density, density * 2.5, wetness);
#ifndef VOID_REALM_PIPE
    // Overworld haze was far too dense (white-out that hid the sun); Nether/End unchanged.
    if (!inWater && hasSkylight) density *= OVERWORLD_FOG;
#endif
    return (density);
}


#endif //FOG
