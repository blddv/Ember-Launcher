// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef POST_PROCESSING_GLSL
#define POST_PROCESSING_GLSL

uniform float contrast = PRISM_CONTRAST;
uniform float saturation = PRISM_CHROMA;
uniform float brightness = PRISM_LIFT;


// For all settings: 1.0 = 100% 0.5=50% 1.5 = 150%
vec3 CSB(vec3 color, float brt, float sat, float con) {
  const vec3 lumaWeights = vec3(0.2125, 0.7154, 0.0721);
  vec3 bright = color * brt;
  vec3 grayscale = vec3(dot(bright, lumaWeights));
  vec3 saturated = grayscale + (bright - grayscale) * sat;
  return vec3(1.0) + (saturated - vec3(1.0)) * con;
}
#endif
