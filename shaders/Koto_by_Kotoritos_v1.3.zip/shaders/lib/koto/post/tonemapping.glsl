// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef TONEMAP
#define TONEMAP

#include "/lib/koto/core/util.glsl"

// Koto filmic curve.
// A rational toe/shoulder curve with hand-tuned constants: a soft toe in the shadows,
// mid-grey kept close to its input and highlights rolling off smoothly towards white.
// Highlights also lose a little saturation, so bright light reads as light, not as a
// clipped primary colour.
vec3 kotoFilmicCurve(vec3 x) {
  x = max(x, vec3(0.0));
  return (x * (x + 0.14)) / (x * (x + 0.165) + 0.26);
}

vec3 kotoFilmic(vec3 rgb) {
  vec3 perChannel = kotoFilmicCurve(rgb);
  float lum = dot(max(rgb, vec3(0.0)), vec3(0.2126, 0.7152, 0.0722));
  float mappedLum = kotoFilmicCurve(vec3(lum)).x;
  vec3 hueKept = rgb * (mappedLum / max(lum, 1e-5));
  float highlight = smoothstep(0.6, 4.0, lum);
  vec3 mapped = mix(perChannel, min(hueKept, vec3(1.0)), 0.3 * (1.0 - highlight));
  return clamp(mapped, 0.0, 1.0);
}

#endif // TONEMAP
