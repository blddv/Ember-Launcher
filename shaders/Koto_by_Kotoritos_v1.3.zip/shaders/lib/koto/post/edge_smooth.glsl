// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef KOTO_EDGE_SMOOTH_GLSL
#define KOTO_EDGE_SMOOTH_GLSL

// Koto edge smoothing.
// Finds the direction of an edge with a Sobel operator on compressed luma, then blends
// a few bilinear samples taken along the edge (never across it). Flat areas and fine
// texture detail below the contrast threshold are left untouched.

float kotoEdgeLuma(vec3 rgb) {
  float l = dot(max(rgb, vec3(0.0)), vec3(0.2627, 0.6780, 0.0593));
  return sqrt(l / (1.0 + l));
}

float kotoEdgeLumaAt(sampler2D tex, vec2 uv) {
  return kotoEdgeLuma(textureLod(tex, uv, 0.0).rgb);
}

vec3 kotoEdgeSmooth(vec3 color, sampler2D tex, vec2 uv) {
  vec2 px = 1.0 / vec2(viewWidth, viewHeight);

  float c  = kotoEdgeLuma(color);
  float n  = kotoEdgeLumaAt(tex, uv + vec2( 0.0, -px.y));
  float s  = kotoEdgeLumaAt(tex, uv + vec2( 0.0,  px.y));
  float e  = kotoEdgeLumaAt(tex, uv + vec2( px.x, 0.0));
  float w  = kotoEdgeLumaAt(tex, uv + vec2(-px.x, 0.0));
  float ne = kotoEdgeLumaAt(tex, uv + vec2( px.x, -px.y));
  float nw = kotoEdgeLumaAt(tex, uv + vec2(-px.x, -px.y));
  float se = kotoEdgeLumaAt(tex, uv + vec2( px.x,  px.y));
  float sw = kotoEdgeLumaAt(tex, uv + vec2(-px.x,  px.y));

  float lo = min(c, min(min(n, s), min(e, w)));
  float hi = max(c, max(max(n, s), max(e, w)));
  float contrast = hi - lo;
  if (contrast < max(0.035, hi * 0.11)) return color;

  // Sobel gradient; the edge runs perpendicular to it.
  float gx = (ne + 2.0 * e + se) - (nw + 2.0 * w + sw);
  float gy = (sw + 2.0 * s + se) - (nw + 2.0 * n + ne);
  float gLen = length(vec2(gx, gy));
  if (gLen < 1e-4) return color;
  vec2 along = vec2(-gy, gx) / gLen;

  // Samples along the edge at increasing distance, with falling weights.
  vec3 sum = color * 1.0;
  float wsum = 1.0;
  const float dist[3] = float[3](0.75, 1.75, 2.75);
  const float wgt[3] = float[3](0.9, 0.55, 0.25);
  for (int i = 0; i < 3; i++) {
    vec2 o = along * dist[i] * px;
    sum += (textureLod(tex, uv + o, 0.0).rgb + textureLod(tex, uv - o, 0.0).rgb) * wgt[i];
    wsum += 2.0 * wgt[i];
  }
  vec3 smoothed = sum / wsum;

  // Stronger edges get more smoothing; single-pixel specks get a little extra.
  float avg = (n + s + e + w) * 0.25;
  float speck = clamp(abs(avg - c) / contrast, 0.0, 1.0);
  float amount = clamp(contrast * 3.0, 0.0, 1.0) * mix(0.75, 1.0, speck * speck);
  return mix(color, smoothed, amount);
}

#endif // KOTO_EDGE_SMOOTH_GLSL
