// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef TIDE_VEIL_ENABLE
#define TIDE_VEIL_ENABLE 1 //[0 1]

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/core/settings.glsl"
#include "/lib/koto/lighting/phase.glsl"
#include "/lib/koto/lighting/lighting.glsl"

const vec3 WATER_ABOSRBTION = vec3(TIDE_ABSORB_RED, TIDE_ABSORB_GREEN, TIDE_ABSORB_BLUE);
const vec3 WATER_SCATTERING = vec3(TIDE_SCATTER_RED, TIDE_SCATTER_GREEN, TIDE_SCATTER_BLUE);

vec3 waterExtinction(
  vec3 color,
  vec2 texcoord,
  vec2 lightmap,
  float depth,
  float depth1
) {

  float t = fract(worldTime / 24000.);

  const int keys = 7;
  const float keyFrames[keys] = float[keys](
    0., //sunrise
    0.0417, //day
    0.45, //noon
    0.5192, //sunset
    0.5417, //night
    0.9527, //midnight
    1. //sunrise
  );

  const float fogIntensity[keys] = float[keys](
    0.85,
    1.,
    1.,
    0.85,
    0.025,
    0.025,
    0.85
  );
  int i = 0;
  //assings the keyframes
  for (int k = 0; k < keys - 1; ++k) {
    i = i + (int(step(keyFrames[k + 1], t)));
  }
  i = clamp(i, 0, keys - 2);

  //Interpolation factor based on the time
  float timeInterp =
    (t - keyFrames[i]) / max(1e-6, keyFrames[i + 1] - keyFrames[i]);
  timeInterp = smoothstep(0., 1., timeInterp);

  float fog = mix(fogIntensity[i], fogIntensity[i + 1], timeInterp);

  float dist0 = length(screenToView(texcoord, depth));
  float dist1 = length(screenToView(texcoord, depth1));
  float dist = max(0, dist1 - dist0);
  vec3 sunColor = vec3(0.);
  sunColor = currentSunColor(sunColor) * 0.12;
  if ((inWater)) {
    dist = dist0;
  }

  vec3 absorptionColor = vec3(0.);
  vec3 absorption = WATER_ABOSRBTION;
  vec3 inscatteringAmount = vec3(0.);
  inscatteringAmount = WATER_SCATTERING ;
  inscatteringAmount = inscatteringAmount * (TIDE_SCATTER_GAIN);
  inscatteringAmount = inscatteringAmount * (fog);

  inscatteringAmount = pow(inscatteringAmount, vec3(2.2));

   vec3 screenPos = vec3(texcoord.xy, depth);
  vec3 NDCPos = vec3(texcoord, depth) * 2. - 1.;
  vec3 viewPos = projectAndDivide(gbufferProjectionInverse, NDCPos);
  vec3 viewDir = normalize(viewPos);
  float VdotL = dot(viewDir, lightVector);
   float phase = waterPhase(VdotL);
  float backPhase = henyeyGreensteinPhase(VdotL, -0.);
float smoothDepth = smoothstep(0.998, 1., depth);
  float scatterReduce = smoothstep(0, 185, eyeBrightnessSmooth.y);
  float fogDistFalloff = length(viewPos) / far;
  float fogReduction = exp( 0.75 * (-2.5 - fogDistFalloff));
  vec3 phaseLighting = sunColor * scatterReduce * fogReduction;
  vec3 scattering = inscatteringAmount   ;
  vec3 totalScattering = (phaseLighting + scattering) * TIDE_SCATTER_GAIN;
  vec3 absorptionFactor = exp(
    -absorption * TIDE_SURFACE_VEIL * (dist * TIDE_ABSORPTION_GAIN * 6)
  );

  color = color * (absorptionFactor);
  color +=
    totalScattering /
    absorption *
    (1. - clamp(absorptionFactor, 0, 1));

   return (color);
}
vec3 waterFog(vec3 color, vec2 texcoord, vec2 lightmap, float depth) {

  float dist0 = length(screenToView(texcoord, depth));

  float dist = dist0;
  vec3 sunColor = vec3(0.);
  sunColor = currentSunColor(sunColor) * 0.7;
  vec3 absorptionColor = vec3(0.);
  vec3 absorption = WATER_ABOSRBTION * 2;
  vec3 inscatteringAmount = vec3(0.);
  inscatteringAmount = WATER_SCATTERING * 7;
  inscatteringAmount = inscatteringAmount * (TIDE_SCATTER_GAIN);
  inscatteringAmount = pow(inscatteringAmount, vec3(2.2));
  absorption = pow(absorption, vec3(2.2));
  vec3 screenPos = vec3(texcoord.xy, depth);
  vec3 NDCPos = vec3(texcoord, depth) * 2. - 1.;
  vec3 viewPos = projectAndDivide(gbufferProjectionInverse, NDCPos);
  vec3 viewDir = normalize(viewPos);
  float VdotL = dot(viewDir, lightVector);
  float phase = waterPhase(VdotL);
  float backPhase = henyeyGreensteinPhase(VdotL, -0.1);
  float smoothDepth = smoothstep(0.998, 1., depth);
   float scatterReduce = smoothstep(0, 185, eyeBrightnessSmooth.y);
    #ifdef VEIL_LIGHTING
    phase = 1.;
    backPhase = 1.;
    inscatteringAmount = inscatteringAmount * (0.);
    absorption = absorption * (0.);
    #endif
  vec3 phaseLighting = sunColor * phase * scatterReduce;
  vec3 scattering = inscatteringAmount  * backPhase ;
  vec3 totalScattering = (phaseLighting + scattering) * TIDE_SCATTER_GAIN;
  vec3 absorptionFactor = exp(
    -absorption * TIDE_DEPTH_VEIL * (dist * TIDE_ABSORPTION_GAIN)
  );
  color.rgb = color.rgb * (absorptionFactor);
   color.rgb = color.rgb + ((totalScattering / absorption) * (1. - absorptionFactor));

  return (color.rgb);
}

#endif //TIDE_VEIL_ENABLE
