// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#ifndef WAVES_GLSL
#define WAVES_GLSL

// Koto water surface.
// A sum of directional crest waves: directions follow the golden angle, every layer gets
// shorter and faster (deep-water dispersion), and the surface is warped and calmed in
// patches by the pack's own noise textures. Slopes are analytic, so layers that are
// smaller than the pixel footprint are simply faded out instead of turning into noise.

const float KOTO_GOLDEN_ANGLE = 2.39996323;

float kotoWaveTime() {
  float t = frameTimeCounter;
  #if ECHO_STILL_CAPTURE == 1
  if (hideGUI == true) t = 0.0;
  #endif
  return t;
}

// 0 = calm patch, 1 = open water. Large, slow variation across the lake or ocean.
float kotoWaterCalmness(vec2 pos) {
  float broad = texture(cloudBase, pos * 0.000145 + 0.3).r;
  float fine = texture(detail, pos * 0.000145 + 0.3).r;
  return clamp(smoothstep(0.25, 0.75, broad * 0.75 + fine * 0.25), 0.35, 1.0);
}

// Height in [0,1] and its slope (d height / d xz).
float kotoWaveField(vec2 pos, int layers, float filterWidth, out vec2 slope) {
  float t = kotoWaveTime();
  float calm = kotoWaterCalmness(pos);

  // Gentle domain warp so the crests never line up into a visible grid.
  vec2 warpUv = pos / 96.0;
  vec2 warp = vec2(texture(waterTex, warpUv).r, texture(waterTex, warpUv + vec2(0.8479, 0.83)).r) - 0.5;
  vec2 p = pos + warp * (1.6 * TIDE_RIPPLE_VARIATION);

  float sharpness = 1.0 + 2.0 * TIDE_RIPPLE_LEAN;
  float frequency = 1.1;
  float amplitude = 1.0;
  float speedScale = 1.0;

  float height = 0.0;
  float weightSum = 0.0;
  slope = vec2(0.0);

  for (int i = 0; i < layers; i++) {
    float angle = float(i) * KOTO_GOLDEN_ANGLE + 0.7;
    vec2 dir = vec2(cos(angle), sin(angle));

    // Deep-water waves: speed grows with the square root of the frequency.
    float speed = sqrt(9.81 * frequency) * 0.55 * speedScale;
    float phase = dot(dir, p) * frequency + t * speed + float(i) * 1.913;

    float s = sin(phase);
    float base = 0.5 + 0.5 * s;
    float crest = pow(base, sharpness);
    float dCrest = sharpness * pow(max(base, 1e-4), sharpness - 1.0) * 0.5 * cos(phase);

    // Fade layers whose wavelength is close to or below the pixel footprint.
    float wavelength = 6.2831853 / frequency;
    float lod = 1.0 - smoothstep(1.0, 3.0, filterWidth * 4.0 / wavelength);

    float w = amplitude * lod;
    height += crest * w;
    slope += dCrest * frequency * dir * w;
    weightSum += amplitude;

    frequency *= 1.27 * TIDE_RIPPLE_SPACING;
    amplitude *= 0.74;
    speedScale *= mix(1.0, TIDE_RIPPLE_RATE, 0.35);
  }

  float norm = 1.0 / max(weightSum, 1e-4);
  slope *= norm * calm;
  return height * norm * calm;
}

float getwaves(vec2 position, int iterations) {
  vec2 unused;
  return kotoWaveField(position, iterations, 0.0, unused);
}

// Surface normal; `e` is the filter width (world size of one pixel or the softness).
vec3 waveNormal(vec2 pos, float e, float depth) {
  vec2 slope;
  kotoWaveField(pos, TIDE_RIPPLE_LAYERS, e, slope);
  return normalize(vec3(-slope.x * depth, 1.0, -slope.y * depth));
}

// Rain: expanding rings from raindrops landing on a jittered grid.
float kotoHash12(vec2 p) {
  vec3 q = fract(vec3(p.xyx) * vec3(0.1213, 0.1471, 0.1319));
  q += dot(q, q.yzx + 82.73);
  return fract((q.x + q.y) * q.z);
}

float getRainWaves(vec2 position, int iterations, float rainAmount) {
  float t = kotoWaveTime();
  float rings = 0.0;
  // Two drop scales: large slow rings and small fast ones.
  for (int scale = 0; scale < 2; scale++) {
    float cellSize = scale == 0 ? 1.15 : 0.55;
    float rate = scale == 0 ? 0.9 : 1.4;
    vec2 p = position / cellSize;
    vec2 cell = floor(p);
    for (int y = -1; y <= 1; y++) {
      for (int x = -1; x <= 1; x++) {
        vec2 id = cell + vec2(x, y);
        float h = kotoHash12(id + float(scale) * 17.0);
        vec2 center = id + 0.2 + 0.6 * vec2(h, kotoHash12(id + 3.1));
        float age = fract(t * rate * (0.6 + 0.4 * rainAmount) + h);
        float r = length(p - center);
        float front = age * 1.2;
        float ring = sin((r - front) * 26.0) * exp(-abs(r - front) * 9.0) * (1.0 - age);
        rings += ring * step(h, 0.35 + 0.6 * rainAmount);
      }
    }
  }
  return 0.5 + 0.25 * rings;
}

vec3 rainNormals(vec2 pos, float e, float depth, float rainAmount) {
  vec2 ex = vec2(e, 0.0);
  float h = getRainWaves(pos, TIDE_RIPPLE_LAYERS, rainAmount);
  float hx = getRainWaves(pos + ex.xy, TIDE_RIPPLE_LAYERS, rainAmount);
  float hz = getRainWaves(pos + ex.yx, TIDE_RIPPLE_LAYERS, rainAmount);
  return normalize(vec3(-(hx - h) / e * depth, 1.0, -(hz - h) / e * depth));
}

#endif //WAVES_GLSL
