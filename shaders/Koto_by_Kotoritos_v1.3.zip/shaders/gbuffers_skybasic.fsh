#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/lighting/lighting.glsl"

in vec3 normal;
in mat3 tbnMatrix;
vec3 horizon;
vec3 zenith;
in vec3 modelPos;
in vec3 viewPos;
in vec4 glcolor;
in vec2 texcoord;
in vec3 feetPlayerPos;
in vec3 eyePlayerPos;
uniform int renderStage;



/* RENDERTARGETS: 0,11 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 stars;
void main() {
  // Do not overwrite colortex11 on non-star sky draws; that used to erase
  // the star buffer depending on Minecraft/Iris draw ordering.
  if (renderStage != MC_RENDER_STAGE_STARS || !kotoIsOverworldDimension()) discard;

  color = vec4(0.0);
  float night = smoothstep(0.01, 0.18, kotoNightFactor());
  if (night <= 0.001) return;

  vec3 dir = normalize(eyePlayerPos);
  float horizonFade = smoothstep(-0.02, 0.12, dir.y);

  // Stable, slow twinkle: brightness varies subtly but never switches the star field off.
  float spatialPhase = dot(feetPlayerPos.xz, vec2(0.0137, 0.0191));
  float twinkle = 0.94 + 0.06 * sin(frameTimeCounter * 0.28 + spatialPhase);

  stars = pow(max(glcolor, vec4(0.0)), vec4(2.2));
  stars.rgb *= 0.88 * night * horizonFade * twinkle;
  stars.a *= night * horizonFade;
}
