#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#define VOID_REALM_PIPE 1

/* RENDERTARGETS: 15,1,2,3,4,6,7,5 */
#include "/lib/koto/stages/shared/gbuffers_hand_water_fsh.glsl"
