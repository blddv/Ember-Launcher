#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#define VOID_REALM_PIPE 1

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/atmosphere/distance_fog.glsl"

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;


float kotoHash12(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

float kotoHash13(vec3 p3) {
  p3 = fract(p3 * 0.1031);
  p3 += dot(p3, p3.zyx + 31.32);
  return fract((p3.x + p3.y) * p3.z);
}

mat2 kotoRot(float a) {
  float s = sin(a), c = cos(a);
  return mat2(c, -s, s, c);
}

float kotoNoise2(vec2 x) {
  vec2 i = floor(x);
  vec2 f = fract(x);
  f = f * f * (3.0 - 2.0 * f);
  float a = kotoHash12(i);
  float b = kotoHash12(i + vec2(1.0, 0.0));
  float c = kotoHash12(i + vec2(0.0, 1.0));
  float d = kotoHash12(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float kotoNoise3(vec3 x) {
  vec3 i = floor(x);
  vec3 f = fract(x);
  f = f * f * (3.0 - 2.0 * f);
  float n000 = kotoHash13(i + vec3(0.0, 0.0, 0.0));
  float n100 = kotoHash13(i + vec3(1.0, 0.0, 0.0));
  float n010 = kotoHash13(i + vec3(0.0, 1.0, 0.0));
  float n110 = kotoHash13(i + vec3(1.0, 1.0, 0.0));
  float n001 = kotoHash13(i + vec3(0.0, 0.0, 1.0));
  float n101 = kotoHash13(i + vec3(1.0, 0.0, 1.0));
  float n011 = kotoHash13(i + vec3(0.0, 1.0, 1.0));
  float n111 = kotoHash13(i + vec3(1.0, 1.0, 1.0));
  float x00 = mix(n000, n100, f.x);
  float x10 = mix(n010, n110, f.x);
  float x01 = mix(n001, n101, f.x);
  float x11 = mix(n011, n111, f.x);
  float y0 = mix(x00, x10, f.y);
  float y1 = mix(x01, x11, f.y);
  return mix(y0, y1, f.z);
}

float kotoFbm2(vec2 p) {
  float s = 0.0;
  float a = 0.5;
  mat2 r = kotoRot(0.65);
  for (int i = 0; i < 5; ++i) {
    s += a * kotoNoise2(p);
    p = r * p * 2.03 + vec2(17.2, 9.4);
    a *= 0.52;
  }
  return s;
}

float kotoFbm3(vec3 p) {
  float s = 0.0;
  float a = 0.5;
  for (int i = 0; i < 4; ++i) {
    s += a * kotoNoise3(p);
    p = p * 2.02 + vec3(11.3, 7.1, 5.7);
    a *= 0.53;
  }
  return s;
}

vec2 kotoSkyUV(vec3 d) {
  float lon = atan(d.z, d.x) / (2.0 * PI) + 0.5;
  float lat = asin(clamp(d.y, -1.0, 1.0)) / PI + 0.5;
  return vec2(lon, lat);
}

vec3 kotoTriWeights(vec3 n) {
  vec3 w = pow(abs(n), vec3(6.0));
  return w / max(dot(w, vec3(1.0)), 1e-6);
}

float kotoDirFbm(vec3 d, float scale, vec3 offset) {
  vec3 p = normalize(d) * scale + offset;
  vec3 w = kotoTriWeights(d);
  float yz = kotoFbm2(p.yz);
  float xz = kotoFbm2(p.xz);
  float xy = kotoFbm2(p.xy);
  return yz * w.x + xz * w.y + xy * w.z;
}

float kotoSquareStar(float localMax, float size) {
  float square = 1.0 - smoothstep(size * 0.55, size, localMax);
  float core = 1.0 - smoothstep(size * 0.18, size * 0.42, localMax);
  return square * 0.85 + core * 0.55;
}

vec3 kotoGalaxyStars(vec3 dir) {
  dir = normalize(dir);
  float horizon = smoothstep(-0.02, 0.10, dir.y);
  float twinkleBase = frameTimeCounter * 0.08;
  vec3 col = vec3(0.0);

  float scales[3] = float[3](68.0, 112.0, 176.0);
  float thresholds[3] = float[3](0.972, 0.985, 0.993);
  float sizes[3] = float[3](0.31, 0.23, 0.16);
  for (int i = 0; i < 3; ++i) {
    vec3 g = dir * scales[i];
    vec3 cell = floor(g + 100.0 + float(i) * 17.0);
    vec3 local = fract(g + 100.0 + float(i) * 17.0) - 0.5;
    float seed = kotoHash13(cell + float(i) * 19.7);
    float present = step(thresholds[i], seed);
    float size = sizes[i] * mix(0.72, 1.28, kotoHash13(cell + 4.7 + float(i)));
    float twinkle = 0.92 + 0.08 * sin(twinkleBase * (1.0 + float(i) * 0.35) + seed * 61.0);
    vec3 starColor = mix(vec3(0.72, 0.82, 1.08), vec3(1.02, 0.94, 0.96), kotoHash13(cell + 31.7));
    float shape = kotoSquareStar(max(max(abs(local.x), abs(local.y)), abs(local.z)), size);
    col += starColor * present * shape * twinkle;
  }

  return col * horizon * 1.35;
}

vec3 kotoEndGalaxySky(vec3 dir) {
  dir = normalize(dir);
  vec3 base = mix(vec3(0.006, 0.004, 0.014), vec3(0.022, 0.010, 0.035), smoothstep(-0.24, 0.84, dir.y));

  // Primary galactic band.
  vec3 galAxis = normalize(vec3(0.17, 0.95, -0.20));
  vec3 refUp = abs(galAxis.y) > 0.95 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
  vec3 galRight = normalize(cross(refUp, galAxis));
  vec3 galForward = normalize(cross(galAxis, galRight));
  float planeDist = dot(dir, galAxis);
  float band = pow(clamp(1.0 - abs(planeDist) / 0.33, 0.0, 1.0), 1.70);
  float wideBand = pow(clamp(1.0 - abs(planeDist) / 0.60, 0.0, 1.0), 1.10);
  vec2 planeUv = vec2(dot(dir, galRight), dot(dir, galForward));
  planeUv = planeUv * 2.7 + vec2(frameTimeCounter * 0.00042, -frameTimeCounter * 0.00019);

  float macro = kotoFbm2(planeUv * 1.05 + vec2(2.7, -3.0));
  float detail = kotoFbm2((kotoRot(0.33) * planeUv) * 2.60 + vec2(-7.1, 4.8));
  float wisps = kotoFbm2((kotoRot(-0.58) * planeUv) * 4.8 + vec2(8.5, -2.2));
  float dust = kotoFbm2((kotoRot(0.95) * planeUv) * 3.3 + vec2(-2.0, 7.2));
  float filaments = kotoDirFbm(dir, 9.0, vec3(2.0, -1.0, 3.0));

  float cloudMask = smoothstep(0.34, 0.88, macro * 0.62 + detail * 0.23 + wisps * 0.15);
  float dustMask = smoothstep(0.42, 0.82, dust);
  float filamentMask = smoothstep(0.52, 0.90, filaments);

  vec3 violet = vec3(0.54, 0.18, 0.88);
  vec3 magenta = vec3(0.90, 0.22, 0.98);
  vec3 lavender = vec3(0.56, 0.40, 1.0);
  vec3 cyan = vec3(0.16, 0.72, 0.95);
  vec3 rose = vec3(0.98, 0.40, 0.84);

  vec3 bandColor = mix(violet, magenta, smoothstep(0.18, 0.82, macro));
  bandColor = mix(bandColor, lavender, smoothstep(0.38, 0.90, detail) * 0.55);
  bandColor = mix(bandColor, cyan, filamentMask * 0.18);
  bandColor = mix(bandColor, rose, smoothstep(0.64, 0.95, wisps) * 0.16);

  vec3 nebula = bandColor * (0.34 + 1.25 * cloudMask) * band * (0.72 + 0.56 * wideBand);

  // Secondary ribbon for a grander galaxy impression.
  vec3 galAxis2 = normalize(vec3(-0.36, 0.82, 0.44));
  vec3 refUp2 = abs(galAxis2.y) > 0.95 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
  vec3 galRight2 = normalize(cross(refUp2, galAxis2));
  vec3 galForward2 = normalize(cross(galAxis2, galRight2));
  float planeDist2 = dot(dir, galAxis2);
  float band2 = pow(clamp(1.0 - abs(planeDist2) / 0.46, 0.0, 1.0), 1.55);
  vec2 planeUv2 = vec2(dot(dir, galRight2), dot(dir, galForward2)) * 2.2;
  float secA = kotoFbm2(planeUv2 * 1.7 + vec2(-3.7, 2.8));
  float secB = kotoFbm2((kotoRot(0.6) * planeUv2) * 3.2 + vec2(1.2, -6.4));
  float secMask = smoothstep(0.50, 0.90, secA * 0.68 + secB * 0.32);
  vec3 secondaryNebula = mix(vec3(0.28, 0.10, 0.50), vec3(0.76, 0.24, 0.94), secA) * secMask * band2 * 0.78;

  // Dark lanes and soft cluster glows for depth.
  float lane = smoothstep(0.50, 0.90, dustMask * band + detail * 0.20);
  float lane2 = smoothstep(0.55, 0.92, secB) * band2;
  float vol = kotoDirFbm(dir, 6.5, vec3(0.0, frameTimeCounter * 0.0002, 0.0));
  float volMask = smoothstep(0.32, 0.84, vol);
  nebula *= 0.84 + volMask * 0.52;
  secondaryNebula *= 0.90 + volMask * 0.34;

  float clusterA = pow(max(dot(dir, normalize(galRight * 0.72 + galForward * 0.66 + galAxis * 0.11)), 0.0), 12.0);
  float clusterB = pow(max(dot(dir, normalize(galRight * -0.53 + galForward * 0.78 + galAxis * -0.16)), 0.0), 11.0);
  float clusterC = pow(max(dot(dir, normalize(galRight2 * 0.63 + galForward2 * -0.69 + galAxis2 * 0.19)), 0.0), 12.0);
  vec3 clusterGlow = vec3(0.22, 0.10, 0.36) * clusterA * 0.65 + vec3(0.30, 0.10, 0.42) * clusterB * 0.60 + vec3(0.18, 0.08, 0.32) * clusterC * 0.55;

  vec3 sky = base + nebula + secondaryNebula + clusterGlow;
  sky *= 1.0 - lane * 0.32 * band;
  sky *= 1.0 - lane2 * 0.18;

  // Seamless full-vault haze and a faint aurora-like veil.
  float upperHaze = kotoDirFbm(dir, 7.8, vec3(4.2, -2.1, 1.3));
  float upperMask = smoothstep(0.56, 0.90, upperHaze) * smoothstep(-0.08, 0.90, dir.y);
  float veil = kotoDirFbm(normalize(dir + vec3(0.0, 0.25, 0.0)), 12.0, vec3(-3.0, 1.4, 5.2));
  float veilMask = smoothstep(0.64, 0.94, veil) * smoothstep(0.10, 0.95, dir.y);
  sky += vec3(0.14, 0.05, 0.20) * upperMask * 0.70;
  sky += vec3(0.24, 0.10, 0.34) * veilMask * 0.30;

  sky += kotoGalaxyStars(dir) * (1.20 + band * 0.34 + band2 * 0.18);
  return max(sky, 0.0);
}

vec3 kotoNetherSky(vec3 dir) {
  dir = normalize(dir);
  float up = smoothstep(-0.18, 0.90, dir.y);
  vec3 base = mix(vec3(0.055, 0.010, 0.010), vec3(0.220, 0.030, 0.020), up);

  float hazeA = kotoDirFbm(dir, 5.5, vec3(1.0, -2.0, 3.0));
  float hazeB = kotoDirFbm(normalize(dir + vec3(0.0, 0.18, 0.0)), 9.0, vec3(-4.0, 3.0, 1.0));
  float hazeC = kotoDirFbm(normalize(dir + vec3(0.0, 0.34, 0.0)), 13.0, vec3(7.0, -1.0, 5.0));
  float haze = smoothstep(0.34, 0.90, hazeA * 0.52 + hazeB * 0.30 + hazeC * 0.18);

  vec3 redNebula = mix(vec3(0.22, 0.03, 0.02), vec3(0.52, 0.06, 0.04), hazeA);
  vec3 orangeNebula = vec3(0.44, 0.14, 0.04) * smoothstep(0.58, 0.92, hazeB);
  vec3 smokeNebula = vec3(0.10, 0.02, 0.02) * smoothstep(0.55, 0.90, hazeC);
  vec3 sky = base + redNebula * haze * 0.78 + orangeNebula * 0.26 + smokeNebula * 0.22;

  // Brighter upper vault without introducing a visible seam.
  float crown = pow(max(dir.y, 0.0), 1.35);
  sky += vec3(0.12, 0.02, 0.015) * crown * 0.70;

  // Sparse ember-like stars using seamless direction-space cells.
  vec3 stars = vec3(0.0);
  float scales[2] = float[2](72.0, 130.0);
  float thresholds[2] = float[2](0.993, 0.997);
  float sizes[2] = float[2](0.23, 0.16);
  for (int i = 0; i < 2; ++i) {
    vec3 g = dir * scales[i];
    vec3 cell = floor(g + 80.0 + float(i) * 13.0);
    vec3 local = fract(g + 80.0 + float(i) * 13.0) - 0.5;
    float seed = kotoHash13(cell + float(i) * 9.7);
    float present = step(thresholds[i], seed);
    float sz = sizes[i] * mix(0.75, 1.20, kotoHash13(cell + 9.1));
    float shape = kotoSquareStar(max(max(abs(local.x), abs(local.y)), abs(local.z)), sz);
    vec3 starColor = mix(vec3(0.90, 0.32, 0.14), vec3(1.0, 0.58, 0.24), kotoHash13(cell + 1.7));
    stars += present * shape * starColor;
  }
  sky += stars * (0.18 + 0.44 * up);
  return max(sky, 0.0);
}

void main() {

  color = texture(colortex0, texcoord);
  vec2 lightmap = texture(colortex1, texcoord).rg;
  float depth = texture(depthtex0, texcoord).r;

  vec4 stars = texture(colortex11, texcoord);

  vec4 SpecMap = texture(colortex3, texcoord);
  bool isMetal = SpecMap.g >= 230.0 / 255.0;
  if(isMetal) return;
  //space conversions
  vec3 NDCPos = vec3(texcoord.xy, depth) * 2.0 - 1.0;
  vec3 viewPos = projectAndDivide(gbufferProjectionInverse, NDCPos);
  vec3 feetPlayerPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
  vec3 eyePlayerPos = feetPlayerPos - gbufferModelViewInverse[3].xyz;

#ifdef VOID_REALM_PIPE
  if (depth == 1.0) {
    color.rgb = kotoEndGalaxySky(normalize(eyePlayerPos));
  }
#else
  if (depth == 1.0 && kotoIsOverworldDimension())
  {
    vec3 sky = skyScattering(eyePlayerPos);
    vec3 celestialBody = getSun(normalize(eyePlayerPos));
    color.rgb = sky + celestialBody + stars.rgb;
  }
#endif
  // In dimensions without skylight, preserve Minecraft's dimension background.
  // This prevents the Overworld sun, moon and stars from leaking into Nether/The End.
}
