#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#define VOID_REALM_PIPE 1

#include "/lib/koto/shadows/distortion.glsl"
#include "/lib/koto/core/uniforms.glsl"
uniform sampler2D gtexture;
out vec2 texcoord;
out vec4 glcolor;
out vec3 feetPlayerPos;
out vec3 shadowViewPos;
in vec2 mc_Entity;

in vec4 at_midBlock;
uniform int entityId;
uniform int renderStage;


void main() {
  //standard stuff
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	glcolor = gl_Color;

  shadowViewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
  feetPlayerPos = (shadowModelViewInverse * vec4(shadowViewPos, 1.0)).xyz;

  vec3 worldPos = feetPlayerPos + cameraPosition;



  gl_Position = gl_ProjectionMatrix * vec4(shadowViewPos, 1.0);
  gl_Position.xyz = distortShadowClipPos(gl_Position.xyz);
}
