#version 400 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#define VOID_REALM_PIPE 1

/* RENDERTARGETS: 0,13 */
#include "/lib/koto/stages/shared/composite8_fsh.glsl"
