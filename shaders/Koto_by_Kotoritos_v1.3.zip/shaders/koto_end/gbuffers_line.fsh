#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#define VOID_REALM_PIPE 1

/* RENDERTARGETS: 15,7 */
#include "/lib/koto/stages/shared/gbuffers_line_fsh.glsl"
