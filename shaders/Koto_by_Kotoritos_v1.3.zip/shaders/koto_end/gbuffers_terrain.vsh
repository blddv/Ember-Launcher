#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#define VOID_REALM_PIPE 1

#include "/lib/koto/stages/shared/gbuffers_terrain_vsh.glsl"
