#version 400 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#define VOID_REALM_PIPE 1

#include "/lib/koto/lighting/lighting.glsl"
#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/shadows/soft_shadows.glsl"
#include "/lib/koto/post/post_processing.glsl"
#include "/lib/koto/materials/block_ids.glsl"
#include "/lib/koto/atmosphere/distance_fog.glsl"
#include "/lib/koto/shadows/ambient_occlusion.glsl"
uniform sampler2D gtexture;

uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 normal;
in mat3 tbnMatrix;
in vec3 modelPos;
in vec3 viewPos;
in vec3 feetPlayerPos;
in vec3 worldPos;
flat in int blockID;
in float emission;

/* RENDERTARGETS: 15,1,2,3,4,5,9 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 lightmap;
layout(location = 2) out vec4 encodedNormal;
layout(location = 3) out vec4 specData;
layout(location = 4) out vec4 geoNormal;
layout(location = 5) out vec4 mask;
layout(location = 6) out vec4 blocklight;

void main() {
  bool isPortal = blockID == PORTAL_ID;
  // Translucents (portal, glass, ice, slime, honey...) use their own atlas texture.
  // Reading colortex0 with atlas UVs returned random screen pixels that changed
  // whenever the camera turned.
  color = texture(gtexture, texcoord) * glcolor;

  vec3 normalMaps = texture(normals, texcoord, 0).rgb;
  normalMaps = normalMaps * 2.0 - 1.0;
  normalMaps.xy /= 254.0 / 255.0;
  normalMaps.z = sqrt(max(0.0, 1.0 - dot(normalMaps.xy, normalMaps.xy)));
  vec3 mappedNormal = tbnMatrix * normalMaps;

  lightmap = vec4(lmcoord, 0.0, 1.0);
  encodedNormal = vec4(mappedNormal * 0.5 + 0.5, 1.0);
  specData = texture(specular, texcoord);

  geoNormal = vec4(normal * 0.5 + 0.5, 1.0);
  if (isPortal) {
    // Portal is an animated emissive translucent surface, not a PBR water/metal surface.
    encodedNormal = geoNormal;
    specData = vec4(0.0, 0.04, 0.0, 0.25);
  }
  if (color.a < 0.1) {
    discard;
  }
  vec3 shadowViewPos = (shadowModelView * vec4(feetPlayerPos, 1.0)).xyz;
  vec4 shadowClipPos = shadowProjection * vec4(shadowViewPos, 1.0);
  vec3 viewDir = normalize(viewPos);
  vec3 V = normalize(cameraPosition - worldPos);
  vec3 L = normalize(worldLightVector);
  vec3 H = normalize(V + L);
  float VdotL = dot(normalize(feetPlayerPos), worldLightVector);

  bool isMetal = specData.g >= 230.0 / 255.0;

  //PBR
  float roughness = pow(1.0 - specData.r, 2.0);
  float sss = specData.b;
  float emission = specData.a;
  vec3 emissive = vec3(0.0);
  #ifndef MATTER_EMISSION_RESPONSE
  if (emission < 1.0) {
    emission = min(emission, 1.0);
    emissive += color.rgb * emission;
    emissive += max(105.25 * pow(emissive, vec3(2.58)), 0.0);

    emissive = CSB(emissive, 1.0, 0.95, 1.0);
    //emissive = pow(emissive, vec3(2.2));
  }
#endif //MATTER_EMISSION_RESPONSE

  vec3 shadow = getSoftShadow(shadowClipPos, geoNormal.rgb, sss);
  vec3 f0 = vec3(0.0);
  if (isMetal) {
    f0 = color.rgb;
  } else {
    f0 = vec3(specData.g);
  }
  float ao = texture(normals,texcoord).z * 0.5 + 0.5;

  if (blockID == WATER_ID) {
    mask = vec4(1.0, 1.0, 1.0, 1.0);
    #ifdef TIDE_MOTION_ENABLE
    encodedNormal = geoNormal;
    #endif
    color.a *= 0.0;

  } else {
    mask = vec4(0.0, 0.0, 0.0, 1.0);

  }
  bool isEmissive = emission > 0;
blocklight.rgb =  vec3(1.0, 0.8, 0.5843) * lightmap.r ;



if (isPortal) {
  color.a = clamp(color.a, 0.0, 1.0);
} else {
  color.a = min(color.a + 0.25, 1.0);
}



}
