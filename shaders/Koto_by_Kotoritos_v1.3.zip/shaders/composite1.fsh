#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.

/* RENDERTARGETS: 15 */
#include "/lib/koto/stages/shared/composite1_fsh.glsl"
