#version 400 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.

/* RENDERTARGETS: 0 */
#include "/lib/koto/stages/shared/deferred1_fsh.glsl"
