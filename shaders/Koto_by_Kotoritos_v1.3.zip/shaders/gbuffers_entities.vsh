#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.

#include "/lib/koto/stages/shared/gbuffers_entities_vsh.glsl"
