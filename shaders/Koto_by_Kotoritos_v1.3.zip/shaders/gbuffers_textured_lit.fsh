#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.

/* RENDERTARGETS: 15,1,2,3,4,5,9 */
#include "/lib/koto/stages/shared/gbuffers_textured_lit_fsh.glsl"
