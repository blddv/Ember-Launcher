#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.

/* RENDERTARGETS: 0,1,2,6,8 */
#include "/lib/koto/stages/shared/gbuffers_weather_fsh.glsl"
