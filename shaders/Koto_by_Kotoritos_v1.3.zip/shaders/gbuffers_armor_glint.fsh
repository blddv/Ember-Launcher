#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.

/* RENDERTARGETS: 0,2 */
#include "/lib/koto/stages/shared/gbuffers_armor_glint_fsh.glsl"
