#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#define PASS_LAYOUT_V2 1

#include "/lib/koto/core/util.glsl"
#include "/lib/koto/atmosphere/distance_fog.glsl"
#include "/lib/koto/materials/block_ids.glsl"
#include "/lib/koto/atmosphere/clouds.glsl"
in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

void main() {
  color = texture(colortex0, texcoord);

  float sceneDepth = texture(depthtex0, texcoord).r;
  vec3 clipPosition = vec3(texcoord, sceneDepth) * 2. - 1.;
  vec3 viewPosition = projectAndDivide(gbufferProjectionInverse, clipPosition);
  vec3 playerPosition = (gbufferModelViewInverse * vec4(viewPosition, 1.)).xyz;
  vec3 worldPosition = playerPosition + cameraPosition;

#ifdef CIRRUS_ENABLE
  if ((hasSkylight && !hasCeiling)) {
    vec3 stableNoise = blue_noise(floor(gl_FragCoord.xy), KOTO_NOISE_FRAME, VEIL_DITHER_CYCLE);
    color.rgb = cloudRaymarch(worldPosition, stableNoise, color.rgb);
  }
#endif
}
