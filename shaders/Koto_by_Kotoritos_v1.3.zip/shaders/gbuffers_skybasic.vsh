#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#define PASS_LAYOUT_V2 1

#include "/lib/koto/stages/shared/gbuffers_skybasic_vsh.glsl"
