#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#define PASS_LAYOUT_V2 1

#include "/lib/koto/lighting/lighting.glsl"
#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/shadows/soft_shadows.glsl"
#include "/lib/koto/post/post_processing.glsl"
#include "/lib/koto/materials/block_ids.glsl"

uniform sampler2D gtexture;

uniform float alphaTestRef = 0.1;

in vec2 lmcoord;
in vec2 texcoord;
in vec4 glcolor;
in vec3 normal;
in mat3 tbnMatrix;
in vec3 modelPos;
in vec3 viewPos;
in vec3 feetPlayerPos;
in vec3 worldPos;
flat in int blockID;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

vec4 kotoCloudSurfaceColor() {
  vec4 texel = texture(gtexture, texcoord);
  return (texel * glcolor);
}

void main() {
  color = kotoCloudSurfaceColor();
}

