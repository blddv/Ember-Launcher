#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.
#define PASS_LAYOUT_V2 1

#include "/lib/koto/core/uniforms.glsl"
#include "/lib/koto/post/edge_smooth.glsl"

in vec2 texcoord;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 color;

void main() {
  color = texture(colortex0, texcoord);

  #if PRISM_EDGE_PASS == 1 && ECHO_ENABLE == 0
  // Koto edge smoothing is skipped when TAA is on (no double filtering).
  color.rgb = kotoEdgeSmooth(color.rgb, colortex0, texcoord);
  #endif

}
