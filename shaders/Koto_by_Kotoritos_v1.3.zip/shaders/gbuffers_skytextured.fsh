#version 430 compatibility
// Koto by Kotoritos - ARR (All Rights Reserved). Do not copy, modify or redistribute.

uniform sampler2D gtexture;
uniform float alphaTestRef = 0.1;

in vec2 texcoord;
in vec4 glcolor;

/* RENDERTARGETS: 0,11 */
layout(location = 0) out vec4 color;
layout(location = 1) out vec4 celestial;

void main() {
  vec4 tex = texture(gtexture, texcoord) * glcolor;
  if (tex.a < alphaTestRef) discard;

  color = tex;
  // Vanilla sun/moon are disabled; Koto renders both celestial bodies procedurally.
  celestial = vec4(tex.rgb * tex.a, tex.a);
}
